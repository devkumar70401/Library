package com.devendra.healthtracker;

public enum MediaSource {
    YOUTUBE("YouTube", "#EF4444", "🎥"),
    INSTAGRAM("Instagram", "#EC4899", "📸"),
    WHATSAPP("WhatsApp Status", "#10B981", "💬"),
    GENERIC_WEB("Direct / Web", "#6366F1", "🌐");

    public final String displayName;
    public final String colorHex;
    public final String icon;

    MediaSource(String displayName, String colorHex, String icon) {
        this.displayName = displayName;
        this.colorHex = colorHex;
        this.icon = icon;
    }

    public static MediaSource detectFromUrl(String url) {
        if (url == null || url.trim().isEmpty()) return GENERIC_WEB;
        String lower = url.toLowerCase().trim();
        if (lower.contains("youtube.com") || lower.contains("youtu.be")) {
            return YOUTUBE;
        } else if (lower.contains("instagram.com") || lower.contains("instagr.am")) {
            return INSTAGRAM;
        } else if (lower.startsWith("whatsapp://") || lower.contains(".statuses") || lower.contains("whatsapp")) {
            return WHATSAPP;
        }
        return GENERIC_WEB;
    }
}
