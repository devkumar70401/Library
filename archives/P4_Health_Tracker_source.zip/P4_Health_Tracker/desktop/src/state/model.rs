//! Persistent state management for tracking fired triggers and date rollover.

use crate::config::model::FireAt;
use chrono::NaiveDate;
use serde::{Deserialize, Serialize};
use std::collections::HashSet;
use std::path::Path;

#[derive(Debug, Clone, Serialize, Deserialize, Default, PartialEq, Eq)]
pub struct PersistentState {
    pub last_seen_date: Option<NaiveDate>,
    pub fired_today: HashSet<(String, FireAt)>,
    pub consumed_once: HashSet<String>,
}

impl PersistentState {
    pub fn load(path: &Path) -> Self {
        if !path.exists() {
            return Self::default();
        }
        match std::fs::read_to_string(path) {
            Ok(content) => match serde_json::from_str::<Self>(&content) {
                Ok(state) => state,
                Err(err) => {
                    tracing::warn!(error = %err, path = %path.display(), "failed to parse state file; using default");
                    Self::default()
                }
            },
            Err(err) => {
                tracing::warn!(error = %err, path = %path.display(), "failed to read state file; using default");
                Self::default()
            }
        }
    }

    pub fn save_atomic(&self, path: &Path) -> anyhow::Result<()> {
        if let Some(parent) = path.parent() {
            std::fs::create_dir_all(parent)?;
        }
        let tmp_path = path.with_extension("tmp");
        let json = serde_json::to_string_pretty(self)?;
        std::fs::write(&tmp_path, json)?;
        std::fs::rename(&tmp_path, path)?;
        Ok(())
    }
}
