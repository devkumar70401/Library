//! State persistence module.

pub mod model;
pub use model::PersistentState;
