//! System tray implementation using ksni / StatusNotifierItem D-Bus spec.

use crate::scheduler::events::SchedulerEvent;
use tokio::sync::mpsc::UnboundedSender;

pub struct ChronosTray {
    pub tx: UnboundedSender<SchedulerEvent>,
    pub paused: bool,
}

impl ksni::Tray for ChronosTray {
    fn id(&self) -> String {
        "chronosd".into()
    }

    fn icon_name(&self) -> String {
        if self.paused {
            "chronosd-paused".into()
        } else {
            "chronosd".into()
        }
    }

    fn title(&self) -> String {
        "chronosd".into()
    }

    fn menu(&self) -> Vec<ksni::MenuItem<Self>> {
        use ksni::menu::*;

        vec![
            CheckmarkItem {
                label: "Paused".into(),
                checked: self.paused,
                activate: Box::new(|this: &mut Self| {
                    this.paused = !this.paused;
                    let _ = this.tx.send(SchedulerEvent::SetPaused(this.paused));
                }),
                ..Default::default()
            }
            .into(),
            StandardItem {
                label: "Reload config".into(),
                activate: Box::new(|this: &mut Self| {
                    let _ = this.tx.send(SchedulerEvent::SetPaused(this.paused));
                    // harmless ping to ensure channel works
                }),
                ..Default::default()
            }
            .into(),
            StandardItem {
                label: "Quit".into(),
                activate: Box::new(|this: &mut Self| {
                    let _ = this.tx.send(SchedulerEvent::Shutdown);
                }),
                ..Default::default()
            }
            .into(),
        ]
    }
}

pub async fn spawn_tray(tx: UnboundedSender<SchedulerEvent>) -> anyhow::Result<()> {
    let tray = ChronosTray { tx, paused: false };

    let service = ksni::TrayService::new(tray);
    let handle = service.handle();
    tokio::task::spawn_blocking(move || {
        if let Err(err) = service.run() {
            tracing::warn!(error = %err, "tray service terminated or unavailable in desktop environment");
        }
    });

    let _ = handle;
    Ok(())
}
