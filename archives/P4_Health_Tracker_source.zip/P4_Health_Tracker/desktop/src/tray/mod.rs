//! System tray integration module.

pub mod icon;
pub use icon::{spawn_tray, ChronosTray};
