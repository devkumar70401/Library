//! Command line argument parsing using clap.

use clap::Parser;
use std::path::PathBuf;
use tracing::level_filters::LevelFilter;

#[derive(Parser, Debug)]
#[command(
    name = "chronosd",
    version,
    about = "Local schedule reminder with full-screen overlay alerts"
)]
pub struct Cli {
    /// Custom path to schedule.toml configuration file
    #[arg(short, long)]
    pub config: Option<PathBuf>,

    /// Check and validate configuration file and exit
    #[arg(long)]
    pub check_config: bool,

    /// List all entries active for today and exit
    #[arg(long)]
    pub list_today: bool,

    /// Enable verbose / debug logging
    #[arg(short, long)]
    pub verbose: bool,
}

impl Cli {
    pub fn log_level(&self) -> LevelFilter {
        if self.verbose {
            LevelFilter::DEBUG
        } else {
            LevelFilter::INFO
        }
    }
}
