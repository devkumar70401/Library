//! Resolves XDG paths for configuration, state, and logs.

use directories::ProjectDirs;
use std::path::PathBuf;

fn project_dirs() -> anyhow::Result<ProjectDirs> {
    ProjectDirs::from("", "", "chronosd")
        .ok_or_else(|| anyhow::anyhow!("Unable to resolve user home / project directories"))
}

/// Returns the configuration directory, e.g. `$XDG_CONFIG_HOME/chronosd` or `~/.config/chronosd`.
pub fn config_dir() -> anyhow::Result<PathBuf> {
    let dirs = project_dirs()?;
    let path = dirs.config_dir().to_path_buf();
    std::fs::create_dir_all(&path)?;
    Ok(path)
}

/// Returns the state directory, e.g. `$XDG_STATE_HOME/chronosd` or `~/.local/state/chronosd`.
pub fn state_dir() -> anyhow::Result<PathBuf> {
    let dirs = project_dirs()?;
    let path = dirs
        .state_dir()
        .unwrap_or_else(|| dirs.data_local_dir())
        .to_path_buf();
    std::fs::create_dir_all(&path)?;
    Ok(path)
}
