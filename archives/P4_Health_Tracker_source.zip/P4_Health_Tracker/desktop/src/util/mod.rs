//! General utility functions for XDG resolution and time conversions.

pub mod time_ext;
pub mod xdg;
