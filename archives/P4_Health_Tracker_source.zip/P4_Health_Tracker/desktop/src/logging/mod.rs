//! Structured rotating file logging using tracing.

use crate::util::xdg;
use tracing::level_filters::LevelFilter;

pub fn init_logging(
    verbosity: LevelFilter,
) -> anyhow::Result<tracing_appender::non_blocking::WorkerGuard> {
    let state_dir = xdg::state_dir()?;
    let log_dir = state_dir.join("logs");
    std::fs::create_dir_all(&log_dir)?;
    let file_appender = tracing_appender::rolling::daily(&log_dir, "chronosd.log");
    let (non_blocking, guard) = tracing_appender::non_blocking(file_appender);

    tracing_subscriber::fmt()
        .with_writer(non_blocking)
        .with_max_level(verbosity)
        .with_ansi(false)
        .init();

    Ok(guard)
}
