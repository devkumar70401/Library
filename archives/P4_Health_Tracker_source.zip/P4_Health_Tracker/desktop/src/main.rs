#![allow(dead_code, unused_imports)]
//! chronosd — A local, network-free desktop schedule reminder with full-screen overlay alerts.

use arc_swap::ArcSwap;
use chrono::Datelike;
use clap::Parser;
use std::sync::{Arc, Mutex};
use std::time::Duration;

mod cli;
mod config;
mod logging;
mod notify_fallback;
mod overlay;
mod scheduler;
mod state;
mod tray;
mod util;

fn main() -> anyhow::Result<()> {
    // 1. Root privilege check
    if unsafe { libc::geteuid() } == 0 {
        eprintln!("refusing to run as root; this is a per-user desktop tool");
        std::process::exit(1);
    }

    // 2. CLI Arguments
    let cli = cli::Cli::parse();
    let _log_guard = logging::init_logging(cli.log_level())?;

    // 3. Config resolution
    let config_path = match cli.config {
        Some(p) => p,
        None => config::Loader::default_path()?,
    };

    let loader = config::Loader::new(config_path.clone());
    loader.ensure_example_exists()?;

    // 4. CLI flags: --check-config
    if cli.check_config {
        let schedule = loader.load()?;
        println!(
            "Configuration at '{}' is valid. ({} entries loaded)",
            config_path.display(),
            schedule.entries.len()
        );
        return Ok(());
    }

    // 5. CLI flags: --list-today
    if cli.list_today {
        let schedule = loader.load()?;
        let now = chrono::Local::now();
        let today = now.date_naive();
        let weekday = now.weekday();

        println!("Schedule for today ({} {}):", today, weekday);
        let mut active_count = 0;
        for entry in &schedule.entries {
            if scheduler::SchedulerEngine::applies_today(&entry.repeat, weekday) {
                active_count += 1;
                println!(
                    "  [{}] {} – {} : \"{}\" (repeat: {:?}, fire_at: {:?})",
                    entry.id,
                    util::time_ext::format_hhmm(&entry.start),
                    util::time_ext::format_hhmm(&entry.end),
                    entry.title,
                    entry.repeat,
                    entry.fire_at
                );
            }
        }
        if active_count == 0 {
            println!("  (No scheduled entries for today)");
        }
        return Ok(());
    }

    // 6. Initial Load
    let initial_schedule = loader.load()?;
    let initial_mode = initial_schedule.settings.overlay_mode;
    let initial_settings = initial_schedule.settings.clone();
    let schedule = Arc::new(ArcSwap::from_pointee(initial_schedule));

    // 7. Persistent State
    let state_path = util::xdg::state_dir()?.join("state.json");
    let state = Arc::new(Mutex::new(state::PersistentState::load(&state_path)));

    // 8. Two-Channel Architecture
    let (tx_control, rx_control) =
        tokio::sync::mpsc::unbounded_channel::<scheduler::SchedulerEvent>();
    let (tx_triggers, rx_triggers) = std::sync::mpsc::channel::<scheduler::TriggerPayload>();
    let rx_triggers = Arc::new(Mutex::new(rx_triggers));
    let rx_triggers_for_overlay = rx_triggers.clone();
    let rx_triggers_for_fallback = rx_triggers.clone();

    // 9. Tokio Runtime on background thread
    let rt = tokio::runtime::Builder::new_multi_thread()
        .enable_all()
        .build()?;
    let _rt_guard = rt.enter();

    // Spawn config watcher
    let tx_watcher = tx_control.clone();
    let _watcher = config::watcher::spawn_watcher(config_path, tx_watcher, rt.handle().clone())?;

    // Spawn scheduler engine
    let schedule_for_engine = schedule.clone();
    let state_for_engine = state.clone();
    let state_path_for_engine = state_path.clone();
    let tx_triggers_for_engine = tx_triggers.clone();

    rt.spawn(async move {
        let engine = scheduler::SchedulerEngine::new(
            schedule_for_engine,
            state_for_engine,
            state_path_for_engine,
            tx_triggers_for_engine,
        );
        engine.run(rx_control).await;
    });

    // Spawn system tray
    let tx_tray = tx_control.clone();
    rt.spawn(async move {
        let _ = tray::spawn_tray(tx_tray).await;
    });

    // Signal handler for clean shutdown
    let tx_signals = tx_control.clone();
    rt.spawn(async move {
        let mut sigterm = tokio::signal::unix::signal(tokio::signal::unix::SignalKind::terminate())
            .expect("failed to bind SIGTERM");
        tokio::select! {
            _ = sigterm.recv() => {
                tracing::info!("received SIGTERM");
            }
            _ = tokio::signal::ctrl_c() => {
                tracing::info!("received Ctrl+C (SIGINT)");
            }
        }
        let _ = tx_signals.send(scheduler::SchedulerEvent::Shutdown);
    });

    // 10. Run eframe on Main Thread
    let native_options = overlay::native_options(initial_mode);
    let app_settings = initial_settings;
    let app_tx_control = tx_control.clone();

    tracing::info!("starting chronosd desktop overlay daemon");

    let run_res = eframe::run_native(
        "chronosd-overlay",
        native_options,
        Box::new(move |_cc| {
            Box::new(overlay::OverlayApp::new(
                rx_triggers_for_overlay,
                app_tx_control,
                app_settings,
            ))
        }),
    );

    if let Err(err) = run_res {
        tracing::error!(error = %err, "GUI failed to launch; running in headless notification fallback mode");
        // Degrade to notification-only mode if display server is not reachable
        while let Ok(rx) = rx_triggers_for_fallback.lock() {
            if let Ok(payload) = rx.recv() {
                let body = format!("Scheduled for {}", payload.scheduled_time.format("%H:%M"));
                let _ = notify_fallback::send_fallback(&payload.title, &body);
            } else {
                break;
            }
        }
    }

    rt.shutdown_timeout(Duration::from_secs(2));
    tracing::info!("chronosd daemon shutdown complete");
    Ok(())
}
