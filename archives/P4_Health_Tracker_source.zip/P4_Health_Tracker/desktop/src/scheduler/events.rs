//! Events passing through the scheduler and UI channels.

use crate::config::model::{FireAt, Schedule};
use chrono::NaiveTime;

#[derive(Debug, Clone, PartialEq, Eq)]
pub struct TriggerPayload {
    pub entry_id: String,
    pub title: String,
    pub boundary: FireAt,
    pub scheduled_time: NaiveTime,
}

#[derive(Debug, Clone)]
pub enum SchedulerEvent {
    Trigger(TriggerPayload),
    Reload(Schedule),
    SetPaused(bool),
    Snooze { entry_id: String, minutes: u32 },
    Shutdown,
}
