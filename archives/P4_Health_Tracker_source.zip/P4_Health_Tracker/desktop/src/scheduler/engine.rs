//! Scheduler engine evaluation loop and trigger computation.

use crate::config::model::{Entry, FireAt, Repeat, Schedule};
use crate::scheduler::clock::{Clock, SystemClock};
use crate::scheduler::events::{SchedulerEvent, TriggerPayload};
use crate::state::PersistentState;
use arc_swap::ArcSwap;
use chrono::{DateTime, Datelike, Local, NaiveTime, Timelike, Weekday};
use smallvec::{smallvec, SmallVec};
use std::path::PathBuf;
use std::sync::atomic::{AtomicBool, Ordering};
use std::sync::{Arc, Mutex};
use std::time::Duration;
use tokio::sync::mpsc;

pub struct SchedulerEngine {
    pub schedule: Arc<ArcSwap<Schedule>>,
    pub state: Arc<Mutex<PersistentState>>,
    pub state_path: PathBuf,
    pub clock: Arc<dyn Clock>,
    pub tx_triggers: std::sync::mpsc::Sender<TriggerPayload>,
    pub paused: Arc<AtomicBool>,
    pub snoozed: Vec<(DateTime<Local>, TriggerPayload)>,
}

impl SchedulerEngine {
    pub fn new(
        schedule: Arc<ArcSwap<Schedule>>,
        state: Arc<Mutex<PersistentState>>,
        state_path: PathBuf,
        tx_triggers: std::sync::mpsc::Sender<TriggerPayload>,
    ) -> Self {
        Self {
            schedule,
            state,
            state_path,
            clock: Arc::new(SystemClock),
            tx_triggers,
            paused: Arc::new(AtomicBool::new(false)),
            snoozed: Vec::new(),
        }
    }

    pub fn with_clock(mut self, clock: Arc<dyn Clock>) -> Self {
        self.clock = clock;
        self
    }

    /// Evaluates one clock tick.
    pub fn tick(&mut self) {
        if self.paused.load(Ordering::Relaxed) {
            return;
        }

        let now_dt = self.clock.now_local();
        let now_date = now_dt.date_naive();
        let now_time = now_dt.time();
        let weekday = now_dt.weekday();

        // 1. Process snoozed triggers
        let mut remaining_snoozed = Vec::new();
        for (target_dt, payload) in self.snoozed.drain(..) {
            if now_dt >= target_dt {
                tracing::info!(entry_id = %payload.entry_id, "firing snoozed trigger");
                let _ = self.tx_triggers.send(payload);
            } else {
                remaining_snoozed.push((target_dt, payload));
            }
        }
        self.snoozed = remaining_snoozed;

        // 2. State & date rollover
        let mut state = self.state.lock().expect("poisoned state lock");
        if state.last_seen_date != Some(now_date) {
            tracing::info!(old_date = ?state.last_seen_date, new_date = %now_date, "day rollover detected; resetting fired triggers");
            state.last_seen_date = Some(now_date);
            state.fired_today.clear();
            let _ = state.save_atomic(&self.state_path);
        }

        let schedule_snapshot = self.schedule.load();
        let grace_secs = (schedule_snapshot.settings.grace_period_minutes as i64) * 60;
        let now_sec = now_time.num_seconds_from_midnight() as i64;

        for entry in &schedule_snapshot.entries {
            if entry.repeat == Repeat::Once && state.consumed_once.contains(&entry.id) {
                continue;
            }

            if !Self::applies_today(&entry.repeat, weekday) {
                continue;
            }

            for (boundary, b_time) in Self::boundary_times(entry) {
                let key = (entry.id.clone(), boundary);
                if state.fired_today.contains(&key) {
                    continue;
                }

                let b_sec = b_time.num_seconds_from_midnight() as i64;
                let delta = now_sec - b_sec;

                if delta >= 0 {
                    if delta <= grace_secs {
                        tracing::info!(
                            entry_id = %entry.id,
                            boundary = ?boundary,
                            delta_secs = delta,
                            "triggering schedule entry"
                        );
                        let payload = TriggerPayload {
                            entry_id: entry.id.clone(),
                            title: entry.title.clone(),
                            boundary,
                            scheduled_time: b_time,
                        };
                        let _ = self.tx_triggers.send(payload);
                    } else {
                        tracing::info!(
                            entry_id = %entry.id,
                            boundary = ?boundary,
                            missed_min = delta / 60,
                            "skipped stale trigger for entry"
                        );
                    }

                    state.fired_today.insert(key);
                    if entry.repeat == Repeat::Once {
                        state.consumed_once.insert(entry.id.clone());
                    }
                    let _ = state.save_atomic(&self.state_path);
                }
            }
        }
    }

    /// Pure function: checks if a Repeat rule applies on a given Weekday.
    pub fn applies_today(repeat: &Repeat, weekday: Weekday) -> bool {
        match repeat {
            Repeat::Daily | Repeat::Once => true,
            Repeat::Weekdays => matches!(
                weekday,
                Weekday::Mon | Weekday::Tue | Weekday::Wed | Weekday::Thu | Weekday::Fri
            ),
            Repeat::Weekends => matches!(weekday, Weekday::Sat | Weekday::Sun),
        }
    }

    /// Pure function: returns boundary times for an Entry based on fire_at.
    pub fn boundary_times(entry: &Entry) -> SmallVec<[(FireAt, NaiveTime); 2]> {
        match entry.fire_at {
            FireAt::Start => smallvec![(FireAt::Start, entry.start)],
            FireAt::End => smallvec![(FireAt::End, entry.end)],
            FireAt::Both => smallvec![(FireAt::Start, entry.start), (FireAt::End, entry.end)],
        }
    }

    /// Main loop.
    pub async fn run(mut self, mut ctrl_rx: mpsc::UnboundedReceiver<SchedulerEvent>) {
        let mut interval = tokio::time::interval(Duration::from_secs(1));

        loop {
            tokio::select! {
                _ = interval.tick() => {
                    self.tick();
                }
                Some(event) = ctrl_rx.recv() => {
                    match event {
                        SchedulerEvent::Trigger(p) => {
                            let _ = self.tx_triggers.send(p);
                        }
                        SchedulerEvent::Reload(new_schedule) => {
                            tracing::info!(entries = new_schedule.entries.len(), "swapping in-memory schedule");
                            self.schedule.store(Arc::new(new_schedule));
                            self.tick();
                        }
                        SchedulerEvent::SetPaused(p) => {
                            tracing::info!(paused = p, "updating scheduler pause state");
                            self.paused.store(p, Ordering::Relaxed);
                        }
                        SchedulerEvent::Snooze { entry_id, minutes } => {
                            let now = self.clock.now_local();
                            let target = now + chrono::Duration::minutes(minutes as i64);
                            let title = {
                                let snap = self.schedule.load();
                                snap.entries.iter()
                                    .find(|e| e.id == entry_id)
                                    .map(|e| e.title.clone())
                                    .unwrap_or_else(|| "Snoozed Reminder".to_string())
                            };
                            tracing::info!(entry_id = %entry_id, minutes, target = %target, "snoozing entry");
                            self.snoozed.push((target, TriggerPayload {
                                entry_id,
                                title,
                                boundary: FireAt::Start,
                                scheduled_time: self.clock.now_time(),
                            }));
                        }
                        SchedulerEvent::Shutdown => {
                            tracing::info!("scheduler engine received shutdown; exiting loop");
                            break;
                        }
                    }
                }
            }
        }
    }
}
