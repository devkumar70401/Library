//! Clock abstraction to support deterministic time testing.

use chrono::{DateTime, Local, NaiveDate, NaiveTime};

pub trait Clock: Send + Sync {
    fn now_local(&self) -> DateTime<Local>;
    fn now_time(&self) -> NaiveTime {
        self.now_local().time()
    }
    fn now_date(&self) -> NaiveDate {
        self.now_local().date_naive()
    }
}

pub struct SystemClock;

impl Clock for SystemClock {
    fn now_local(&self) -> DateTime<Local> {
        Local::now()
    }
}

pub struct FixedClock {
    current: std::sync::RwLock<DateTime<Local>>,
}

impl FixedClock {
    pub fn new(initial: DateTime<Local>) -> Self {
        Self {
            current: std::sync::RwLock::new(initial),
        }
    }

    pub fn set(&self, dt: DateTime<Local>) {
        let mut lock = self.current.write().unwrap();
        *lock = dt;
    }

    pub fn advance_secs(&self, secs: i64) {
        let mut lock = self.current.write().unwrap();
        *lock += chrono::Duration::seconds(secs);
    }
}

impl Clock for FixedClock {
    fn now_local(&self) -> DateTime<Local> {
        *self.current.read().unwrap()
    }
}
