//! Filesystem watcher using `notify` for automatic hot-reloading.

use crate::config::loader::Loader;
use crate::scheduler::events::SchedulerEvent;
use notify::{Event, EventKind, RecommendedWatcher, RecursiveMode, Watcher};
use std::path::PathBuf;
use std::time::Duration;
use tokio::sync::mpsc;

pub fn spawn_watcher(
    path: PathBuf,
    tx: mpsc::UnboundedSender<SchedulerEvent>,
    handle: tokio::runtime::Handle,
) -> notify::Result<RecommendedWatcher> {
    let watch_path = path.clone();
    let parent_dir = path
        .parent()
        .unwrap_or_else(|| std::path::Path::new("."))
        .to_path_buf();
    let filename = path.file_name().map(|f| f.to_os_string());

    let (raw_tx, mut raw_rx) = tokio::sync::mpsc::unbounded_channel::<()>();

    let mut watcher = notify::recommended_watcher(move |res: notify::Result<Event>| {
        if let Ok(event) = res {
            let is_match = match event.kind {
                EventKind::Create(_) | EventKind::Modify(_) => {
                    if let Some(ref target_name) = filename {
                        event
                            .paths
                            .iter()
                            .any(|p| p.file_name() == Some(target_name))
                    } else {
                        true
                    }
                }
                _ => false,
            };

            if is_match {
                let _ = raw_tx.send(());
            }
        }
    })?;

    // Watch the parent directory so file replacements/atomic saves from editors are captured
    watcher.watch(&parent_dir, RecursiveMode::NonRecursive)?;

    // Debounce loop: wait 300ms of quiet before reloading
    handle.spawn(async move {
        let loader = Loader::new(watch_path);
        loop {
            if raw_rx.recv().await.is_none() {
                break;
            }

            // Drain any rapid bursts
            tokio::time::sleep(Duration::from_millis(300)).await;
            while raw_rx.try_recv().is_ok() {}

            match loader.load() {
                Ok(schedule) => {
                    tracing::info!(
                        entries_count = schedule.entries.len(),
                        "config reloaded successfully"
                    );
                    let _ = tx.send(SchedulerEvent::Reload(schedule));
                }
                Err(err) => {
                    tracing::error!(
                        error = %err,
                        "failed to reload config; keeping current in-memory schedule"
                    );
                }
            }
        }
    });

    Ok(watcher)
}
