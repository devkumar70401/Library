//! Config file loader and schema validation.

use crate::config::model::Schedule;
use crate::util::xdg;
use std::collections::HashSet;
use std::path::{Path, PathBuf};

#[derive(Debug, thiserror::Error)]
pub enum ConfigError {
    #[error("config file not found at {0}")]
    NotFound(PathBuf),
    #[error("failed to read config file: {0}")]
    Io(#[from] std::io::Error),
    #[error("failed to parse TOML: {0}")]
    Parse(#[from] toml::de::Error),
    #[error("duplicate entry id: {0}")]
    DuplicateId(String),
    #[error("entry '{id}': invalid time window (end <= start and crosses_midnight = false)")]
    InvalidWindow { id: String },
    #[error("entry '{id}': invalid value for field '{field}'")]
    InvalidEnumValue { id: String, field: String },
}

pub struct Loader {
    path: PathBuf,
}

impl Loader {
    /// Resolve the default config path via XDG, e.g. `$XDG_CONFIG_HOME/chronosd/schedule.toml`.
    pub fn default_path() -> anyhow::Result<PathBuf> {
        let dir = xdg::config_dir()?;
        Ok(dir.join("schedule.toml"))
    }

    /// Construct a loader for an explicit path.
    pub fn new(path: PathBuf) -> Self {
        Self { path }
    }

    /// Read the file, parse TOML, run validation, and return `Schedule`.
    pub fn load(&self) -> Result<Schedule, ConfigError> {
        if !self.path.exists() {
            return Err(ConfigError::NotFound(self.path.clone()));
        }
        let content = std::fs::read_to_string(&self.path)?;
        let schedule: Schedule = toml::from_str(&content)?;
        validate(&schedule)?;
        Ok(schedule)
    }

    /// If no config exists, write default example so the user has a starting template.
    pub fn ensure_example_exists(&self) -> anyhow::Result<bool> {
        if self.path.exists() {
            return Ok(false);
        }
        if let Some(parent) = self.path.parent() {
            std::fs::create_dir_all(parent)?;
        }
        const DEFAULT_CONFIG: &str = include_str!("../../config/schedule.example.toml");
        std::fs::write(&self.path, DEFAULT_CONFIG)?;
        Ok(true)
    }

    pub fn path(&self) -> &Path {
        &self.path
    }
}

/// Enforces the business validation rules for a Schedule.
pub fn validate(schedule: &Schedule) -> Result<(), ConfigError> {
    let mut seen_ids = HashSet::new();

    for entry in &schedule.entries {
        if !seen_ids.insert(&entry.id) {
            return Err(ConfigError::DuplicateId(entry.id.clone()));
        }

        if !entry.crosses_midnight && entry.end <= entry.start {
            return Err(ConfigError::InvalidWindow {
                id: entry.id.clone(),
            });
        }
    }

    if schedule.settings.play_sound
        && !schedule.settings.sound_file.is_empty()
        && !Path::new(&schedule.settings.sound_file).exists()
    {
        tracing::warn!(
            sound_file = %schedule.settings.sound_file,
            "configured sound_file does not exist; audio playback will be disabled"
        );
    }

    Ok(())
}
