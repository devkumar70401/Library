//! Data model for the schedule configuration.

use crate::util::time_ext;
use chrono::NaiveTime;
use serde::{Deserialize, Serialize};

#[derive(Debug, Clone, Deserialize, Serialize, PartialEq, Eq)]
#[serde(rename_all = "lowercase")]
pub enum Repeat {
    Daily,
    Weekdays,
    Weekends,
    Once,
}

#[derive(Debug, Clone, Copy, Deserialize, Serialize, PartialEq, Eq, Hash)]
#[serde(rename_all = "lowercase")]
pub enum FireAt {
    Start,
    End,
    Both,
}

fn default_fire_at() -> FireAt {
    FireAt::Start
}

#[derive(Debug, Clone, Deserialize, Serialize, PartialEq, Eq)]
pub struct Entry {
    pub id: String,
    #[serde(with = "time_ext::hhmm_format")]
    pub start: NaiveTime,
    #[serde(with = "time_ext::hhmm_format")]
    pub end: NaiveTime,
    pub title: String,
    pub repeat: Repeat,
    #[serde(default = "default_fire_at")]
    pub fire_at: FireAt,
    #[serde(default)]
    pub crosses_midnight: bool,
}

fn default_overlay_duration() -> u32 {
    20
}

fn default_overlay_mode() -> OverlayMode {
    OverlayMode::Fullscreen
}

fn default_true() -> bool {
    true
}

fn default_snooze_minutes() -> u32 {
    5
}

fn default_grace_period() -> u32 {
    10
}

fn default_timezone() -> String {
    "system".to_string()
}

#[derive(Debug, Clone, Copy, Deserialize, Serialize, PartialEq, Eq)]
#[serde(rename_all = "snake_case")]
pub enum OverlayMode {
    Fullscreen,
    CenteredBanner,
}

#[derive(Debug, Clone, Deserialize, Serialize, PartialEq, Eq)]
pub struct Settings {
    #[serde(default = "default_overlay_duration")]
    pub overlay_duration_secs: u32,
    #[serde(default = "default_overlay_mode")]
    pub overlay_mode: OverlayMode,
    #[serde(default = "default_true")]
    pub allow_snooze: bool,
    #[serde(default = "default_snooze_minutes")]
    pub snooze_minutes: u32,
    #[serde(default)]
    pub play_sound: bool,
    #[serde(default)]
    pub sound_file: String,
    #[serde(default = "default_grace_period")]
    pub grace_period_minutes: u32,
    #[serde(default = "default_timezone")]
    pub timezone: String,
}

impl Default for Settings {
    fn default() -> Self {
        Self {
            overlay_duration_secs: default_overlay_duration(),
            overlay_mode: default_overlay_mode(),
            allow_snooze: default_true(),
            snooze_minutes: default_snooze_minutes(),
            play_sound: false,
            sound_file: String::new(),
            grace_period_minutes: default_grace_period(),
            timezone: default_timezone(),
        }
    }
}

#[derive(Debug, Clone, Deserialize, Serialize, PartialEq, Eq)]
pub struct Schedule {
    #[serde(default)]
    pub settings: Settings,
    #[serde(default, rename = "entries")]
    pub entries: Vec<Entry>,
}
