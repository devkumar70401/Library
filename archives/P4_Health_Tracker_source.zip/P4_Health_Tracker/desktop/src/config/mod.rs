//! Configuration loading, models, validation, and hot-reloading.

pub mod loader;
pub mod model;
pub mod watcher;

pub use loader::{ConfigError, Loader};
pub use model::{Entry, FireAt, OverlayMode, Repeat, Schedule, Settings};
