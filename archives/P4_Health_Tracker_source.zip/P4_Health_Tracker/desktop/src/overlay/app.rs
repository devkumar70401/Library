//! eframe::App implementation for rendering the overlay.

use crate::config::model::{OverlayMode, Settings};
use crate::overlay::style::OverlayStyle;
use crate::scheduler::events::{SchedulerEvent, TriggerPayload};
use egui::{Align2, Color32, FontId, Pos2, Rect, Rounding, Vec2};
use std::collections::VecDeque;
use std::sync::mpsc::Receiver;
use std::sync::{Arc, Mutex};
use std::time::{Duration, Instant};
use tokio::sync::mpsc::UnboundedSender;

pub struct ActiveOverlay {
    pub payload: TriggerPayload,
    pub shown_at: Instant,
}

pub struct OverlayApp {
    rx_triggers: Arc<Mutex<Receiver<TriggerPayload>>>,
    tx_scheduler: UnboundedSender<SchedulerEvent>,
    settings: Settings,
    style: OverlayStyle,
    queue: VecDeque<TriggerPayload>,
    current: Option<ActiveOverlay>,
    is_window_visible: bool,
}

impl OverlayApp {
    pub fn new(
        rx_triggers: Arc<Mutex<Receiver<TriggerPayload>>>,
        tx_scheduler: UnboundedSender<SchedulerEvent>,
        settings: Settings,
    ) -> Self {
        Self {
            rx_triggers,
            tx_scheduler,
            settings,
            style: OverlayStyle::default(),
            queue: VecDeque::new(),
            current: None,
            is_window_visible: false,
        }
    }

    pub fn update_settings(&mut self, settings: Settings) {
        self.settings = settings;
    }

    fn collapse_if_backlogged(&mut self) {
        if self.queue.len() > 5 {
            let count = self.queue.len();
            let mut titles = Vec::new();
            while let Some(item) = self.queue.pop_front() {
                titles.push(item.title);
            }
            let combined_title = format!("{} reminders pending ({})", count, titles.join(", "));
            self.queue.push_back(TriggerPayload {
                entry_id: "backlog".to_string(),
                title: combined_title,
                boundary: crate::config::model::FireAt::Start,
                scheduled_time: chrono::Local::now().time(),
            });
        }
    }

    fn dismiss_current(&mut self, ctx: &egui::Context) {
        self.current = None;
        if self.queue.is_empty() && self.is_window_visible {
            ctx.send_viewport_cmd(egui::ViewportCommand::Visible(false));
            self.is_window_visible = false;
        }
    }

    fn snooze_current(&mut self, ctx: &egui::Context) {
        if let Some(active) = self.current.take() {
            let _ = self.tx_scheduler.send(SchedulerEvent::Snooze {
                entry_id: active.payload.entry_id,
                minutes: self.settings.snooze_minutes,
            });
        }
        self.dismiss_current(ctx);
    }
}

impl eframe::App for OverlayApp {
    fn update(&mut self, ctx: &egui::Context, _frame: &mut eframe::Frame) {
        // 1. Drain newly arrived triggers
        if let Ok(rx) = self.rx_triggers.lock() {
            while let Ok(payload) = rx.try_recv() {
                self.queue.push_back(payload);
            }
        }
        self.collapse_if_backlogged();

        // 2. Advance queue if needed
        if self.current.is_none() && !self.queue.is_empty() {
            if let Some(next) = self.queue.pop_front() {
                self.current = Some(ActiveOverlay {
                    payload: next,
                    shown_at: Instant::now(),
                });
                if !self.is_window_visible {
                    ctx.send_viewport_cmd(egui::ViewportCommand::Visible(true));
                    ctx.send_viewport_cmd(egui::ViewportCommand::Focus);
                    self.is_window_visible = true;
                }
                if self.settings.play_sound && !self.settings.sound_file.is_empty() {
                    let sound_path = self.settings.sound_file.clone();
                    std::thread::spawn(move || {
                        let _ = std::process::Command::new("pw-play")
                            .arg(&sound_path)
                            .spawn()
                            .or_else(|_| {
                                std::process::Command::new("aplay")
                                    .arg(&sound_path)
                                    .spawn()
                            });
                    });
                }
            }
        }

        // 3. If nothing is showing, idle with long repaint
        let active = match &self.current {
            Some(a) => a,
            None => {
                ctx.request_repaint_after(Duration::from_millis(250));
                return;
            }
        };

        // 4. Timer evaluation
        let elapsed = active.shown_at.elapsed();
        let total_duration = Duration::from_secs(self.settings.overlay_duration_secs as u64);

        if elapsed >= total_duration {
            self.dismiss_current(ctx);
            return;
        }

        // 5. User Input Dismissal
        let mut should_dismiss = false;
        let mut should_snooze = false;

        ctx.input(|i| {
            if i.key_pressed(egui::Key::Escape) {
                should_dismiss = true;
            }
            if self.settings.allow_snooze && i.key_pressed(egui::Key::Space) {
                should_snooze = true;
            }
            if i.pointer.any_click() {
                should_dismiss = true;
            }
        });

        if should_snooze {
            self.snooze_current(ctx);
            return;
        }

        if should_dismiss {
            self.dismiss_current(ctx);
            return;
        }

        // 6. Rendering
        let screen_rect = ctx.screen_rect();
        let painter = ctx.layer_painter(egui::LayerId::background());

        // Alpha fade-in
        let alpha = if self.style.fade_in_ms > 0 {
            (elapsed.as_millis() as f32 / self.style.fade_in_ms as f32).clamp(0.0, 1.0)
        } else {
            1.0
        };

        match self.settings.overlay_mode {
            OverlayMode::Fullscreen => {
                let mut bg = self.style.bg_color;
                bg = Color32::from_rgba_premultiplied(
                    (bg.r() as f32 * alpha) as u8,
                    (bg.g() as f32 * alpha) as u8,
                    (bg.b() as f32 * alpha) as u8,
                    (bg.a() as f32 * alpha) as u8,
                );
                painter.rect_filled(screen_rect, Rounding::ZERO, bg);
            }
            OverlayMode::CenteredBanner => {
                painter.rect_filled(
                    screen_rect,
                    Rounding::same(self.style.corner_radius),
                    self.style.banner_bg_color,
                );
            }
        }

        // Text & Layout
        let active = match &self.current {
            Some(a) => a,
            None => return,
        };

        let title = &active.payload.title;
        let font_size = if self.settings.overlay_mode == OverlayMode::Fullscreen {
            self.style.title_font_size
        } else {
            36.0
        };

        let center_pos = screen_rect.center();
        let text_color = Color32::from_rgba_premultiplied(
            (self.style.text_color.r() as f32 * alpha) as u8,
            (self.style.text_color.g() as f32 * alpha) as u8,
            (self.style.text_color.b() as f32 * alpha) as u8,
            (self.style.text_color.a() as f32 * alpha) as u8,
        );

        painter.text(
            center_pos - Vec2::new(0.0, 20.0),
            Align2::CENTER_CENTER,
            title,
            FontId::proportional(font_size),
            text_color,
        );

        // Helper text
        let mut helper = "Press Esc or click anywhere to dismiss".to_string();
        if self.settings.allow_snooze {
            helper.push_str(&format!(
                " · Space to snooze ({} min)",
                self.settings.snooze_minutes
            ));
        }

        let muted_color = Color32::from_rgba_premultiplied(
            (self.style.muted_text_color.r() as f32 * alpha) as u8,
            (self.style.muted_text_color.g() as f32 * alpha) as u8,
            (self.style.muted_text_color.b() as f32 * alpha) as u8,
            (self.style.muted_text_color.a() as f32 * alpha) as u8,
        );

        painter.text(
            center_pos + Vec2::new(0.0, 50.0),
            Align2::CENTER_CENTER,
            helper,
            FontId::proportional(self.style.subtitle_font_size),
            muted_color,
        );

        // Progress bar along the bottom edge
        let progress = 1.0 - (elapsed.as_secs_f32() / total_duration.as_secs_f32()).clamp(0.0, 1.0);
        let bar_height = 4.0;
        let bar_rect = Rect::from_min_size(
            Pos2::new(screen_rect.min.x, screen_rect.max.y - bar_height),
            Vec2::new(screen_rect.width() * progress, bar_height),
        );
        painter.rect_filled(bar_rect, Rounding::ZERO, self.style.accent_color);

        ctx.request_repaint_after(Duration::from_millis(100));
    }
}
