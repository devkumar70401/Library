//! Styling constants and configuration for the overlay UI.

use egui::Color32;

#[derive(Debug, Clone)]
pub struct OverlayStyle {
    pub bg_color: Color32,
    pub banner_bg_color: Color32,
    pub text_color: Color32,
    pub accent_color: Color32,
    pub muted_text_color: Color32,
    pub title_font_size: f32,
    pub subtitle_font_size: f32,
    pub corner_radius: f32,
    pub fade_in_ms: u64,
}

impl Default for OverlayStyle {
    fn default() -> Self {
        Self {
            bg_color: Color32::from_rgba_premultiplied(16, 16, 20, 235), // near-black 92% opacity
            banner_bg_color: Color32::from_rgb(16, 16, 20),
            text_color: Color32::from_rgb(245, 245, 240), // warm off-white
            accent_color: Color32::from_rgb(94, 234, 212), // teal #5EEAD4
            muted_text_color: Color32::from_rgb(138, 138, 144), // #8A8A90
            title_font_size: 72.0,
            subtitle_font_size: 18.0,
            corner_radius: 16.0,
            fade_in_ms: 180,
        }
    }
}
