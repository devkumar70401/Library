//! Full-screen and centered banner overlay presentation using eframe.

pub mod app;
pub mod style;
pub mod window;

pub use app::OverlayApp;
pub use style::OverlayStyle;
pub use window::native_options;
