//! ViewportBuilder construction for Fullscreen and CenteredBanner overlay modes.

use crate::config::model::OverlayMode;
use eframe::NativeOptions;
use egui::ViewportBuilder;

pub fn native_options(mode: OverlayMode) -> NativeOptions {
    let viewport = match mode {
        OverlayMode::Fullscreen => ViewportBuilder::default()
            .with_decorations(false)
            .with_always_on_top()
            .with_fullscreen(true)
            .with_transparent(true)
            .with_visible(false)
            .with_taskbar(false),
        OverlayMode::CenteredBanner => ViewportBuilder::default()
            .with_decorations(false)
            .with_always_on_top()
            .with_inner_size([640.0, 220.0])
            .with_transparent(true)
            .with_visible(false)
            .with_taskbar(false),
    };

    NativeOptions {
        viewport,
        vsync: true,
        ..Default::default()
    }
}
