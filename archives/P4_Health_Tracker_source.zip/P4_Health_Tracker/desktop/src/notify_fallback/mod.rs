//! Desktop notification fallback using notify-rust over D-Bus.

pub fn send_fallback(title: &str, body: &str) -> anyhow::Result<()> {
    notify_rust::Notification::new()
        .summary(title)
        .body(body)
        .icon("chronosd")
        .timeout(notify_rust::Timeout::Milliseconds(10_000))
        .urgency(notify_rust::Urgency::Critical)
        .show()?;
    Ok(())
}
