# chronosd

**A local, network-free desktop schedule reminder with full-screen overlay alerts for Ubuntu.**

`chronosd` is a lightweight, always-running background daemon for Ubuntu Linux (X11 & Wayland). It evaluates local wall-clock time against a configured schedule file (`schedule.toml`) and presents unmissable, borderless, always-on-top overlay alerts at exact scheduled boundaries.

---

## Key Features

* **High Precision:** 1-second tick loop, evaluates boundaries within ±1 second.
* **Unmissable Overlays:** Displays full-screen or centered banner overlays above all other windows using `eframe`/`egui`.
* **Zero Network / 100% Private:** No network libraries, no telemetry, no cloud dependency.
* **Live Hot-Reload:** Edits to `schedule.toml` are immediately detected via inotify and hot-reloaded without restarting the process.
* **Grace Period & Catch-Up:** Machine suspend/resume and reboots are handled gracefully using persistent state (`state.json`).
* **Non-Blocking & Dismissable:** Dismiss via `Esc`, screen click, or automatic progress-bar timeout. Snooze support with configurable delays.
* **System Tray & Notification Fallback:** StatusNotifierItem tray menu with Pause/Reload/Quit, and critical desktop notification fallback via `notify-rust` if display servers degrade.

---

## Installation & Build

### 1. System Build Dependencies
```bash
sudo apt update
sudo apt install -y build-essential pkg-config libssl-dev \
    libgtk-3-dev libxcb-render0-dev libxcb-shape0-dev libxcb-xfixes0-dev \
    libxkbcommon-dev libdbus-1-dev
```

### 2. Compile Release Binary
```bash
cargo build --release
mkdir -p ~/.local/bin
cp target/release/chronosd ~/.local/bin/
```

### 3. Setup Autostart
```bash
mkdir -p ~/.config/autostart
cp packaging/chronosd.desktop ~/.config/autostart/
```

*(Alternatively, for systemd user service:)*
```bash
mkdir -p ~/.config/systemd/user
cp systemd/chronosd.service ~/.config/systemd/user/
systemctl --user daemon-reload
systemctl --user enable --now chronosd.service
```

---

## Configuration (`schedule.toml`)

The configuration file is located at `~/.config/chronosd/schedule.toml`. If it does not exist, `chronosd` creates an example configuration on first run.

```toml
[settings]
overlay_duration_secs = 20
overlay_mode          = "fullscreen"   # "fullscreen" | "centered_banner"
allow_snooze          = true
snooze_minutes        = 5
play_sound            = false
sound_file            = ""
grace_period_minutes  = 10
timezone              = "system"

[[entries]]
id      = "morning-routine"
start   = "07:00"
end     = "07:30"
title   = "Morning Routine"
repeat  = "daily"       # "daily" | "weekdays" | "weekends" | "once"
fire_at = "start"       # "start" | "end" | "both"

[[entries]]
id      = "focus-block-1"
start   = "09:00"
end     = "11:00"
title   = "Focus Block"
repeat  = "weekdays"
fire_at = "start"
```

---

## CLI Usage

```bash
chronosd --check-config                   # Validate schedule.toml schema and exit
chronosd --list-today                     # Print today's active schedule and exit
chronosd --config /path/to/custom.toml    # Run with a custom config path
chronosd --verbose                        # Enable debug logging
chronosd --version                        # Print version information
```

---

## Troubleshooting Guide

**"The overlay never appears, but the log shows the trigger fired."**  
Likely cause: the process is running under a systemd user unit that did not inherit `DISPLAY`/`WAYLAND_DISPLAY`/`XAUTHORITY` from the graphical session. Fix by switching to the XDG autostart `.desktop` approach, or by running `systemctl --user import-environment DISPLAY WAYLAND_DISPLAY XAUTHORITY` from a session-startup script before starting the unit. Confirm by running `chronosd` manually from a terminal inside the graphical session.

**"The overlay appears but is hidden behind my full-screen video/game/terminal."**  
This is a documented Wayland compositor limitation. Confirm the `notify_fallback` critical-urgency notification did fire (check the log for `"fallback notification sent"`). If the fallback notification also did not appear, check whether a notification daemon is running at all (`busctl --user list | grep Notifications`).

**"Tray icon doesn't show up."**  
Stock GNOME Shell (46+ on Ubuntu 24.04) does not render `StatusNotifierItem` tray icons without the "AppIndicator and KStatusNotifierItem Support" GNOME Shell extension installed and enabled. This is a well-known GNOME limitation, not a bug in `chronosd`. The app functions fully via config file and CLI flags with no tray icon present.

**"CPU usage is higher than expected."**  
Confirm `ctx.request_repaint_after` is being honored and the overlay isn't accidentally requesting continuous 60fps repaints while idle/hidden. The daemon is tuned to consume < 0.1% CPU.

**"A reminder fired twice in one day."**  
Check the state file at `~/.local/state/chronosd/state.json` for the `fired_today` set contents. Keep `id` values stable across edits to `start`/`end`/`title`.

**"Editing the config file doesn't seem to reload."**  
`chronosd` watches the parent directory for write/rename events with a 300ms debounce window. Confirm your editor is writing to `~/.config/chronosd/schedule.toml`.
