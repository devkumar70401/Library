use chronosd::config::{Loader, Schedule};
use std::path::PathBuf;

#[test]
fn test_load_sample_fixture() {
    let fixture_path = PathBuf::from("tests/fixtures/sample_schedule.toml");
    let loader = Loader::new(fixture_path);
    let schedule = loader
        .load()
        .expect("sample_schedule.toml should parse cleanly");
    assert_eq!(schedule.entries.len(), 5);
    assert_eq!(schedule.settings.overlay_duration_secs, 20);
    assert!(schedule.settings.allow_snooze);
}

#[test]
fn test_duplicate_id_fails() {
    let toml = r#"
[[entries]]
id = "dup"
start = "08:00"
end = "09:00"
title = "First"
repeat = "daily"

[[entries]]
id = "dup"
start = "10:00"
end = "11:00"
title = "Second"
repeat = "daily"
"#;
    let res: Result<Schedule, _> = toml::from_str(toml);
    assert!(res.is_ok());
    let schedule = res.unwrap();
    let val = chronosd::config::loader::validate(&schedule);
    assert!(val.is_err());
}

#[test]
fn test_invalid_window_fails() {
    let toml = r#"
[[entries]]
id = "bad-window"
start = "10:00"
end = "09:00"
title = "Bad"
repeat = "daily"
crosses_midnight = false
"#;
    let schedule: Schedule = toml::from_str(toml).unwrap();
    let val = chronosd::config::loader::validate(&schedule);
    assert!(val.is_err());
}
