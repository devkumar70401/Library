use arc_swap::ArcSwap;
use chrono::{NaiveDate, NaiveTime, TimeZone, Weekday};
use chronosd::config::model::{Entry, FireAt, Repeat, Schedule, Settings};
use chronosd::scheduler::clock::FixedClock;
use chronosd::scheduler::engine::SchedulerEngine;
use chronosd::state::PersistentState;
use std::collections::HashSet;
use std::path::PathBuf;
use std::sync::{Arc, Mutex};

#[test]
fn test_applies_today() {
    assert!(SchedulerEngine::applies_today(&Repeat::Daily, Weekday::Mon));
    assert!(SchedulerEngine::applies_today(&Repeat::Daily, Weekday::Sun));

    assert!(SchedulerEngine::applies_today(
        &Repeat::Weekdays,
        Weekday::Mon
    ));
    assert!(SchedulerEngine::applies_today(
        &Repeat::Weekdays,
        Weekday::Fri
    ));
    assert!(!SchedulerEngine::applies_today(
        &Repeat::Weekdays,
        Weekday::Sat
    ));
    assert!(!SchedulerEngine::applies_today(
        &Repeat::Weekdays,
        Weekday::Sun
    ));

    assert!(!SchedulerEngine::applies_today(
        &Repeat::Weekends,
        Weekday::Wed
    ));
    assert!(SchedulerEngine::applies_today(
        &Repeat::Weekends,
        Weekday::Sat
    ));
    assert!(SchedulerEngine::applies_today(
        &Repeat::Weekends,
        Weekday::Sun
    ));

    assert!(SchedulerEngine::applies_today(&Repeat::Once, Weekday::Tue));
}

#[test]
fn test_boundary_times() {
    let entry_start = Entry {
        id: "t1".into(),
        start: NaiveTime::from_hms_opt(8, 0, 0).unwrap(),
        end: NaiveTime::from_hms_opt(9, 0, 0).unwrap(),
        title: "Test".into(),
        repeat: Repeat::Daily,
        fire_at: FireAt::Start,
        crosses_midnight: false,
    };
    let b1 = SchedulerEngine::boundary_times(&entry_start);
    assert_eq!(b1.len(), 1);
    assert_eq!(
        b1[0],
        (FireAt::Start, NaiveTime::from_hms_opt(8, 0, 0).unwrap())
    );

    let mut entry_both = entry_start.clone();
    entry_both.fire_at = FireAt::Both;
    let b2 = SchedulerEngine::boundary_times(&entry_both);
    assert_eq!(b2.len(), 2);
    assert_eq!(
        b2[0],
        (FireAt::Start, NaiveTime::from_hms_opt(8, 0, 0).unwrap())
    );
    assert_eq!(
        b2[1],
        (FireAt::End, NaiveTime::from_hms_opt(9, 0, 0).unwrap())
    );
}

#[test]
fn test_scheduler_trigger_and_catchup() {
    let schedule = Schedule {
        settings: Settings {
            grace_period_minutes: 10,
            ..Default::default()
        },
        entries: vec![
            Entry {
                id: "morning".into(),
                start: NaiveTime::from_hms_opt(7, 0, 0).unwrap(),
                end: NaiveTime::from_hms_opt(7, 30, 0).unwrap(),
                title: "Morning Routine".into(),
                repeat: Repeat::Daily,
                fire_at: FireAt::Start,
                crosses_midnight: false,
            },
            Entry {
                id: "stale".into(),
                start: NaiveTime::from_hms_opt(5, 0, 0).unwrap(),
                end: NaiveTime::from_hms_opt(6, 0, 0).unwrap(),
                title: "Old task".into(),
                repeat: Repeat::Daily,
                fire_at: FireAt::Start,
                crosses_midnight: false,
            },
        ],
    };

    let schedule_arc = Arc::new(ArcSwap::from_pointee(schedule));
    let state = Arc::new(Mutex::new(PersistentState {
        last_seen_date: Some(NaiveDate::from_ymd_opt(2026, 9, 2).unwrap()),
        fired_today: HashSet::new(),
        consumed_once: HashSet::new(),
    }));

    let (tx, rx) = std::sync::mpsc::channel();
    let test_state_path = PathBuf::from("/tmp/test_chronosd_state.json");

    let initial_dt = chrono::Local.with_ymd_and_hms(2026, 9, 2, 7, 2, 0).unwrap(); // 2 minutes past 07:00 (within 10m grace period)
    let clock = Arc::new(FixedClock::new(initial_dt));

    let mut engine = SchedulerEngine::new(schedule_arc, state.clone(), test_state_path.clone(), tx)
        .with_clock(clock);

    // Evaluate tick
    engine.tick();

    // The 07:00 entry should have triggered because 7:02 is within 10 min grace period!
    let received: Vec<_> = rx.try_iter().collect();
    assert_eq!(received.len(), 1);
    assert_eq!(received[0].entry_id, "morning");

    // The 05:00 entry should NOT trigger because it is 2h2m late (beyond grace period), but it must be marked fired
    let locked_state = state.lock().unwrap();
    assert!(locked_state
        .fired_today
        .contains(&("morning".to_string(), FireAt::Start)));
    assert!(locked_state
        .fired_today
        .contains(&("stale".to_string(), FireAt::Start)));

    let _ = std::fs::remove_file(test_state_path);
}
