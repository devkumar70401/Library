#!/usr/bin/env bash
set -e

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
BIN_DIR="$SCRIPT_DIR/bin"

mkdir -p "$BIN_DIR"

echo "==> Compiling Automated Unit Tests..."
javac -cp "/home/dev/Android/Sdk/platforms/android-34/android.jar:$SCRIPT_DIR/../src" -d "$BIN_DIR" \
    "$SCRIPT_DIR/../src/com/devendra/healthtracker/ScheduleManager.java" \
    "$SCRIPT_DIR/../src/com/devendra/healthtracker/DeviceTelemetryManager.java" \
    "$SCRIPT_DIR/../src/com/devendra/healthtracker/DeepCleanManager.java" \
    "$SCRIPT_DIR/PomodoroStateTest.java" \
    "$SCRIPT_DIR/ChecklistManagerTest.java" \
    "$SCRIPT_DIR/WellbeingHistoryTest.java" \
    "$SCRIPT_DIR/AppEngineTest.java" \
    "$SCRIPT_DIR/ScheduleManagerTest.java" \
    "$SCRIPT_DIR/DeviceTelemetryTest.java" \
    "$SCRIPT_DIR/DeepCleanManagerTest.java" \
    "$SCRIPT_DIR/RunAllTests.java"

echo "==> Running Automated Unit Tests..."
java -cp "$BIN_DIR:/home/dev/Android/Sdk/platforms/android-34/android.jar" com.devendra.healthtracker.tests.RunAllTests
