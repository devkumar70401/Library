package com.devendra.healthtracker;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Build;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

public class ScheduleManager {

    public static final String PREF_NAME = "RoseSchedulePrefs";
    public static final String KEY_WAKE_HOUR = "wake_hour";
    public static final String KEY_WAKE_MIN = "wake_minute";
    public static final String KEY_SLEEP_HOUR = "sleep_hour";
    public static final String KEY_SLEEP_MIN = "sleep_minute";

    public static class Phase {
        public final String id;
        public final int startHour;
        public final int startMinute;
        public final int endHour;
        public final int endMinute;
        public final String romanWindow;
        public final String title;
        public final String decodedProtocol;
        public final String biologicalWhy;

        public Phase(String id, int startHour, int startMinute, int endHour, int endMinute,
                     String romanWindow, String title, String decodedProtocol, String biologicalWhy) {
            this.id = id;
            this.startHour = startHour;
            this.startMinute = startMinute;
            this.endHour = endHour;
            this.endMinute = endMinute;
            this.romanWindow = romanWindow;
            this.title = title;
            this.decodedProtocol = decodedProtocol;
            this.biologicalWhy = biologicalWhy;
        }

        public String getDisplayTitle() {
            if ("phase-08".equals(id)) {
                Calendar now = Calendar.getInstance();
                String timePrefix = formatTime12(startHour, startMinute);
                if (now.get(Calendar.DAY_OF_WEEK) == Calendar.TUESDAY) {
                    return "Evening Fuel: " + timePrefix + " Paneer (Tuesday Zero-Egg)";
                } else {
                    return "Evening Fuel: " + timePrefix + " Eggs & Creatine";
                }
            }
            return title;
        }

        public String getDisplayProtocol() {
            if ("phase-08".equals(id)) {
                Calendar now = Calendar.getInstance();
                if (now.get(Calendar.DAY_OF_WEEK) == Calendar.TUESDAY) {
                    return "Tuesday (Zero-Egg): 80g–100g Fresh Paneer (or Tofu) + Steamed Sprouted Moong + Roasted Chana + 1/2 Lemon + 3–5g Creatine in water.";
                } else {
                    return "3 Whole Boiled Eggs with rock salt & pepper + Steamed Sprouted Moong + Roasted Chana + 1/2 Lemon + 3–5g Creatine in water.";
                }
            }
            return decodedProtocol;
        }

        public String getFormattedTime12() {
            return formatTime12(startHour, startMinute) + " – " + formatTime12(endHour, endMinute);
        }

        public String getFormattedTime24() {
            return String.format("%02d:%02d – %02d:%02d", startHour, startMinute, endHour, endMinute);
        }

        public static String formatTime12(int h, int m) {
            String ampm = h >= 12 ? "PM" : "AM";
            int h12 = h % 12;
            if (h12 == 0) h12 = 12;
            return String.format("%02d:%02d %s", h12, m, ampm);
        }
    }

    public static class PhaseTemplate {
        public final String id;
        public final String title;
        public final String protocol;
        public final String why;
        public final int baseDuration; // in minutes

        public PhaseTemplate(String id, String title, String protocol, String why, int baseDuration) {
            this.id = id;
            this.title = title;
            this.protocol = protocol;
            this.why = why;
            this.baseDuration = baseDuration;
        }
    }

    private static final PhaseTemplate[] WAKING_TEMPLATES = new PhaseTemplate[]{
        new PhaseTemplate(
            "phase-01",
            "Hydrate (500ml) + Sendha Namak + Wakeup",
            "500ml warm/room-temp water + 1/4 tsp Sendha Namak (rock salt) + fresh lemon squeeze.",
            "Rehydrates brain neurons, restores blood volume, and initiates cortisol awakening.",
            30
        ),
        new PhaseTemplate(
            "phase-02",
            "Morning Sunlight (15 min Outdoor)",
            "15–20 minutes direct outdoor sunlight exposure on skin and eyes (no sunglasses).",
            "Resets circadian clock, suppresses residual melatonin, and triggers dopamine synthesis.",
            15
        ),
        new PhaseTemplate(
            "phase-03",
            "Breakfast: Morning Brain Fuel",
            "1 Whole Atta Roti with 1 tbsp 100% Natural PB (or Besan Chilla) + 1 Banana + 4-5 Soaked & Peeled Almonds + 2-3 Walnuts + 1 tbsp Pumpkin Seeds + 1 tbsp Ground Flaxseed + Pre-soaked Chia Tonic.",
            "Supplies L-Tyrosine, Vitamin B6, MUFAs, and magnesium. Soaked & peeled nuts guarantee 90%+ mineral absorption.",
            45
        ),
        new PhaseTemplate(
            "phase-04",
            "Deep Work Block 1 (AI/ML & Core Math)",
            "4-hour uninterrupted flow state: Tensor mathematics, ML model pipelines, and deep debugging. Sip mineralized water.",
            "Peak cognitive executive function powered by morning tyrosine and dopamine reserves with zero insulin volatility.",
            240
        ),
        new PhaseTemplate(
            "phase-05",
            "Lunch: Anti-Coma Power Fuel",
            "50g-60g Soya Chunks (Double-boiled, water dumped, firmly squeezed twice) + Veggies (Cabbage/Carrots/Capsicum) in 1 tsp mustard oil/ghee + 1 Roti + 1/2 Lemon Juice squeeze.",
            "30g clean protein. Fresh Lemon Vitamin C converts non-heme iron to absorbable Fe2+ (+300% gain). Zero palak hassle; egg yolks supply superior retinal lutein.",
            30
        ),
        new PhaseTemplate(
            "phase-06",
            "Post-Lunch 10-Minute Walk",
            "10-15 minutes brisk walking in corridor, room, or terrace. Avoid sitting down immediately.",
            "Translocates muscular GLUT4 glucose transporters, clearing post-meal blood sugar without demanding high insulin.",
            30
        ),
        new PhaseTemplate(
            "phase-07",
            "Deep Work Block 2 (Robotics & Systems)",
            "3-hour technical execution: ROS2 nodes, Isaac Sim, state estimation, and systems architecture.",
            "High cerebral blood flow maintained by post-lunch walk and stable glycemic curve.",
            180
        ),
        new PhaseTemplate(
            "phase-08",
            "Evening Fuel: Eggs & Creatine",
            "WED-MON: 3 Whole Boiled Eggs with rock salt + Steamed Sprouted Moong & Roasted Chana + 1/2 Lemon + 3-5g Creatine in water. (TUESDAY: Replace 3 eggs with 80g-100g Fresh Paneer/Tofu).",
            "420mg Choline for acetylcholine synthesis (spatial memory & ROS transforms) + lutein + DHA + Creatine for brain ATP.",
            60
        ),
        new PhaseTemplate(
            "phase-09",
            "Deep Work Block 3 / Review / Workout",
            "1-hour focused execution: Engineering pull requests, research papers, hardware calibration, or physical training.",
            "Sustained cognitive stamina powered by newly digested acetylcholine precursors and cellular creatine.",
            60
        ),
        new PhaseTemplate(
            "phase-10",
            "1-Hour English Practice & Active Fluency",
            "Active verbal drills: Shadowing native audio, pronunciation/phonetics refinement, technical presentation speaking, and active vocabulary retrieval.",
            "Stimulates Broca's and Wernicke's speech-motor pathways; shifts brain from silent mathematical logic to expressive verbal fluidity and cross-hemispheric communication.",
            60
        ),
        new PhaseTemplate(
            "phase-11",
            "Dinner: Light Khichdi & Curd",
            "Warm Moong Dal Khichdi (2:1 dal-to-rice) + 1 cup Fresh Curd/Dahi. MUST FINISH BEFORE BED.",
            "Supplies dietary tryptophan and probiotics. Curd calcium consumed here without blocking daytime plant iron.",
            30
        ),
        new PhaseTemplate(
            "phase-12",
            "Fasting Gap Before Bed",
            "Displays switched to warm/amber <=15% brightness. Zero calorie intake. Thermal dump walk or reading.",
            "Stomach empties completely. Prevents late-night acid and melatonin suppression.",
            150
        ),
        new PhaseTemplate(
            "phase-13",
            "Night Wind-Down & Hydration",
            "Sip 200ml room-temperature water. Dark environment, cool room temperature.",
            "Lowers core body temperature, signaling hypothalamic sleep center.",
            30
        )
    };

    public static final List<Phase> PHASES = new ArrayList<>();
    private static boolean initialized = false;

    static {
        recalculatePhases(8, 0, 0, 0);
    }

    public static void ensureInitialized(Context context) {
        if (!initialized && context != null) {
            init(context);
        }
    }

    public static synchronized void init(Context context) {
        if (context != null) {
            int wakeH = getWakeHour(context);
            int wakeM = getWakeMinute(context);
            int sleepH = getSleepHour(context);
            int sleepM = getSleepMinute(context);
            recalculatePhases(wakeH, wakeM, sleepH, sleepM);
        } else {
            recalculatePhases(8, 0, 0, 0);
        }
        initialized = true;
    }

    public static int getWakeHour(Context context) {
        if (context == null) return 8;
        return context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE).getInt(KEY_WAKE_HOUR, 8);
    }

    public static int getWakeMinute(Context context) {
        if (context == null) return 0;
        return context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE).getInt(KEY_WAKE_MIN, 0);
    }

    public static int getSleepHour(Context context) {
        if (context == null) return 0;
        return context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE).getInt(KEY_SLEEP_HOUR, 0);
    }

    public static int getSleepMinute(Context context) {
        if (context == null) return 0;
        return context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE).getInt(KEY_SLEEP_MIN, 0);
    }

    public static void setScheduleTimings(Context context, int wakeH, int wakeM, int sleepH, int sleepM) {
        if (context != null) {
            SharedPreferences.Editor editor = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE).edit();
            editor.putInt(KEY_WAKE_HOUR, wakeH);
            editor.putInt(KEY_WAKE_MIN, wakeM);
            editor.putInt(KEY_SLEEP_HOUR, sleepH);
            editor.putInt(KEY_SLEEP_MIN, sleepM);
            editor.apply();
        }
        recalculatePhases(wakeH, wakeM, sleepH, sleepM);
        if (context != null && AppEngineManager.isAppEnabled(context)) {
            scheduleAllAlarms(context);
        }
    }

    public static synchronized void recalculatePhases(int wakeH, int wakeM, int sleepH, int sleepM) {
        PHASES.clear();

        int wakeTotalMin = ((wakeH * 60 + wakeM) % 1440 + 1440) % 1440;
        int sleepTotalMin = ((sleepH * 60 + sleepM) % 1440 + 1440) % 1440;

        int wakingMinutes = (sleepTotalMin - wakeTotalMin + 1440) % 1440;
        if (wakingMinutes <= 0) wakingMinutes = 960; // 16h fallback if identical

        int[] durations = new int[WAKING_TEMPLATES.length];
        int sum = 0;

        for (int i = 0; i < WAKING_TEMPLATES.length; i++) {
            if (wakingMinutes == 960) {
                durations[i] = WAKING_TEMPLATES[i].baseDuration;
            } else {
                float scaled = WAKING_TEMPLATES[i].baseDuration * ((float) wakingMinutes / 960.0f);
                durations[i] = Math.max(5, Math.round(scaled / 5.0f) * 5);
            }
            sum += durations[i];
        }

        // Absorb rounding remainder into primary Deep Work Block 1 (index 3)
        int diff = wakingMinutes - sum;
        durations[3] = Math.max(30, durations[3] + diff);

        int currentMin = wakeTotalMin;
        for (int i = 0; i < WAKING_TEMPLATES.length; i++) {
            int startMin = (currentMin % 1440 + 1440) % 1440;
            int endMin = ((currentMin + durations[i]) % 1440 + 1440) % 1440;
            currentMin += durations[i];

            int sH = startMin / 60;
            int sM = startMin % 60;
            int eH = endMin / 60;
            int eM = endMin % 60;
            String timeStr = Phase.formatTime12(sH, sM) + " – " + Phase.formatTime12(eH, eM);

            PhaseTemplate t = WAKING_TEMPLATES[i];
            PHASES.add(new Phase(t.id, sH, sM, eH, eM, timeStr, t.title, t.protocol, t.why));
        }

        // Phase 14: Deep Sleep (from sleepTotalMin to wakeTotalMin)
        int sleepDurationMin = (wakeTotalMin - sleepTotalMin + 1440) % 1440;
        float sleepHours = Math.round((sleepDurationMin / 60.0f) * 10.0f) / 10.0f;
        String sleepHourStr = (sleepHours == (int) sleepHours) ? String.valueOf((int) sleepHours) : String.format("%.1f", sleepHours);
        String sleepTimeStr = Phase.formatTime12(sleepH, sleepM) + " – " + Phase.formatTime12(wakeH, wakeM);
        String sleepTitle = "Deep Restorative Sleep (" + sleepHourStr + " Hours)";
        String sleepProtocol = sleepHourStr + " hours deep restorative sleep in complete darkness and cool air (" + sleepTimeStr + ").";
        String sleepWhy = "Zero digestion allows the Glymphatic System to expand and flush cerebral metabolic waste.";

        PHASES.add(new Phase("phase-14", sleepH, sleepM, wakeH, wakeM, sleepTimeStr, sleepTitle, sleepProtocol, sleepWhy));
    }

    public static Phase getCurrentPhase() {
        Calendar now = Calendar.getInstance();
        int nowMinutes = now.get(Calendar.HOUR_OF_DAY) * 60 + now.get(Calendar.MINUTE);

        for (Phase p : PHASES) {
            int startMin = p.startHour * 60 + p.startMinute;
            int endMin = p.endHour * 60 + p.endMinute;

            if (startMin > endMin) { // Crosses midnight
                if (nowMinutes >= startMin || nowMinutes < endMin) {
                    return p;
                }
            } else {
                if (nowMinutes >= startMin && nowMinutes < endMin) {
                    return p;
                }
            }
        }
        return null;
    }

    public static Phase getNextPhase() {
        Calendar now = Calendar.getInstance();
        int nowMinutes = now.get(Calendar.HOUR_OF_DAY) * 60 + now.get(Calendar.MINUTE);

        Phase bestNext = null;
        int minDiff = Integer.MAX_VALUE;

        for (Phase p : PHASES) {
            int startMin = p.startHour * 60 + p.startMinute;
            int diff = startMin - nowMinutes;
            if (diff <= 0) diff += 1440; // Next day
            if (diff < minDiff) {
                minDiff = diff;
                bestNext = p;
            }
        }
        return bestNext;
    }

    public static void scheduleAllAlarms(Context context) {
        ensureInitialized(context);
        if (!AppEngineManager.isAppEnabled(context)) {
            return;
        }
        AlarmManager alarmManager = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
        if (alarmManager == null) return;

        Calendar now = Calendar.getInstance();

        for (int i = 0; i < PHASES.size(); i++) {
            Phase p = PHASES.get(i);
            Calendar target = Calendar.getInstance();
            target.set(Calendar.HOUR_OF_DAY, p.startHour);
            target.set(Calendar.MINUTE, p.startMinute);
            target.set(Calendar.SECOND, 0);
            target.set(Calendar.MILLISECOND, 0);

            if (target.before(now)) {
                target.add(Calendar.DAY_OF_YEAR, 1);
            }

            Intent intent = new Intent(context, ReminderReceiver.class);
            intent.setAction("com.devendra.healthtracker.ALARM_TRIGGER");
            intent.putExtra("phase_id", p.id);
            intent.putExtra("title", p.getDisplayTitle());
            intent.putExtra("roman", p.romanWindow);
            intent.putExtra("time", p.getFormattedTime12());
            intent.putExtra("protocol", p.getDisplayProtocol());
            intent.putExtra("request_code", 1000 + i);

            int flags = PendingIntent.FLAG_UPDATE_CURRENT;
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                flags |= PendingIntent.FLAG_IMMUTABLE;
            }

            PendingIntent pi = PendingIntent.getBroadcast(context, 1000 + i, intent, flags);

            boolean canExact = true;
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                canExact = alarmManager.canScheduleExactAlarms();
            }

            try {
                if (canExact && Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                    alarmManager.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, target.getTimeInMillis(), pi);
                } else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                    alarmManager.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, target.getTimeInMillis(), pi);
                } else {
                    alarmManager.set(AlarmManager.RTC_WAKEUP, target.getTimeInMillis(), pi);
                }
            } catch (SecurityException se) {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                    alarmManager.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, target.getTimeInMillis(), pi);
                } else {
                    alarmManager.set(AlarmManager.RTC_WAKEUP, target.getTimeInMillis(), pi);
                }
            }
        }
    }

    public static void cancelAllAlarms(Context context) {
        ensureInitialized(context);
        AlarmManager alarmManager = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
        if (alarmManager == null) return;

        for (int i = 0; i < PHASES.size(); i++) {
            Intent intent = new Intent(context, ReminderReceiver.class);
            intent.setAction("com.devendra.healthtracker.ALARM_TRIGGER");
            int flags = PendingIntent.FLAG_UPDATE_CURRENT;
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                flags |= PendingIntent.FLAG_IMMUTABLE;
            }
            PendingIntent pi = PendingIntent.getBroadcast(context, 1000 + i, intent, flags);
            try {
                alarmManager.cancel(pi);
                pi.cancel();
            } catch (Exception ignored) {}
        }
    }
}
