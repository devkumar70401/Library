package com.devendra.healthtracker;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.TimePickerDialog;
import android.appwidget.AppWidgetManager;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.StateListDrawable;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.util.DisplayMetrics;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

public class MainActivity extends Activity {

    private SnapHorizontalScrollView pager;
    private View[] dotIndicators;
    private int screenWidth;

    // Left Card (Checklist / To-Do) views
    private LinearLayout checklistItemsContainer;
    private EditText checklistInput;
    private String currentChecklistFilter = "ALL";
    private Button filterAllBtn;
    private Button filterActiveBtn;
    private Button filterDoneBtn;
    private TextView checklistStatsText;
    private ProgressBar checklistProgressBar;

    // Master App Engine Top Bar iOS Toggle
    private ModernToggleSwitch topBarSwitch;

    // Circadian Schedule Config views
    private TextView wakeTimeView;
    private TextView sleepTimeView;
    private TextView scheduleSummaryView;

    // Center Card (Cadence) views
    private TextView currentRomanView;
    private TextView currentTitleView;
    private TextView currentCountdownView;
    private TextView currentDirectiveView;
    private TextView currentWhyView;
    private LinearLayout phaseListContainer;

    // Digital Wellbeing views
    private LinearLayout wellbeingListContainer;
    private TextView screenTimeTotalView;
    private TextView focusScoreView;
    private LinearLayout categoryBarContainer;
    private LinearLayout permissionBanner;
    private TextView wbFocusTimeView;
    private TextView wbSessionsView;
    private TextView wbTasksDoneView;
    private TextView wbAppActiveView;
    private LinearLayout sevenDayTrendsContainer;

    // Right Card (Biometrics) views
    private TextView hydrationTextView;
    private ProgressBar hydrationProgressBar;

    // Pomodoro views
    private TextView pomoTimerView;
    private TextView pomoPhaseBadgeView;
    private TextView pomoSessionView;
    private ProgressBar pomoProgressBar;
    private Button pomoToggleBtn;
    private Button pomoSoundToggleBtn;
    private Button pomoNotifToggleBtn;
    private TextView pomoStatsView;
    private TextView pomoParallelDietView;
    private PomodoroManager.OnPomodoroUpdateListener pomoListener;

    // System & Hardware Monitor views
    private TextView sysRamTitleView;
    private TextView sysRamSubtitleView;
    private View sysRamProgressBar;
    private TextView sysRamSubDetailsView;

    private TextView sysStorageTitleView;
    private TextView sysStorageSubtitleView;
    private View sysStorageProgressBar;
    private TextView sysStorageSubDetailsView;

    private TextView sysBatteryLevelView;
    private TextView sysBatteryStatusView;
    private TextView sysBatteryHealthBadgeView;
    private TextView sysBatteryTempView;
    private TextView sysBatteryVoltageView;
    private TextView sysBatteryTechView;

    private TextView sysNetworkCountBadge;
    private TextView sysNetworkSummaryView;
    private LinearLayout sysNetworkListContainer;

    private TextView sysBgAppsCountBadge;
    private LinearLayout sysBgAppsListContainer;
    private List<DeviceTelemetryManager.BackgroundAppInfo> cachedBgApps = new ArrayList<>();

    // Deep System Cleaner (CCleaner) views
    private TextView deepTotalJunkView;
    private TextView deepAppCacheSubView;
    private TextView deepThumbnailSubView;
    private TextView deepTempLogsSubView;
    private TextView perm1StatusView;
    private TextView perm2StatusView;
    private TextView perm3StatusView;
    private Button perm1Btn;
    private Button perm2Btn;
    private Button perm3Btn;
    private LinearLayout deepProgressLayout;
    private TextView deepProgressTitle;
    private ProgressBar deepProgressBar;
    private TextView deepProgressFreed;
    private Button deepProgressStopBtn;
    private Button runDeepCleanBtn;
    private Button runTempPurgeBtn;
    private LinearLayout deepAppListContainer;
    private TextView deepAppsCountBadge;
    private DeepCleanManager.JunkOverview currentJunkOverview;

    private Handler tickerHandler;
    private Runnable tickerRunnable;
    private Handler telemetryHandler;
    private Runnable telemetryTicker;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        if (Build.VERSION.SDK_INT >= 23) {
            getWindow().setStatusBarColor(Color.WHITE);
            getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR);
        }

        DisplayMetrics dm = getResources().getDisplayMetrics();
        screenWidth = dm.widthPixels;

        // Initialize dynamic circadian schedule from preferences
        ScheduleManager.init(this);

        // Ensure background alarms are registered if engine is enabled
        if (AppEngineManager.isAppEnabled(this)) {
            ScheduleManager.scheduleAllAlarms(this);
        }

        // Root vertical layout with clean, aesthetic porcelain white background
        LinearLayout rootLayout = new LinearLayout(this);
        rootLayout.setOrientation(LinearLayout.VERTICAL);
        rootLayout.setBackgroundColor(Color.parseColor("#F8FAFC"));

        // 1. Sleek Minimal Top Bar (Logo + Title + Dot Indicators, NO TAB HEADINGS)
        View topBar = createMinimalTopBar();
        rootLayout.addView(topBar);

        // 2. Horizontal Card Pager (8 Cards: Checklist, Diet, Pomodoro, Wellbeing, System Monitor, Deep Cleaner, Hydration, Blueprint)
        pager = new SnapHorizontalScrollView(this);
        pager.setTotalPages(8);
        LinearLayout.LayoutParams pagerLp = new LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, 0, 1.0f
        );
        pager.setLayoutParams(pagerLp);

        LinearLayout cardsContainer = new LinearLayout(this);
        cardsContainer.setOrientation(LinearLayout.HORIZONTAL);

        // Card 0: Left-Side Checklist & To-Do Flashcard (Emerald Green)
        View checklistPage = wrapInFlashcard(createChecklistContent(), "📝 DAILY CHECKLIST & TO-DO", "#10B981");
        cardsContainer.addView(checklistPage);

        // Card 1: Diet & Daily Routine Flashcard (First - Rose Red)
        View cadencePage = wrapInFlashcard(createCadenceContent(), "🌹 DAILY ROUTINE", "#E11D48");
        cardsContainer.addView(cadencePage);

        // Card 2: Pomodoro Focus Engine Flashcard (Second - Rose Red)
        View pomodoroPage = wrapInFlashcard(createPomodoroContent(), "⏱️ POMODORO FOCUS", "#E11D48");
        cardsContainer.addView(pomodoroPage);

        // Card 3: Digital Wellbeing Flashcard (Third - Sky Blue)
        View wellbeingPage = wrapInFlashcard(createWellbeingContent(), "📊 DIGITAL WELLBEING", "#0284C7");
        cardsContainer.addView(wellbeingPage);

        // Card 4: System & Hardware Monitor Flashcard (Fourth - Electric Indigo)
        View sysMonPage = wrapInFlashcard(createSystemMonitorContent(), "⚡ SYSTEM & HARDWARE MONITOR", "#6366F1");
        cardsContainer.addView(sysMonPage);

        // Card 5: Deep System Cleaner (CCleaner Spec - Deep Teal)
        View deepCleanPage = wrapInFlashcard(createDeepCleanContent(), "🧹 DEEP SYSTEM CLEANER", "#0D9488");
        cardsContainer.addView(deepCleanPage);

        // Card 6: Hydration & Fuel Flashcard (Sixth - Sky Blue)
        View biometricsPage = wrapInFlashcard(createBiometricsContent(), "💧 HYDRATION & FUEL", "#0284C7");
        cardsContainer.addView(biometricsPage);

        // Card 7: Complete Blueprint Flashcard (Seventh - Rose Red)
        View blueprintPage = wrapInFlashcard(createBlueprintContent(), "📖 BRAIN FUEL BLUEPRINT", "#E11D48");
        cardsContainer.addView(blueprintPage);

        pager.addView(cardsContainer);
        rootLayout.addView(pager);

        setContentView(rootLayout);

        // Update dot indicator on page snap
        pager.setOnPageChangeListener(page -> {
            updateDotIndicators(page);
            if (page == 4) {
                refreshSystemMonitorUI();
            } else if (page == 5) {
                refreshDeepCleanUI();
            }
        });

        // Start on requested page without animation on initial load
        int targetPage = 0; // Default to Leftmost Checklist Card
        if (getIntent() != null) {
            if ("pomodoro".equals(getIntent().getStringExtra("targetTab"))) {
                targetPage = 2;
            } else if (getIntent().hasExtra("openPage")) {
                targetPage = getIntent().getIntExtra("openPage", 0);
            }
        }
        final int initialPage = targetPage;
        pager.post(() -> {
            pager.scrollToPage(initialPage, false);
            updateDotIndicators(initialPage);
        });

        // Start live 1-second ticker
        startLiveTicker();
        updateEngineStateUI();
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        if (intent != null && pager != null) {
            int p = 0;
            if ("pomodoro".equals(intent.getStringExtra("targetTab"))) {
                p = 2;
            } else if (intent.hasExtra("openPage")) {
                p = intent.getIntExtra("openPage", 0);
            }
            final int targetPage = p;
            pager.post(() -> {
                pager.scrollToPage(targetPage, true);
                updateDotIndicators(targetPage);
            });
            if (intent.getBooleanExtra("cleanComplete", false)) {
                int count = intent.getIntExtra("cleanedCount", 0);
                long freed = intent.getLongExtra("freedBytes", 0);
                Toast.makeText(this, "🎉 Deep Clean Complete! Freed " + DeepCleanManager.formatBytes(freed) + " across " + count + " apps!", Toast.LENGTH_LONG).show();
            }
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (AppEngineManager.isAppEnabled(this)) {
            startTelemetryTracking();
        }
        refreshChecklistUI();
        refreshWellbeingData();
        refreshHydrationUI();
        refreshSystemMonitorUI();
        refreshDeepCleanUI();
        updateActivePhaseUI();
        pomoListener = (phase, status, remaining, total, completed) -> {
            runOnUiThread(() -> updatePomodoroUI(phase, status, remaining, total, completed));
        };
        PomodoroManager.registerListener(pomoListener);
        refreshPomodoroUI();
        updateSoundControlsUI();
        updateEngineStateUI();
    }

    @Override
    protected void onPause() {
        super.onPause();
        stopTelemetryTracking();
        if (pomoListener != null) {
            PomodoroManager.unregisterListener(pomoListener);
        }
    }

    private void startTelemetryTracking() {
        if (telemetryHandler == null) {
            telemetryHandler = new Handler(Looper.getMainLooper());
        }
        stopTelemetryTracking();
        telemetryTicker = new Runnable() {
            @Override
            public void run() {
                WellbeingHistoryManager.recordActiveAppTime(MainActivity.this, 1);
                if (telemetryHandler != null) {
                    telemetryHandler.postDelayed(this, 60000);
                }
            }
        };
        telemetryHandler.postDelayed(telemetryTicker, 60000);
    }

    private void stopTelemetryTracking() {
        if (telemetryHandler != null && telemetryTicker != null) {
            telemetryHandler.removeCallbacks(telemetryTicker);
            telemetryTicker = null;
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (tickerHandler != null && tickerRunnable != null) {
            tickerHandler.removeCallbacks(tickerRunnable);
        }
    }

    // ==========================================
    // 1. MINIMAL TOP BAR & DOT INDICATORS
    // ==========================================
    private View createMinimalTopBar() {
        LinearLayout bar = new LinearLayout(this);
        bar.setOrientation(LinearLayout.VERTICAL);
        bar.setBackgroundColor(Color.WHITE);

        LinearLayout topRow = new LinearLayout(this);
        topRow.setOrientation(LinearLayout.HORIZONTAL);
        topRow.setGravity(Gravity.CENTER_VERTICAL);
        topRow.setPadding(dp(16), dp(10), dp(16), dp(10));

        ImageView logo = new ImageView(this);
        logo.setImageResource(R.drawable.app_logo);
        LinearLayout.LayoutParams logoLp = new LinearLayout.LayoutParams(dp(32), dp(32));
        logoLp.setMargins(0, 0, dp(10), 0);
        logo.setLayoutParams(logoLp);
        topRow.addView(logo);

        LinearLayout titleCol = new LinearLayout(this);
        titleCol.setOrientation(LinearLayout.HORIZONTAL);
        titleCol.setGravity(Gravity.CENTER_VERTICAL);
        LinearLayout.LayoutParams titleLp = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1.0f);
        titleCol.setLayoutParams(titleLp);

        TextView title = new TextView(this);
        title.setText("ROSE");
        title.setTextSize(16);
        title.setTypeface(Typeface.DEFAULT_BOLD);
        title.setTextColor(Color.parseColor("#0F172A"));
        titleCol.addView(title);

        topBarSwitch = new ModernToggleSwitch(this);
        topBarSwitch.setChecked(AppEngineManager.isAppEnabled(this), false);
        topBarSwitch.setOnCheckedChangeListener((sw, isChecked) -> setAppEngineState(isChecked));
        LinearLayout.LayoutParams swLp = new LinearLayout.LayoutParams(dp(44), dp(26));
        swLp.setMargins(dp(10), 0, 0, 0);
        topBarSwitch.setLayoutParams(swLp);
        titleCol.addView(topBarSwitch);

        topRow.addView(titleCol);

        // 8 Minimal Dots (Checklist, Diet, Pomodoro, Wellbeing, System Monitor, Deep Cleaner, Hydration, Blueprint)
        LinearLayout dotsRow = new LinearLayout(this);
        dotsRow.setOrientation(LinearLayout.HORIZONTAL);
        dotsRow.setGravity(Gravity.CENTER_VERTICAL);

        dotIndicators = new View[8];
        for (int i = 0; i < 8; i++) {
            final int pIndex = i;
            android.widget.FrameLayout slot = new android.widget.FrameLayout(this);
            slot.setPadding(dp(5), dp(10), dp(5), dp(10));
            slot.setClickable(true);
            slot.setFocusable(true);
            slot.setOnClickListener(v -> {
                if (pager != null) {
                    pager.scrollToPage(pIndex, true);
                    updateDotIndicators(pIndex);
                }
            });

            View dot = new View(this);
            android.widget.FrameLayout.LayoutParams dlp = new android.widget.FrameLayout.LayoutParams(dp(8), dp(8), Gravity.CENTER);
            dot.setLayoutParams(dlp);
            dot.setBackground(createPillDrawable(Color.parseColor("#CBD5E1"), dp(4)));
            dotIndicators[i] = dot;

            slot.addView(dot);
            dotsRow.addView(slot);
        }
        topRow.addView(dotsRow);
        bar.addView(topRow);

        View hairline = new View(this);
        hairline.setLayoutParams(new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(1)));
        hairline.setBackgroundColor(Color.parseColor("#F1F5F9"));
        bar.addView(hairline);

        return bar;
    }

    private void updateDotIndicators(int activePage) {
        if (dotIndicators == null) return;
        for (int i = 0; i < 8; i++) {
            if (dotIndicators[i] == null) continue;
            boolean isActive = (i == activePage);
            ViewGroup.LayoutParams lp = dotIndicators[i].getLayoutParams();
            if (isActive) {
                lp.width = dp(22);
                dotIndicators[i].setLayoutParams(lp);
                int color;
                if (activePage == 0) {
                    color = Color.parseColor("#10B981"); // Emerald for Checklist
                } else if (activePage == 1 || activePage == 2 || activePage == 7) {
                    color = Color.parseColor("#E11D48"); // Rose Red for Routine, Pomodoro, Blueprint
                } else if (activePage == 4) {
                    color = Color.parseColor("#6366F1"); // Electric Indigo for System Monitor
                } else if (activePage == 5) {
                    color = Color.parseColor("#0D9488"); // Deep Teal for Deep System Cleaner
                } else {
                    color = Color.parseColor("#0284C7"); // Sky Blue for Wellbeing & Hydration
                }
                dotIndicators[i].setBackground(createPillDrawable(color, dp(4)));
            } else {
                lp.width = dp(8);
                dotIndicators[i].setLayoutParams(lp);
                dotIndicators[i].setBackground(createPillDrawable(Color.parseColor("#CBD5E1"), dp(4)));
            }
        }
    }

    // ==========================================
    // 2. FLASHCARD CONTAINER WRAPPER
    // ==========================================
    private View wrapInFlashcard(View content, String badgeTitle, String accentColor) {
        // Page container: screenWidth width
        LinearLayout pageWrapper = new LinearLayout(this);
        pageWrapper.setOrientation(LinearLayout.VERTICAL);
        pageWrapper.setLayoutParams(new LinearLayout.LayoutParams(screenWidth, ViewGroup.LayoutParams.MATCH_PARENT));
        pageWrapper.setPadding(dp(12), dp(6), dp(12), dp(16));

        // The Physical Flashcard Frame
        LinearLayout cardFrame = new LinearLayout(this);
        cardFrame.setOrientation(LinearLayout.VERTICAL);
        cardFrame.setLayoutParams(new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        // Elevated Pristine White Card Background with 24dp rounded corners and subtle stroke
        GradientDrawable cardBg = new GradientDrawable();
        cardBg.setColor(Color.WHITE);
        cardBg.setCornerRadius(dp(24));
        cardBg.setStroke(dp(1), Color.parseColor("#E2E8F0"));
        cardFrame.setBackground(cardBg);
        cardFrame.setPadding(dp(16), dp(16), dp(16), dp(12));

        // Inner Card Header Pill
        LinearLayout badgeRow = new LinearLayout(this);
        badgeRow.setOrientation(LinearLayout.HORIZONTAL);
        badgeRow.setGravity(Gravity.CENTER_VERTICAL);
        badgeRow.setPadding(0, 0, 0, dp(12));

        TextView badge = new TextView(this);
        badge.setText(badgeTitle);
        badge.setTextSize(10);
        badge.setTypeface(Typeface.DEFAULT_BOLD);
        badge.setTextColor(Color.parseColor(accentColor));
        badge.setPadding(dp(10), dp(4), dp(10), dp(4));

        boolean isRose = accentColor.equalsIgnoreCase("#E11D48") || accentColor.equalsIgnoreCase("#F43F5E");
        boolean isEmerald = accentColor.equalsIgnoreCase("#10B981");
        boolean isIndigo = accentColor.equalsIgnoreCase("#6366F1");
        boolean isTeal = accentColor.equalsIgnoreCase("#0D9488");
        GradientDrawable badgeBg = new GradientDrawable();
        if (isEmerald) {
            badgeBg.setColor(Color.parseColor("#ECFDF5"));
            badgeBg.setStroke(dp(1), Color.parseColor("#A7F3D0"));
        } else if (isRose) {
            badgeBg.setColor(Color.parseColor("#FFF1F2"));
            badgeBg.setStroke(dp(1), Color.parseColor("#FECDD3"));
        } else if (isIndigo) {
            badgeBg.setColor(Color.parseColor("#EEF2FF"));
            badgeBg.setStroke(dp(1), Color.parseColor("#C7D2FE"));
        } else if (isTeal) {
            badgeBg.setColor(Color.parseColor("#F0FDFA"));
            badgeBg.setStroke(dp(1), Color.parseColor("#99F6E4"));
        } else {
            badgeBg.setColor(Color.parseColor("#F0F9FF"));
            badgeBg.setStroke(dp(1), Color.parseColor("#BAE6FD"));
        }
        badgeBg.setCornerRadius(dp(12));
        badge.setBackground(badgeBg);
        badgeRow.addView(badge);

        cardFrame.addView(badgeRow);

        // Scrollable content inside the card
        ScrollView scroll = new ScrollView(this);
        scroll.setLayoutParams(new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1.0f));
        scroll.setVerticalScrollBarEnabled(false);
        scroll.addView(content);
        cardFrame.addView(scroll);

        pageWrapper.addView(cardFrame);
        return pageWrapper;
    }

    // ==========================================
    // 2B. CARD 0: CHECKLIST & TO-DO CONTENT
    // ==========================================
    private View createChecklistContent() {
        LinearLayout content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setPadding(0, 0, 0, dp(24));

        // Header summary card
        LinearLayout summaryCard = createCardLayout(Color.WHITE, Color.parseColor("#E2E8F0"));
        summaryCard.setPadding(dp(16), dp(14), dp(16), dp(14));
        summaryCard.setOrientation(LinearLayout.VERTICAL);

        TextView headerTitle = new TextView(this);
        headerTitle.setText("TASK & SHOPPING MATRIX");
        headerTitle.setTextSize(11);
        headerTitle.setTypeface(Typeface.DEFAULT_BOLD);
        headerTitle.setTextColor(Color.parseColor("#10B981"));
        summaryCard.addView(headerTitle);

        checklistStatsText = new TextView(this);
        checklistStatsText.setText("0 of 0 tasks completed");
        checklistStatsText.setTextSize(14);
        checklistStatsText.setTypeface(Typeface.DEFAULT_BOLD);
        checklistStatsText.setTextColor(Color.parseColor("#0F172A"));
        checklistStatsText.setPadding(0, dp(2), 0, dp(6));
        summaryCard.addView(checklistStatsText);

        checklistProgressBar = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
        checklistProgressBar.setMax(100);
        checklistProgressBar.setProgress(0);
        checklistProgressBar.setProgressTintList(ColorStateList.valueOf(Color.parseColor("#10B981")));
        checklistProgressBar.setProgressBackgroundTintList(ColorStateList.valueOf(Color.parseColor("#E2E8F0")));
        LinearLayout.LayoutParams pbLp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(6));
        checklistProgressBar.setLayoutParams(pbLp);
        summaryCard.addView(checklistProgressBar);

        content.addView(summaryCard);

        // Quick Add Box
        LinearLayout addCard = createCardLayout(Color.WHITE, Color.parseColor("#CBD5E1"));
        addCard.setOrientation(LinearLayout.HORIZONTAL);
        addCard.setGravity(Gravity.CENTER_VERTICAL);
        addCard.setPadding(dp(12), dp(8), dp(12), dp(8));
        LinearLayout.LayoutParams addLp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        addLp.setMargins(0, dp(12), 0, dp(12));
        addCard.setLayoutParams(addLp);

        checklistInput = new EditText(this);
        checklistInput.setHint("Add task, grocery item, or idea...");
        checklistInput.setHintTextColor(Color.parseColor("#94A3B8"));
        checklistInput.setTextColor(Color.parseColor("#0F172A"));
        checklistInput.setTextSize(13);
        checklistInput.setBackgroundColor(Color.TRANSPARENT);
        checklistInput.setSingleLine(true);
        checklistInput.setImeOptions(EditorInfo.IME_ACTION_DONE);
        checklistInput.setOnEditorActionListener((v, actionId, event) -> {
            addChecklistItem();
            return true;
        });
        LinearLayout.LayoutParams inLp = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1.0f);
        checklistInput.setLayoutParams(inLp);
        addCard.addView(checklistInput);

        Button addBtn = createStyledButton("+ Add", Color.parseColor("#10B981"));
        addBtn.setPadding(dp(14), dp(8), dp(14), dp(8));
        addBtn.setOnClickListener(v -> addChecklistItem());
        addCard.addView(addBtn);

        content.addView(addCard);

        // Filter Bar (All / Active / Done)
        LinearLayout filterBar = new LinearLayout(this);
        filterBar.setOrientation(LinearLayout.HORIZONTAL);
        filterBar.setPadding(dp(2), 0, dp(2), dp(10));

        filterAllBtn = createFilterButton("All (0)", "ALL");
        filterActiveBtn = createFilterButton("Active (0)", "ACTIVE");
        filterDoneBtn = createFilterButton("Done (0)", "COMPLETED");

        filterBar.addView(filterAllBtn);
        filterBar.addView(filterActiveBtn);
        filterBar.addView(filterDoneBtn);
        content.addView(filterBar);

        // Tasks Container
        checklistItemsContainer = new LinearLayout(this);
        checklistItemsContainer.setOrientation(LinearLayout.VERTICAL);
        content.addView(checklistItemsContainer);

        // Clear completed button
        Button clearBtn = createOutlinedButton("🗑️ Clear Completed Items", Color.parseColor("#DC2626"), Color.parseColor("#FECDD3"));
        LinearLayout.LayoutParams cbLp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        cbLp.setMargins(0, dp(14), 0, 0);
        clearBtn.setLayoutParams(cbLp);
        clearBtn.setOnClickListener(v -> {
            int removed = ChecklistManager.clearCompleted(this);
            Toast.makeText(this, removed > 0 ? ("Cleared " + removed + " completed items") : "No completed items to clear", Toast.LENGTH_SHORT).show();
            refreshChecklistUI();
            refreshWellbeingData();
        });
        content.addView(clearBtn);

        return content;
    }

    private Button createFilterButton(String text, String filterKey) {
        Button b = new Button(this);
        b.setText(text);
        b.setTextSize(11);
        b.setTypeface(Typeface.DEFAULT_BOLD);
        b.setAllCaps(false);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1.0f);
        lp.setMargins(dp(2), 0, dp(2), 0);
        b.setLayoutParams(lp);
        b.setPadding(dp(4), dp(6), dp(4), dp(6));
        updateFilterButtonAppearance(b, filterKey);
        b.setOnClickListener(v -> {
            currentChecklistFilter = filterKey;
            updateFilterButtonAppearance(filterAllBtn, "ALL");
            updateFilterButtonAppearance(filterActiveBtn, "ACTIVE");
            updateFilterButtonAppearance(filterDoneBtn, "COMPLETED");
            refreshChecklistUI();
        });
        return b;
    }

    private void updateFilterButtonAppearance(Button b, String filterKey) {
        if (b == null) return;
        boolean isSelected = filterKey.equals(currentChecklistFilter);
        if (isSelected) {
            b.setBackground(createPillDrawable(Color.parseColor("#10B981"), dp(8)));
            b.setTextColor(Color.WHITE);
        } else {
            b.setBackground(createOutlinedDrawable(Color.WHITE, Color.parseColor("#CBD5E1"), dp(8)));
            b.setTextColor(Color.parseColor("#64748B"));
        }
    }

    private void addChecklistItem() {
        if (checklistInput == null) return;
        String text = checklistInput.getText().toString().trim();
        if (text.isEmpty()) return;
        ChecklistManager.addItem(this, text);
        checklistInput.setText("");
        InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
        if (imm != null) {
            imm.hideSoftInputFromWindow(checklistInput.getWindowToken(), 0);
        }
        refreshChecklistUI();
        refreshWellbeingData();
    }

    private void refreshChecklistUI() {
        if (checklistItemsContainer == null) return;
        checklistItemsContainer.removeAllViews();

        List<ChecklistItem> all = ChecklistManager.getItems(this);
        int total = all.size();
        int completed = 0;
        for (ChecklistItem i : all) {
            if (i.completed) completed++;
        }
        int active = total - completed;

        if (checklistStatsText != null) {
            int pct = total > 0 ? (completed * 100 / total) : 0;
            checklistStatsText.setText(completed + " of " + total + " tasks completed (" + pct + "%)");
        }
        if (checklistProgressBar != null) {
            int pct = total > 0 ? (completed * 100 / total) : 0;
            checklistProgressBar.setProgress(pct);
        }

        if (filterAllBtn != null) filterAllBtn.setText("All (" + total + ")");
        if (filterActiveBtn != null) filterActiveBtn.setText("Active (" + active + ")");
        if (filterDoneBtn != null) filterDoneBtn.setText("Done (" + completed + ")");

        List<ChecklistItem> displayed = ChecklistManager.filter(all, currentChecklistFilter);

        if (displayed.isEmpty()) {
            LinearLayout emptyCard = createCardLayout(Color.WHITE, Color.parseColor("#E2E8F0"));
            emptyCard.setPadding(dp(16), dp(20), dp(16), dp(20));
            emptyCard.setGravity(Gravity.CENTER);
            emptyCard.setOrientation(LinearLayout.VERTICAL);

            TextView icon = new TextView(this);
            icon.setText("📋");
            icon.setTextSize(28);
            icon.setGravity(Gravity.CENTER);
            emptyCard.addView(icon);

            TextView emptyTitle = new TextView(this);
            emptyTitle.setText("No items in this list");
            emptyTitle.setTextSize(13);
            emptyTitle.setTypeface(Typeface.DEFAULT_BOLD);
            emptyTitle.setTextColor(Color.parseColor("#64748B"));
            emptyTitle.setGravity(Gravity.CENTER);
            emptyTitle.setPadding(0, dp(4), 0, 0);
            emptyCard.addView(emptyTitle);

            TextView emptyDesc = new TextView(this);
            emptyDesc.setText("Add tasks above to organize your day.");
            emptyDesc.setTextSize(11);
            emptyDesc.setTextColor(Color.parseColor("#94A3B8"));
            emptyDesc.setGravity(Gravity.CENTER);
            emptyCard.addView(emptyDesc);

            checklistItemsContainer.addView(emptyCard);
            return;
        }

        for (ChecklistItem item : displayed) {
            LinearLayout row = createCardLayout(Color.WHITE, Color.parseColor(item.completed ? "#F8FAFC" : "#FFFFFF"));
            row.setOrientation(LinearLayout.HORIZONTAL);
            row.setGravity(Gravity.CENTER_VERTICAL);
            row.setPadding(dp(12), dp(10), dp(12), dp(10));
            LinearLayout.LayoutParams rlp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            rlp.setMargins(0, 0, 0, dp(8));
            row.setLayoutParams(rlp);

            // Checkbox / Check circle button
            Button checkBtn = new Button(this);
            checkBtn.setText(item.completed ? "✓" : "");
            checkBtn.setTextSize(12);
            checkBtn.setTypeface(Typeface.DEFAULT_BOLD);
            checkBtn.setTextColor(Color.WHITE);
            LinearLayout.LayoutParams cbLp = new LinearLayout.LayoutParams(dp(28), dp(28));
            cbLp.setMargins(0, 0, dp(10), 0);
            checkBtn.setLayoutParams(cbLp);
            checkBtn.setPadding(0, 0, 0, 0);
            if (item.completed) {
                checkBtn.setBackground(createPillDrawable(Color.parseColor("#10B981"), dp(14)));
            } else {
                checkBtn.setBackground(createOutlinedDrawable(Color.WHITE, Color.parseColor("#CBD5E1"), dp(14)));
            }
            checkBtn.setOnClickListener(v -> {
                ChecklistManager.toggleItem(this, item.id);
                refreshChecklistUI();
                refreshWellbeingData();
            });
            row.addView(checkBtn);

            // Text title
            TextView titleView = new TextView(this);
            titleView.setText(item.title);
            titleView.setTextSize(13);
            if (item.completed) {
                titleView.setPaintFlags(titleView.getPaintFlags() | Paint.STRIKE_THRU_TEXT_FLAG);
                titleView.setTextColor(Color.parseColor("#94A3B8"));
            } else {
                titleView.setPaintFlags(titleView.getPaintFlags() & (~Paint.STRIKE_THRU_TEXT_FLAG));
                titleView.setTextColor(Color.parseColor("#0F172A"));
                titleView.setTypeface(Typeface.DEFAULT_BOLD);
            }
            LinearLayout.LayoutParams tvLp = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1.0f);
            titleView.setLayoutParams(tvLp);
            titleView.setOnClickListener(v -> {
                ChecklistManager.toggleItem(this, item.id);
                refreshChecklistUI();
                refreshWellbeingData();
            });
            row.addView(titleView);

            // Delete Button (✕)
            TextView delBtn = new TextView(this);
            delBtn.setText("✕");
            delBtn.setTextSize(14);
            delBtn.setTypeface(Typeface.DEFAULT_BOLD);
            delBtn.setTextColor(Color.parseColor("#94A3B8"));
            delBtn.setPadding(dp(8), dp(4), dp(8), dp(4));
            delBtn.setOnClickListener(v -> {
                ChecklistManager.deleteItem(this, item.id);
                refreshChecklistUI();
            });
            row.addView(delBtn);

            checklistItemsContainer.addView(row);
        }
    }

    private GradientDrawable createOutlinedDrawable(int bgColor, int strokeColor, int radius) {
        GradientDrawable gd = new GradientDrawable();
        gd.setColor(bgColor);
        gd.setCornerRadius(radius);
        gd.setStroke(dp(1), strokeColor);
        return gd;
    }

    // ==========================================
    // 3. CARD 0: DIGITAL WELLBEING CONTENT
    // ==========================================
    private View createWellbeingContent() {
        LinearLayout content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setPadding(0, 0, 0, dp(24));

        // Permission Notice
        permissionBanner = createCardLayout(Color.parseColor("#FFF7ED"), Color.parseColor("#FED7AA"));
        permissionBanner.setPadding(dp(12), dp(10), dp(12), dp(10));
        permissionBanner.setOrientation(LinearLayout.VERTICAL);

        TextView permTitle = new TextView(this);
        permTitle.setText("⚠️ Live App Usage Access Required");
        permTitle.setTextSize(11);
        permTitle.setTypeface(Typeface.DEFAULT_BOLD);
        permTitle.setTextColor(Color.parseColor("#C2410C"));
        permissionBanner.addView(permTitle);

        TextView permDesc = new TextView(this);
        permDesc.setText("Grant Usage Access in Android Settings to read real-time screen telemetry.");
        permDesc.setTextSize(10);
        permDesc.setTextColor(Color.parseColor("#9A3412"));
        permDesc.setPadding(0, dp(2), 0, dp(6));
        permissionBanner.addView(permDesc);

        Button permBtn = createStyledButton("Grant Usage Permission", Color.parseColor("#EA580C"));
        permBtn.setOnClickListener(v -> {
            try {
                startActivity(new Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS));
            } catch (Exception e) {
                Toast.makeText(this, "Could not open usage settings", Toast.LENGTH_SHORT).show();
            }
        });
        permissionBanner.addView(permBtn);
        content.addView(permissionBanner);

        // 1. Hero Today Wellbeing Telemetry Card (Multi-Metric Daily Aggregation)
        LinearLayout todayCard = createCardLayout(Color.WHITE, Color.parseColor("#E2E8F0"));
        todayCard.setPadding(dp(16), dp(14), dp(16), dp(14));
        todayCard.setOrientation(LinearLayout.VERTICAL);

        TextView todayHeader = new TextView(this);
        todayHeader.setText("TODAY'S WELLBEING TELEMETRY");
        todayHeader.setTextSize(10);
        todayHeader.setTypeface(Typeface.DEFAULT_BOLD);
        todayHeader.setTextColor(Color.parseColor("#0284C7"));
        todayCard.addView(todayHeader);

        TextView todaySub = new TextView(this);
        todaySub.setText("Daily aggregation: Focus, completed tasks & app session engagement");
        todaySub.setTextSize(10);
        todaySub.setTextColor(Color.parseColor("#64748B"));
        todaySub.setPadding(0, dp(1), 0, dp(10));
        todayCard.addView(todaySub);

        // 2x2 Metric Tiles Grid
        LinearLayout gridRow1 = new LinearLayout(this);
        gridRow1.setOrientation(LinearLayout.HORIZONTAL);
        gridRow1.setPadding(0, 0, 0, dp(8));

        LinearLayout tileFocus = createMetricTile("⏱️ FOCUS TIME", "#0284C7");
        wbFocusTimeView = (TextView) tileFocus.getChildAt(1);
        LinearLayout.LayoutParams tflp = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1.0f);
        tflp.setMargins(0, 0, dp(4), 0);
        tileFocus.setLayoutParams(tflp);
        gridRow1.addView(tileFocus);

        LinearLayout tileSessions = createMetricTile("🍅 SESSIONS", "#E11D48");
        wbSessionsView = (TextView) tileSessions.getChildAt(1);
        LinearLayout.LayoutParams tslp = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1.0f);
        tslp.setMargins(dp(4), 0, 0, 0);
        tileSessions.setLayoutParams(tslp);
        gridRow1.addView(tileSessions);
        todayCard.addView(gridRow1);

        LinearLayout gridRow2 = new LinearLayout(this);
        gridRow2.setOrientation(LinearLayout.HORIZONTAL);

        LinearLayout tileTasks = createMetricTile("✅ TASKS DONE", "#10B981");
        wbTasksDoneView = (TextView) tileTasks.getChildAt(1);
        LinearLayout.LayoutParams ttlp = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1.0f);
        ttlp.setMargins(0, 0, dp(4), 0);
        tileTasks.setLayoutParams(ttlp);
        gridRow2.addView(tileTasks);

        LinearLayout tileActive = createMetricTile("📱 IN-APP ACTIVE", "#8B5CF6");
        wbAppActiveView = (TextView) tileActive.getChildAt(1);
        LinearLayout.LayoutParams talp = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1.0f);
        talp.setMargins(dp(4), 0, 0, 0);
        tileActive.setLayoutParams(talp);
        gridRow2.addView(tileActive);
        todayCard.addView(gridRow2);

        content.addView(todayCard);

        // 2. 7-Day Activity & Focus Trends Card (Rolling History)
        LinearLayout trendsCard = createCardLayout(Color.WHITE, Color.parseColor("#E2E8F0"));
        trendsCard.setPadding(dp(16), dp(14), dp(16), dp(14));
        trendsCard.setOrientation(LinearLayout.VERTICAL);
        LinearLayout.LayoutParams tclp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        tclp.setMargins(0, dp(12), 0, dp(12));
        trendsCard.setLayoutParams(tclp);

        TextView trendsHeader = new TextView(this);
        trendsHeader.setText("7-DAY ACTIVITY & FOCUS TRENDS");
        trendsHeader.setTextSize(10);
        trendsHeader.setTypeface(Typeface.DEFAULT_BOLD);
        trendsHeader.setTextColor(Color.parseColor("#0284C7"));
        trendsCard.addView(trendsHeader);

        TextView trendsSub = new TextView(this);
        trendsSub.setText("Daily rolling history & rollover (30-day retention engine)");
        trendsSub.setTextSize(10);
        trendsSub.setTextColor(Color.parseColor("#64748B"));
        trendsSub.setPadding(0, dp(1), 0, dp(10));
        trendsCard.addView(trendsSub);

        sevenDayTrendsContainer = new LinearLayout(this);
        sevenDayTrendsContainer.setOrientation(LinearLayout.VERTICAL);
        trendsCard.addView(sevenDayTrendsContainer);

        content.addView(trendsCard);

        // Hero Screen Time Metric (Aesthetic Sky Blue Card)
        LinearLayout heroCard = createCardLayout(Color.parseColor("#F0F9FF"), Color.parseColor("#BAE6FD"));
        heroCard.setPadding(dp(16), dp(14), dp(16), dp(14));
        heroCard.setOrientation(LinearLayout.VERTICAL);

        TextView heroLabel = new TextView(this);
        heroLabel.setText("SYSTEM DEVICE SCREEN TIME");
        heroLabel.setTextSize(10);
        heroLabel.setTypeface(Typeface.DEFAULT_BOLD);
        heroLabel.setTextColor(Color.parseColor("#0284C7"));
        heroCard.addView(heroLabel);

        screenTimeTotalView = new TextView(this);
        screenTimeTotalView.setText("3h 48m");
        screenTimeTotalView.setTextSize(30);
        screenTimeTotalView.setTypeface(Typeface.DEFAULT_BOLD);
        screenTimeTotalView.setTextColor(Color.parseColor("#0F172A"));
        screenTimeTotalView.setPadding(0, dp(2), 0, dp(2));
        heroCard.addView(screenTimeTotalView);

        focusScoreView = new TextView(this);
        focusScoreView.setText("⚡ Dopamine Score: 84/100 · High Discipline");
        focusScoreView.setTextSize(11);
        focusScoreView.setTextColor(Color.parseColor("#059669"));
        heroCard.addView(focusScoreView);

        content.addView(heroCard);

        // Category Breakdown Bar
        TextView catHeader = new TextView(this);
        catHeader.setText("TIME DISTRIBUTION BY CATEGORY");
        catHeader.setTextSize(10);
        catHeader.setTypeface(Typeface.DEFAULT_BOLD);
        catHeader.setTextColor(Color.parseColor("#64748B"));
        catHeader.setPadding(dp(2), dp(14), 0, dp(6));
        content.addView(catHeader);

        categoryBarContainer = new LinearLayout(this);
        categoryBarContainer.setOrientation(LinearLayout.HORIZONTAL);
        categoryBarContainer.setPadding(0, 0, 0, dp(10));
        content.addView(categoryBarContainer);

        // App Telemetry List
        TextView appsHeader = new TextView(this);
        appsHeader.setText("APPLICATION USAGE TELEMETRY");
        appsHeader.setTextSize(10);
        appsHeader.setTypeface(Typeface.DEFAULT_BOLD);
        appsHeader.setTextColor(Color.parseColor("#64748B"));
        appsHeader.setPadding(dp(2), dp(6), 0, dp(8));
        content.addView(appsHeader);

        wellbeingListContainer = new LinearLayout(this);
        wellbeingListContainer.setOrientation(LinearLayout.VERTICAL);
        content.addView(wellbeingListContainer);

        return content;
    }

    private LinearLayout createMetricTile(String label, String colorHex) {
        LinearLayout tile = createCardLayout(Color.parseColor("#F8FAFC"), Color.parseColor("#E2E8F0"));
        tile.setPadding(dp(10), dp(8), dp(10), dp(8));
        tile.setOrientation(LinearLayout.VERTICAL);

        TextView lbl = new TextView(this);
        lbl.setText(label);
        lbl.setTextSize(9);
        lbl.setTypeface(Typeface.DEFAULT_BOLD);
        lbl.setTextColor(Color.parseColor(colorHex));
        tile.addView(lbl);

        TextView val = new TextView(this);
        val.setText("0");
        val.setTextSize(18);
        val.setTypeface(Typeface.DEFAULT_BOLD);
        val.setTextColor(Color.parseColor("#0F172A"));
        val.setPadding(0, dp(2), 0, 0);
        tile.addView(val);

        return tile;
    }

    private void refreshWellbeingData() {
        // 1. Refresh In-App Telemetry & Trends
        DailyWellbeingRecord todayRec = WellbeingHistoryManager.getTodayRecord(this);
        if (wbFocusTimeView != null) {
            wbFocusTimeView.setText(todayRec.totalFocusMinutes + "m");
        }
        if (wbSessionsView != null) {
            wbSessionsView.setText(todayRec.completedPomodoros + " done");
        }
        if (wbTasksDoneView != null) {
            wbTasksDoneView.setText(todayRec.tasksCompleted + " tasks");
        }
        if (wbAppActiveView != null) {
            wbAppActiveView.setText(todayRec.activeAppMinutes + "m");
        }

        if (sevenDayTrendsContainer != null) {
            sevenDayTrendsContainer.removeAllViews();
            List<DailyWellbeingRecord> pastDays = WellbeingHistoryManager.getPastDays(this, 7);
            int maxFocus = 60;
            for (DailyWellbeingRecord d : pastDays) {
                if (d.totalFocusMinutes > maxFocus) maxFocus = d.totalFocusMinutes;
            }

            String todayStr = WellbeingHistoryManager.getTodayDateString();
            SimpleDateFormat inFormat = new SimpleDateFormat("yyyy-MM-dd", Locale.US);
            SimpleDateFormat outFormat = new SimpleDateFormat("EEE dd", Locale.US);

            for (DailyWellbeingRecord d : pastDays) {
                LinearLayout dayRow = new LinearLayout(this);
                dayRow.setOrientation(LinearLayout.HORIZONTAL);
                dayRow.setGravity(Gravity.CENTER_VERTICAL);
                dayRow.setPadding(0, dp(4), 0, dp(4));

                boolean isToday = todayStr.equals(d.date);
                String displayDate;
                try {
                    Date parsed = inFormat.parse(d.date);
                    displayDate = isToday ? "Today" : outFormat.format(parsed);
                } catch (Exception e) {
                    displayDate = d.date;
                }

                TextView dayLabel = new TextView(this);
                dayLabel.setText(displayDate);
                dayLabel.setTextSize(11);
                dayLabel.setTypeface(Typeface.DEFAULT_BOLD);
                dayLabel.setTextColor(Color.parseColor(isToday ? "#E11D48" : "#475569"));
                LinearLayout.LayoutParams dlp = new LinearLayout.LayoutParams(dp(54), ViewGroup.LayoutParams.WRAP_CONTENT);
                dayLabel.setLayoutParams(dlp);
                dayRow.addView(dayLabel);

                ProgressBar bar = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
                bar.setMax(maxFocus);
                bar.setProgress(d.totalFocusMinutes);
                bar.setProgressTintList(ColorStateList.valueOf(Color.parseColor(isToday ? "#E11D48" : "#38BDF8")));
                bar.setProgressBackgroundTintList(ColorStateList.valueOf(Color.parseColor("#F1F5F9")));
                LinearLayout.LayoutParams blp = new LinearLayout.LayoutParams(0, dp(6), 1.0f);
                blp.setMargins(dp(6), 0, dp(8), 0);
                bar.setLayoutParams(blp);
                dayRow.addView(bar);

                TextView statsLabel = new TextView(this);
                statsLabel.setText(d.totalFocusMinutes + "m · ✅ " + d.tasksCompleted + " · 🍅 " + d.completedPomodoros);
                statsLabel.setTextSize(10);
                statsLabel.setTextColor(Color.parseColor("#64748B"));
                statsLabel.setGravity(Gravity.END);
                LinearLayout.LayoutParams slp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
                statsLabel.setLayoutParams(slp);
                dayRow.addView(statsLabel);

                sevenDayTrendsContainer.addView(dayRow);
            }
        }

        // 2. Refresh Device App Usage
        boolean hasPerm = WellbeingManager.hasUsageStatsPermission(this);
        if (permissionBanner != null) {
            permissionBanner.setVisibility(hasPerm ? View.GONE : View.VISIBLE);
        }

        List<WellbeingManager.AppUsageInfo> apps = WellbeingManager.getTodayAppUsage(this);
        long totalMillis = WellbeingManager.getTotalScreenTime(apps);
        if (screenTimeTotalView != null) {
            screenTimeTotalView.setText(WellbeingManager.formatDuration(totalMillis));
        }

        if (wellbeingListContainer == null) return;
        wellbeingListContainer.removeAllViews();

        long maxTime = apps.isEmpty() ? 1 : apps.get(0).totalTimeMillis;

        // Render Category Breakdown Bars
        if (categoryBarContainer != null) {
            categoryBarContainer.removeAllViews();
            Map<String, Long> catSums = new HashMap<>();
            for (WellbeingManager.AppUsageInfo a : apps) {
                catSums.put(a.category, catSums.getOrDefault(a.category, 0L) + a.totalTimeMillis);
            }

            for (Map.Entry<String, Long> entry : catSums.entrySet()) {
                float weight = (float) entry.getValue() / (float) (totalMillis > 0 ? totalMillis : 1);
                View barSlice = new View(this);
                LinearLayout.LayoutParams slp = new LinearLayout.LayoutParams(0, dp(6), Math.max(0.05f, weight));
                slp.setMargins(dp(1), 0, dp(1), 0);
                barSlice.setLayoutParams(slp);
                barSlice.setBackgroundColor(WellbeingManager.getCategoryColor(entry.getKey()));
                categoryBarContainer.addView(barSlice);
            }
        }

        // Render Individual App Cards (Clean White Cards with subtle borders)
        for (WellbeingManager.AppUsageInfo app : apps) {
            LinearLayout item = createCardLayout(Color.WHITE, Color.parseColor("#E2E8F0"));
            item.setOrientation(LinearLayout.VERTICAL);
            item.setPadding(dp(12), dp(10), dp(12), dp(10));
            LinearLayout.LayoutParams ilp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            ilp.setMargins(0, 0, 0, dp(8));
            item.setLayoutParams(ilp);

            LinearLayout topRow = new LinearLayout(this);
            topRow.setOrientation(LinearLayout.HORIZONTAL);
            topRow.setGravity(Gravity.CENTER_VERTICAL);

            if (app.icon != null) {
                ImageView iv = new ImageView(this);
                iv.setImageDrawable(app.icon);
                LinearLayout.LayoutParams ivLp = new LinearLayout.LayoutParams(dp(26), dp(26));
                ivLp.setMargins(0, 0, dp(10), 0);
                iv.setLayoutParams(ivLp);
                topRow.addView(iv);
            } else {
                TextView dot = new TextView(this);
                dot.setText("●");
                dot.setTextSize(14);
                dot.setTextColor(app.categoryColor);
                dot.setPadding(0, 0, dp(8), 0);
                topRow.addView(dot);
            }

            TextView appNameView = new TextView(this);
            appNameView.setText(app.appName);
            appNameView.setTextSize(13);
            appNameView.setTypeface(Typeface.DEFAULT_BOLD);
            appNameView.setTextColor(Color.parseColor("#0F172A"));
            LinearLayout.LayoutParams nameLp = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1.0f);
            appNameView.setLayoutParams(nameLp);
            topRow.addView(appNameView);

            TextView timeView = new TextView(this);
            timeView.setText(WellbeingManager.formatDuration(app.totalTimeMillis));
            timeView.setTextSize(12);
            timeView.setTypeface(Typeface.DEFAULT_BOLD);
            timeView.setTextColor(Color.parseColor("#0284C7"));
            topRow.addView(timeView);

            item.addView(topRow);

            LinearLayout barRow = new LinearLayout(this);
            barRow.setOrientation(LinearLayout.HORIZONTAL);
            barRow.setGravity(Gravity.CENTER_VERTICAL);
            barRow.setPadding(0, dp(6), 0, 0);

            ProgressBar pb = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
            pb.setMax(100);
            int percent = (int) ((app.totalTimeMillis * 100) / (maxTime > 0 ? maxTime : 1));
            pb.setProgress(percent);
            pb.setProgressTintList(ColorStateList.valueOf(Color.parseColor("#38BDF8")));
            pb.setProgressBackgroundTintList(ColorStateList.valueOf(Color.parseColor("#F1F5F9")));
            LinearLayout.LayoutParams pbLp = new LinearLayout.LayoutParams(0, dp(4), 1.0f);
            pbLp.setMargins(0, 0, dp(8), 0);
            pb.setLayoutParams(pbLp);
            barRow.addView(pb);

            TextView catView = new TextView(this);
            catView.setText(app.category);
            catView.setTextSize(9);
            catView.setTypeface(Typeface.DEFAULT_BOLD);
            catView.setTextColor(app.categoryColor);
            barRow.addView(catView);

            item.addView(barRow);
            wellbeingListContainer.addView(item);
        }
    }

    // ==========================================
    // 4. CARD 1: CORE CADENCE CONTENT
    // ==========================================
    private View createCadenceContent() {
        LinearLayout content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setPadding(0, 0, 0, dp(24));

        // 0. Circadian Schedule Timings Config Card (Custom Wake-up & Sleep Times)
        LinearLayout scheduleConfigCard = createCardLayout(Color.WHITE, Color.parseColor("#E2E8F0"));
        scheduleConfigCard.setPadding(dp(14), dp(12), dp(14), dp(12));
        scheduleConfigCard.setOrientation(LinearLayout.VERTICAL);
        LinearLayout.LayoutParams sccLp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        sccLp.setMargins(0, 0, 0, dp(12));
        scheduleConfigCard.setLayoutParams(sccLp);

        LinearLayout scHeaderRow = new LinearLayout(this);
        scHeaderRow.setOrientation(LinearLayout.HORIZONTAL);
        scHeaderRow.setGravity(Gravity.CENTER_VERTICAL);

        TextView scTitle = new TextView(this);
        scTitle.setText("⏰ CIRCADIAN SCHEDULE TIMINGS");
        scTitle.setTextSize(11);
        scTitle.setTypeface(Typeface.DEFAULT_BOLD);
        scTitle.setTextColor(Color.parseColor("#475569"));
        LinearLayout.LayoutParams sctLp = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1.0f);
        scTitle.setLayoutParams(sctLp);
        scHeaderRow.addView(scTitle);

        TextView scHint = new TextView(this);
        scHint.setText("Tap pill to edit ⚙️");
        scHint.setTextSize(10);
        scHint.setTextColor(Color.parseColor("#0284C7"));
        scHeaderRow.addView(scHint);

        scheduleConfigCard.addView(scHeaderRow);

        // 2 Interactive Time Pills Row
        LinearLayout pillsRow = new LinearLayout(this);
        pillsRow.setOrientation(LinearLayout.HORIZONTAL);
        pillsRow.setPadding(0, dp(8), 0, dp(6));

        // Wake-up Pill (Sky Blue Tint)
        LinearLayout wakePill = new LinearLayout(this);
        wakePill.setOrientation(LinearLayout.VERTICAL);
        wakePill.setGravity(Gravity.CENTER);
        wakePill.setPadding(dp(12), dp(8), dp(12), dp(8));
        GradientDrawable wbg = new GradientDrawable();
        wbg.setColor(Color.parseColor("#F0F9FF"));
        wbg.setCornerRadius(dp(12));
        wbg.setStroke(dp(1), Color.parseColor("#BAE6FD"));
        wakePill.setBackground(wbg);
        wakePill.setClickable(true);
        wakePill.setFocusable(true);
        wakePill.setOnClickListener(v -> showTimePicker(true));
        LinearLayout.LayoutParams wpLp = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1.0f);
        wpLp.setMargins(0, 0, dp(6), 0);
        wakePill.setLayoutParams(wpLp);

        TextView wakeLabel = new TextView(this);
        wakeLabel.setText("☀️ WAKE UP");
        wakeLabel.setTextSize(10);
        wakeLabel.setTypeface(Typeface.DEFAULT_BOLD);
        wakeLabel.setTextColor(Color.parseColor("#0284C7"));
        wakePill.addView(wakeLabel);

        wakeTimeView = new TextView(this);
        wakeTimeView.setText("08:00 AM");
        wakeTimeView.setTextSize(15);
        wakeTimeView.setTypeface(Typeface.DEFAULT_BOLD);
        wakeTimeView.setTextColor(Color.parseColor("#0F172A"));
        wakePill.addView(wakeTimeView);

        pillsRow.addView(wakePill);

        // Sleep Pill (Purple Tint)
        LinearLayout sleepPill = new LinearLayout(this);
        sleepPill.setOrientation(LinearLayout.VERTICAL);
        sleepPill.setGravity(Gravity.CENTER);
        sleepPill.setPadding(dp(12), dp(8), dp(12), dp(8));
        GradientDrawable sbg = new GradientDrawable();
        sbg.setColor(Color.parseColor("#FAF5FF"));
        sbg.setCornerRadius(dp(12));
        sbg.setStroke(dp(1), Color.parseColor("#E9D5FF"));
        sleepPill.setBackground(sbg);
        sleepPill.setClickable(true);
        sleepPill.setFocusable(true);
        sleepPill.setOnClickListener(v -> showTimePicker(false));
        LinearLayout.LayoutParams spLp = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1.0f);
        spLp.setMargins(dp(6), 0, 0, 0);
        sleepPill.setLayoutParams(spLp);

        TextView sleepLabel = new TextView(this);
        sleepLabel.setText("🌙 SLEEP TIME");
        sleepLabel.setTextSize(10);
        sleepLabel.setTypeface(Typeface.DEFAULT_BOLD);
        sleepLabel.setTextColor(Color.parseColor("#7E22CE"));
        sleepPill.addView(sleepLabel);

        sleepTimeView = new TextView(this);
        sleepTimeView.setText("12:00 AM");
        sleepTimeView.setTextSize(15);
        sleepTimeView.setTypeface(Typeface.DEFAULT_BOLD);
        sleepTimeView.setTextColor(Color.parseColor("#0F172A"));
        sleepPill.addView(sleepTimeView);

        pillsRow.addView(sleepPill);
        scheduleConfigCard.addView(pillsRow);

        scheduleSummaryView = new TextView(this);
        scheduleSummaryView.setTextSize(10);
        scheduleSummaryView.setTextColor(Color.parseColor("#64748B"));
        scheduleSummaryView.setPadding(dp(2), dp(2), dp(2), 0);
        scheduleConfigCard.addView(scheduleSummaryView);

        content.addView(scheduleConfigCard);
        updateScheduleTimingsUI();

        // Active Routine Card (Aesthetic Rose Red Card)
        LinearLayout activeCard = createCardLayout(Color.parseColor("#FFF1F2"), Color.parseColor("#FDA4AF"));
        activeCard.setPadding(dp(16), dp(14), dp(16), dp(14));

        TextView activeBadge = new TextView(this);
        activeBadge.setText("🌹 CURRENT ROUTINE");
        activeBadge.setTextSize(10);
        activeBadge.setTypeface(Typeface.DEFAULT_BOLD);
        activeBadge.setTextColor(Color.parseColor("#E11D48"));
        activeCard.addView(activeBadge);

        currentRomanView = new TextView(this);
        currentRomanView.setText("CALCULATING...");
        currentRomanView.setTextSize(13);
        currentRomanView.setTypeface(Typeface.DEFAULT_BOLD);
        currentRomanView.setTextColor(Color.parseColor("#E11D48"));
        currentRomanView.setPadding(0, dp(4), 0, dp(2));
        activeCard.addView(currentRomanView);

        currentTitleView = new TextView(this);
        currentTitleView.setText("Updating routine...");
        currentTitleView.setTextSize(17);
        currentTitleView.setTypeface(Typeface.DEFAULT_BOLD);
        currentTitleView.setTextColor(Color.parseColor("#0F172A"));
        currentTitleView.setPadding(0, 0, 0, dp(2));
        activeCard.addView(currentTitleView);

        currentCountdownView = new TextView(this);
        currentCountdownView.setText("Next boundary in --:--");
        currentCountdownView.setTextSize(11);
        currentCountdownView.setTextColor(Color.parseColor("#0284C7"));
        currentCountdownView.setPadding(0, 0, 0, dp(6));
        activeCard.addView(currentCountdownView);

        currentDirectiveView = new TextView(this);
        currentDirectiveView.setText("What to do: Loading protocol...");
        currentDirectiveView.setTextSize(11);
        currentDirectiveView.setTextColor(Color.parseColor("#334155"));
        currentDirectiveView.setPadding(0, 0, 0, dp(3));
        activeCard.addView(currentDirectiveView);

        currentWhyView = new TextView(this);
        currentWhyView.setText("Why: Loading benefits...");
        currentWhyView.setTextSize(10);
        currentWhyView.setTextColor(Color.parseColor("#64748B"));
        activeCard.addView(currentWhyView);

        content.addView(activeCard);

        // Action Buttons
        LinearLayout btnRow = new LinearLayout(this);
        btnRow.setOrientation(LinearLayout.HORIZONTAL);
        btnRow.setPadding(0, dp(12), 0, dp(12));

        Button testBtn = createIosGlossyButton(
            "🔔 Test",
            Color.parseColor("#38BDF8"),
            Color.parseColor("#0EA5E9"),
            Color.parseColor("#0284C7"),
            Color.parseColor("#7DD3FC")
        );
        LinearLayout.LayoutParams p1 = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1.0f);
        p1.setMargins(0, 0, dp(4), 0);
        testBtn.setLayoutParams(p1);
        testBtn.setOnClickListener(v -> triggerTestAlarm());
        btnRow.addView(testBtn);

        Button stopBtn = createIosGlossyButton(
            "⏹ Stop",
            Color.parseColor("#FB7185"),
            Color.parseColor("#F43F5E"),
            Color.parseColor("#E11D48"),
            Color.parseColor("#FDA4AF")
        );
        LinearLayout.LayoutParams pStop = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1.0f);
        pStop.setMargins(dp(4), 0, dp(4), 0);
        stopBtn.setLayoutParams(pStop);
        stopBtn.setOnClickListener(v -> {
            AlarmAudioService.stopAlarm(this);
            Toast.makeText(this, "Song stopped", Toast.LENGTH_SHORT).show();
        });
        btnRow.addView(stopBtn);

        Button blueprintBtn = createIosGlossyButton(
            "📖 Blueprint",
            Color.parseColor("#475569"),
            Color.parseColor("#334155"),
            Color.parseColor("#0F172A"),
            Color.parseColor("#94A3B8")
        );
        LinearLayout.LayoutParams p2 = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1.0f);
        p2.setMargins(dp(4), 0, 0, 0);
        blueprintBtn.setLayoutParams(p2);
        blueprintBtn.setOnClickListener(v -> {
            if (pager != null) pager.scrollToPage(6, true);
        });
        btnRow.addView(blueprintBtn);

        content.addView(btnRow);

        // Schedule Header
        TextView matrixHeader = new TextView(this);
        matrixHeader.setText("DAILY SCHEDULE (14 PHASES)");
        matrixHeader.setTextSize(10);
        matrixHeader.setTypeface(Typeface.DEFAULT_BOLD);
        matrixHeader.setTextColor(Color.parseColor("#64748B"));
        matrixHeader.setPadding(dp(2), dp(4), 0, dp(6));
        content.addView(matrixHeader);

        phaseListContainer = new LinearLayout(this);
        phaseListContainer.setOrientation(LinearLayout.VERTICAL);
        content.addView(phaseListContainer);

        renderCadenceList();
        return content;
    }

    private void renderCadenceList() {
        if (phaseListContainer == null) return;
        phaseListContainer.removeAllViews();

        for (ScheduleManager.Phase p : ScheduleManager.PHASES) {
            LinearLayout item = createCardLayout(Color.WHITE, Color.parseColor("#E2E8F0"));
            item.setOrientation(LinearLayout.VERTICAL);
            item.setPadding(dp(12), dp(10), dp(12), dp(10));
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            lp.setMargins(0, 0, 0, dp(6));
            item.setLayoutParams(lp);

            LinearLayout headerRow = new LinearLayout(this);
            headerRow.setOrientation(LinearLayout.HORIZONTAL);

            TextView timeText = new TextView(this);
            timeText.setText(p.getFormattedTime12());
            timeText.setTextSize(12);
            timeText.setTypeface(Typeface.DEFAULT_BOLD);
            timeText.setTextColor(Color.parseColor("#E11D48"));
            LinearLayout.LayoutParams timeLp = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1.0f);
            timeText.setLayoutParams(timeLp);
            headerRow.addView(timeText);
            item.addView(headerRow);

            TextView titleText = new TextView(this);
            titleText.setText(p.getDisplayTitle());
            titleText.setTextSize(13);
            titleText.setTypeface(Typeface.DEFAULT_BOLD);
            titleText.setTextColor(Color.parseColor("#0F172A"));
            titleText.setPadding(0, dp(3), 0, 0);
            item.addView(titleText);

            LinearLayout details = new LinearLayout(this);
            details.setOrientation(LinearLayout.VERTICAL);
            details.setPadding(0, dp(6), 0, 0);
            details.setVisibility(View.GONE);

            TextView dir = new TextView(this);
            dir.setText("What to do: " + p.getDisplayProtocol());
            dir.setTextSize(11);
            dir.setTextColor(Color.parseColor("#0284C7"));
            details.addView(dir);

            TextView why = new TextView(this);
            why.setText("Why: " + p.biologicalWhy);
            why.setTextSize(10);
            why.setTextColor(Color.parseColor("#64748B"));
            why.setPadding(0, dp(3), 0, 0);
            details.addView(why);

            item.addView(details);

            item.setOnClickListener(v -> {
                details.setVisibility(details.getVisibility() == View.VISIBLE ? View.GONE : View.VISIBLE);
            });

            phaseListContainer.addView(item);
        }
    }

    // ==========================================
    // 5. SYSTEM & HARDWARE MONITOR CONTENT (CARD 4)
    // ==========================================
    private View createSystemMonitorContent() {
        LinearLayout content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setPadding(0, 0, 0, dp(24));

        // ==========================================
        // SECTION 1: HARDWARE VITALS
        // ==========================================
        LinearLayout vitalsCard = createCardLayout(Color.WHITE, Color.parseColor("#E2E8F0"));
        vitalsCard.setPadding(dp(16), dp(14), dp(16), dp(14));
        vitalsCard.setOrientation(LinearLayout.VERTICAL);

        TextView vitalsHeader = new TextView(this);
        vitalsHeader.setText("HARDWARE VITALS & SENSORS");
        vitalsHeader.setTextSize(10);
        vitalsHeader.setTypeface(Typeface.DEFAULT_BOLD);
        vitalsHeader.setTextColor(Color.parseColor("#6366F1"));
        vitalsCard.addView(vitalsHeader);

        TextView vitalsSub = new TextView(this);
        vitalsSub.setText("Physical telemetry: Live RAM, internal flash storage & battery health");
        vitalsSub.setTextSize(10);
        vitalsSub.setTextColor(Color.parseColor("#64748B"));
        vitalsSub.setPadding(0, dp(1), 0, dp(10));
        vitalsCard.addView(vitalsSub);

        // A. RAM Meter Tile
        LinearLayout ramTile = createCardLayout(Color.parseColor("#F8FAFC"), Color.parseColor("#E2E8F0"));
        ramTile.setPadding(dp(12), dp(10), dp(12), dp(10));
        ramTile.setOrientation(LinearLayout.VERTICAL);

        LinearLayout ramTopRow = new LinearLayout(this);
        ramTopRow.setOrientation(LinearLayout.HORIZONTAL);
        ramTopRow.setGravity(Gravity.CENTER_VERTICAL);

        sysRamTitleView = new TextView(this);
        sysRamTitleView.setText("🧠 RAM MEMORY");
        sysRamTitleView.setTextSize(11);
        sysRamTitleView.setTypeface(Typeface.DEFAULT_BOLD);
        sysRamTitleView.setTextColor(Color.parseColor("#1E293B"));
        LinearLayout.LayoutParams ramTitleLp = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1.0f);
        sysRamTitleView.setLayoutParams(ramTitleLp);
        ramTopRow.addView(sysRamTitleView);

        sysRamSubtitleView = new TextView(this);
        sysRamSubtitleView.setText("0 GB / 0 GB (0%)");
        sysRamSubtitleView.setTextSize(11);
        sysRamSubtitleView.setTypeface(Typeface.DEFAULT_BOLD);
        sysRamSubtitleView.setTextColor(Color.parseColor("#6366F1"));
        ramTopRow.addView(sysRamSubtitleView);
        ramTile.addView(ramTopRow);

        // Progress Track
        android.widget.FrameLayout ramTrack = new android.widget.FrameLayout(this);
        LinearLayout.LayoutParams ramTrackLp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(8));
        ramTrackLp.setMargins(0, dp(8), 0, dp(6));
        ramTrack.setLayoutParams(ramTrackLp);
        ramTrack.setBackground(createPillDrawable(Color.parseColor("#E2E8F0"), dp(4)));

        sysRamProgressBar = new View(this);
        android.widget.FrameLayout.LayoutParams rpbLp = new android.widget.FrameLayout.LayoutParams(dp(20), ViewGroup.LayoutParams.MATCH_PARENT);
        sysRamProgressBar.setLayoutParams(rpbLp);
        sysRamProgressBar.setBackground(createPillDrawable(Color.parseColor("#10B981"), dp(4)));
        ramTrack.addView(sysRamProgressBar);
        ramTile.addView(ramTrack);

        sysRamSubDetailsView = new TextView(this);
        sysRamSubDetailsView.setText("Free: -- | Total: --");
        sysRamSubDetailsView.setTextSize(9);
        sysRamSubDetailsView.setTextColor(Color.parseColor("#64748B"));
        ramTile.addView(sysRamSubDetailsView);
        vitalsCard.addView(ramTile);

        // B. Storage Meter Tile
        LinearLayout storageTile = createCardLayout(Color.parseColor("#F8FAFC"), Color.parseColor("#E2E8F0"));
        storageTile.setPadding(dp(12), dp(10), dp(12), dp(10));
        storageTile.setOrientation(LinearLayout.VERTICAL);
        LinearLayout.LayoutParams stLp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        stLp.setMargins(0, dp(8), 0, 0);
        storageTile.setLayoutParams(stLp);

        LinearLayout storageTopRow = new LinearLayout(this);
        storageTopRow.setOrientation(LinearLayout.HORIZONTAL);
        storageTopRow.setGravity(Gravity.CENTER_VERTICAL);

        sysStorageTitleView = new TextView(this);
        sysStorageTitleView.setText("💾 INTERNAL FLASH STORAGE");
        sysStorageTitleView.setTextSize(11);
        sysStorageTitleView.setTypeface(Typeface.DEFAULT_BOLD);
        sysStorageTitleView.setTextColor(Color.parseColor("#1E293B"));
        LinearLayout.LayoutParams stTitleLp = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1.0f);
        sysStorageTitleView.setLayoutParams(stTitleLp);
        storageTopRow.addView(sysStorageTitleView);

        sysStorageSubtitleView = new TextView(this);
        sysStorageSubtitleView.setText("0 GB / 0 GB (0%)");
        sysStorageSubtitleView.setTextSize(11);
        sysStorageSubtitleView.setTypeface(Typeface.DEFAULT_BOLD);
        sysStorageSubtitleView.setTextColor(Color.parseColor("#0284C7"));
        storageTopRow.addView(sysStorageSubtitleView);
        storageTile.addView(storageTopRow);

        // Storage Progress Track
        android.widget.FrameLayout storageTrack = new android.widget.FrameLayout(this);
        LinearLayout.LayoutParams strackLp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(8));
        strackLp.setMargins(0, dp(8), 0, dp(6));
        storageTrack.setLayoutParams(strackLp);
        storageTrack.setBackground(createPillDrawable(Color.parseColor("#E2E8F0"), dp(4)));

        sysStorageProgressBar = new View(this);
        android.widget.FrameLayout.LayoutParams spbLp = new android.widget.FrameLayout.LayoutParams(dp(20), ViewGroup.LayoutParams.MATCH_PARENT);
        sysStorageProgressBar.setLayoutParams(spbLp);
        sysStorageProgressBar.setBackground(createPillDrawable(Color.parseColor("#0284C7"), dp(4)));
        storageTrack.addView(sysStorageProgressBar);
        storageTile.addView(storageTrack);

        sysStorageSubDetailsView = new TextView(this);
        sysStorageSubDetailsView.setText("Free: -- | Total: --");
        sysStorageSubDetailsView.setTextSize(9);
        sysStorageSubDetailsView.setTextColor(Color.parseColor("#64748B"));
        storageTile.addView(sysStorageSubDetailsView);
        vitalsCard.addView(storageTile);

        // C. Battery & Health 2x2 Grid
        LinearLayout battGrid = new LinearLayout(this);
        battGrid.setOrientation(LinearLayout.VERTICAL);
        LinearLayout.LayoutParams bgLp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        bgLp.setMargins(0, dp(10), 0, 0);
        battGrid.setLayoutParams(bgLp);

        LinearLayout battRow1 = new LinearLayout(this);
        battRow1.setOrientation(LinearLayout.HORIZONTAL);
        battRow1.setPadding(0, 0, 0, dp(6));

        // Tile 1: Level & Status
        LinearLayout tLevel = createMetricTile("🔋 LEVEL & STATUS", "#10B981");
        sysBatteryLevelView = (TextView) tLevel.getChildAt(1);
        sysBatteryStatusView = new TextView(this);
        sysBatteryStatusView.setText("Checking...");
        sysBatteryStatusView.setTextSize(10);
        sysBatteryStatusView.setTextColor(Color.parseColor("#10B981"));
        sysBatteryStatusView.setPadding(0, dp(2), 0, 0);
        tLevel.addView(sysBatteryStatusView);
        LinearLayout.LayoutParams tllp = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1.0f);
        tllp.setMargins(0, 0, dp(4), 0);
        tLevel.setLayoutParams(tllp);
        battRow1.addView(tLevel);

        // Tile 2: Health Rating
        LinearLayout tHealth = createMetricTile("🩺 CELL HEALTH", "#0284C7");
        sysBatteryHealthBadgeView = (TextView) tHealth.getChildAt(1);
        sysBatteryTechView = new TextView(this);
        sysBatteryTechView.setText("Li-ion");
        sysBatteryTechView.setTextSize(10);
        sysBatteryTechView.setTextColor(Color.parseColor("#64748B"));
        sysBatteryTechView.setPadding(0, dp(2), 0, 0);
        tHealth.addView(sysBatteryTechView);
        LinearLayout.LayoutParams thlp = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1.0f);
        thlp.setMargins(dp(4), 0, 0, 0);
        tHealth.setLayoutParams(thlp);
        battRow1.addView(tHealth);
        battGrid.addView(battRow1);

        LinearLayout battRow2 = new LinearLayout(this);
        battRow2.setOrientation(LinearLayout.HORIZONTAL);

        // Tile 3: Temperature
        LinearLayout tTemp = createMetricTile("🌡️ TEMPERATURE", "#F59E0B");
        sysBatteryTempView = (TextView) tTemp.getChildAt(1);
        TextView tTempSub = new TextView(this);
        tTempSub.setText("Thermal Status");
        tTempSub.setTextSize(10);
        tTempSub.setTextColor(Color.parseColor("#64748B"));
        tTempSub.setPadding(0, dp(2), 0, 0);
        tTemp.addView(tTempSub);
        LinearLayout.LayoutParams ttlp = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1.0f);
        ttlp.setMargins(0, 0, dp(4), 0);
        tTemp.setLayoutParams(ttlp);
        battRow2.addView(tTemp);

        // Tile 4: Voltage
        LinearLayout tVolt = createMetricTile("⚡ VOLTAGE", "#6366F1");
        sysBatteryVoltageView = (TextView) tVolt.getChildAt(1);
        TextView tVoltSub = new TextView(this);
        tVoltSub.setText("Cell Potential");
        tVoltSub.setTextSize(10);
        tVoltSub.setTextColor(Color.parseColor("#64748B"));
        tVoltSub.setPadding(0, dp(2), 0, 0);
        tVolt.addView(tVoltSub);
        LinearLayout.LayoutParams tvlp = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1.0f);
        tvlp.setMargins(dp(4), 0, 0, 0);
        tVolt.setLayoutParams(tvlp);
        battRow2.addView(tVolt);
        battGrid.addView(battRow2);

        vitalsCard.addView(battGrid);
        content.addView(vitalsCard);

        // ==========================================
        // SECTION 2: ACTIVE NETWORK USAGE
        // ==========================================
        LinearLayout netCard = createCardLayout(Color.WHITE, Color.parseColor("#E2E8F0"));
        netCard.setPadding(dp(16), dp(14), dp(16), dp(14));
        netCard.setOrientation(LinearLayout.VERTICAL);
        LinearLayout.LayoutParams ncLp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        ncLp.setMargins(0, dp(12), 0, 0);
        netCard.setLayoutParams(ncLp);

        LinearLayout netHeaderRow = new LinearLayout(this);
        netHeaderRow.setOrientation(LinearLayout.HORIZONTAL);
        netHeaderRow.setGravity(Gravity.CENTER_VERTICAL);

        TextView netHeader = new TextView(this);
        netHeader.setText("ACTIVE NETWORK USAGE");
        netHeader.setTextSize(10);
        netHeader.setTypeface(Typeface.DEFAULT_BOLD);
        netHeader.setTextColor(Color.parseColor("#0284C7"));
        LinearLayout.LayoutParams nhLp = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1.0f);
        netHeader.setLayoutParams(nhLp);
        netHeaderRow.addView(netHeader);

        sysNetworkCountBadge = new TextView(this);
        sysNetworkCountBadge.setText("0 Apps Active");
        sysNetworkCountBadge.setTextSize(9);
        sysNetworkCountBadge.setTypeface(Typeface.DEFAULT_BOLD);
        sysNetworkCountBadge.setTextColor(Color.parseColor("#0369A1"));
        sysNetworkCountBadge.setBackground(createPillDrawable(Color.parseColor("#E0F2FE"), dp(10)));
        sysNetworkCountBadge.setPadding(dp(8), dp(3), dp(8), dp(3));
        netHeaderRow.addView(sysNetworkCountBadge);
        netCard.addView(netHeaderRow);

        TextView netSub = new TextView(this);
        netSub.setText("Network traffic consumed per application since boot (Download Rx + Upload Tx)");
        netSub.setTextSize(10);
        netSub.setTextColor(Color.parseColor("#64748B"));
        netSub.setPadding(0, dp(1), 0, dp(8));
        netCard.addView(netSub);

        sysNetworkSummaryView = new TextView(this);
        sysNetworkSummaryView.setText("Total Traffic: Calculating...");
        sysNetworkSummaryView.setTextSize(10);
        sysNetworkSummaryView.setTypeface(Typeface.DEFAULT_BOLD);
        sysNetworkSummaryView.setTextColor(Color.parseColor("#0F172A"));
        sysNetworkSummaryView.setBackground(createPillDrawable(Color.parseColor("#F8FAFC"), dp(8)));
        sysNetworkSummaryView.setPadding(dp(10), dp(6), dp(10), dp(6));
        netCard.addView(sysNetworkSummaryView);

        sysNetworkListContainer = new LinearLayout(this);
        sysNetworkListContainer.setOrientation(LinearLayout.VERTICAL);
        sysNetworkListContainer.setPadding(0, dp(8), 0, 0);
        netCard.addView(sysNetworkListContainer);

        content.addView(netCard);

        // ==========================================
        // SECTION 3: BACKGROUND RUNNING APPS & MEMORY CLEANER
        // ==========================================
        LinearLayout bgCard = createCardLayout(Color.WHITE, Color.parseColor("#E2E8F0"));
        bgCard.setPadding(dp(16), dp(14), dp(16), dp(14));
        bgCard.setOrientation(LinearLayout.VERTICAL);
        LinearLayout.LayoutParams bgcLp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        bgcLp.setMargins(0, dp(12), 0, 0);
        bgCard.setLayoutParams(bgcLp);

        LinearLayout bgHeaderRow = new LinearLayout(this);
        bgHeaderRow.setOrientation(LinearLayout.HORIZONTAL);
        bgHeaderRow.setGravity(Gravity.CENTER_VERTICAL);

        TextView bgHeader = new TextView(this);
        bgHeader.setText("BACKGROUND RUNNING APPS");
        bgHeader.setTextSize(10);
        bgHeader.setTypeface(Typeface.DEFAULT_BOLD);
        bgHeader.setTextColor(Color.parseColor("#6366F1"));
        LinearLayout.LayoutParams bghLp = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1.0f);
        bgHeader.setLayoutParams(bghLp);
        bgHeaderRow.addView(bgHeader);

        sysBgAppsCountBadge = new TextView(this);
        sysBgAppsCountBadge.setText("0 Apps Running");
        sysBgAppsCountBadge.setTextSize(9);
        sysBgAppsCountBadge.setTypeface(Typeface.DEFAULT_BOLD);
        sysBgAppsCountBadge.setTextColor(Color.parseColor("#4F46E5"));
        sysBgAppsCountBadge.setBackground(createPillDrawable(Color.parseColor("#EEF2FF"), dp(10)));
        sysBgAppsCountBadge.setPadding(dp(8), dp(3), dp(8), dp(3));
        bgHeaderRow.addView(sysBgAppsCountBadge);
        bgCard.addView(bgHeaderRow);

        TextView bgSub = new TextView(this);
        bgSub.setText("Toggle each app to halt background tasks and instantly reclaim RAM");
        bgSub.setTextSize(10);
        bgSub.setTextColor(Color.parseColor("#64748B"));
        bgSub.setPadding(0, dp(1), 0, dp(10));
        bgCard.addView(bgSub);

        // Action Buttons Row (iOS Glossy Buttons: Free RAM & Clean Storage Cache)
        LinearLayout actionRow = new LinearLayout(this);
        actionRow.setOrientation(LinearLayout.HORIZONTAL);
        actionRow.setPadding(0, 0, 0, dp(10));

        Button boostBtn = createIosGlossyButton(
            "⚡ Free RAM & Boost",
            Color.parseColor("#6366F1"),
            Color.parseColor("#4F46E5"),
            Color.parseColor("#4338CA"),
            Color.parseColor("#3730A3")
        );
        LinearLayout.LayoutParams bblp = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1.0f);
        bblp.setMargins(0, 0, dp(4), 0);
        boostBtn.setLayoutParams(bblp);
        boostBtn.setOnClickListener(v -> {
            int halted = DeviceTelemetryManager.boostAllRam(this, cachedBgApps);
            Toast.makeText(this, "⚡ Boost Complete! Reclaimed RAM across " + halted + " processes.", Toast.LENGTH_SHORT).show();
            updateBackgroundAppsUI(cachedBgApps);
            new Thread(() -> {
                DeviceTelemetryManager.HardwareStats s = DeviceTelemetryManager.getHardwareStats(this);
                runOnUiThread(() -> updateHardwareVitalsUI(s));
            }).start();
        });
        actionRow.addView(boostBtn);

        Button cleanBtn = createIosGlossyButton(
            "🧹 Clean Storage Cache",
            Color.parseColor("#0284C7"),
            Color.parseColor("#0369A1"),
            Color.parseColor("#075985"),
            Color.parseColor("#0C4A6E")
        );
        LinearLayout.LayoutParams cblp = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1.0f);
        cblp.setMargins(dp(4), 0, 0, 0);
        cleanBtn.setLayoutParams(cblp);
        cleanBtn.setOnClickListener(v -> {
            long cleaned = DeviceTelemetryManager.cleanStorageCache(this);
            String msg = cleaned > 0
                ? "🧹 Cache optimized! Reclaimed " + DeviceTelemetryManager.formatBytes(cleaned) + " storage."
                : "🧹 Storage cache clean & trimmed!";
            Toast.makeText(this, msg, Toast.LENGTH_SHORT).show();
            new Thread(() -> {
                DeviceTelemetryManager.HardwareStats s = DeviceTelemetryManager.getHardwareStats(this);
                runOnUiThread(() -> updateHardwareVitalsUI(s));
            }).start();
        });
        actionRow.addView(cleanBtn);
        bgCard.addView(actionRow);

        // Background Apps List Container
        sysBgAppsListContainer = new LinearLayout(this);
        sysBgAppsListContainer.setOrientation(LinearLayout.VERTICAL);
        bgCard.addView(sysBgAppsListContainer);

        content.addView(bgCard);

        return content;
    }

    private void refreshSystemMonitorUI() {
        new Thread(() -> {
            DeviceTelemetryManager.HardwareStats stats = DeviceTelemetryManager.getHardwareStats(this);
            List<DeviceTelemetryManager.AppNetworkUsage> netApps = DeviceTelemetryManager.getNetworkUsageApps(this);
            List<DeviceTelemetryManager.BackgroundAppInfo> bgApps = DeviceTelemetryManager.getRunningBackgroundApps(this);
            cachedBgApps = bgApps;

            runOnUiThread(() -> {
                updateHardwareVitalsUI(stats);
                updateNetworkUsageUI(netApps);
                updateBackgroundAppsUI(bgApps);
            });
        }).start();
    }

    private void updateHardwareVitalsUI(DeviceTelemetryManager.HardwareStats stats) {
        if (stats == null) return;

        // RAM
        if (sysRamSubtitleView != null) {
            sysRamSubtitleView.setText(
                DeviceTelemetryManager.formatBytes(stats.usedRamBytes) + " / " +
                DeviceTelemetryManager.formatBytes(stats.totalRamBytes) + " (" + stats.ramPercent + "%)"
            );
        }
        if (sysRamSubDetailsView != null) {
            sysRamSubDetailsView.setText(
                "Free: " + DeviceTelemetryManager.formatBytes(stats.freeRamBytes) + " | Total: " + DeviceTelemetryManager.formatBytes(stats.totalRamBytes)
            );
        }
        if (sysRamProgressBar != null) {
            int availableWidth = Math.max(dp(120), screenWidth - dp(64));
            int fillWidth = Math.max(dp(8), (availableWidth * stats.ramPercent) / 100);
            ViewGroup.LayoutParams lp = sysRamProgressBar.getLayoutParams();
            lp.width = fillWidth;
            sysRamProgressBar.setLayoutParams(lp);

            int barColor = (stats.ramPercent < 70)
                ? Color.parseColor("#10B981")
                : (stats.ramPercent < 85 ? Color.parseColor("#F59E0B") : Color.parseColor("#E11D48"));
            sysRamProgressBar.setBackground(createPillDrawable(barColor, dp(4)));
        }

        // Storage
        if (sysStorageSubtitleView != null) {
            sysStorageSubtitleView.setText(
                DeviceTelemetryManager.formatBytes(stats.usedStorageBytes) + " / " +
                DeviceTelemetryManager.formatBytes(stats.totalStorageBytes) + " (" + stats.storagePercent + "%)"
            );
        }
        if (sysStorageSubDetailsView != null) {
            sysStorageSubDetailsView.setText(
                "Free: " + DeviceTelemetryManager.formatBytes(stats.freeStorageBytes) + " | Total: " + DeviceTelemetryManager.formatBytes(stats.totalStorageBytes)
            );
        }
        if (sysStorageProgressBar != null) {
            int availableWidth = Math.max(dp(120), screenWidth - dp(64));
            int fillWidth = Math.max(dp(8), (availableWidth * stats.storagePercent) / 100);
            ViewGroup.LayoutParams lp = sysStorageProgressBar.getLayoutParams();
            lp.width = fillWidth;
            sysStorageProgressBar.setLayoutParams(lp);
        }

        // Battery
        if (sysBatteryLevelView != null) {
            sysBatteryLevelView.setText(stats.batteryLevel + "%");
        }
        if (sysBatteryStatusView != null) {
            sysBatteryStatusView.setText(stats.chargingStatusText);
            sysBatteryStatusView.setTextColor(stats.isCharging ? Color.parseColor("#10B981") : Color.parseColor("#64748B"));
        }
        if (sysBatteryHealthBadgeView != null) {
            sysBatteryHealthBadgeView.setText(stats.batteryHealth);
            sysBatteryHealthBadgeView.setTextColor(stats.batteryHealth.equalsIgnoreCase("Good") ? Color.parseColor("#10B981") : Color.parseColor("#E11D48"));
        }
        if (sysBatteryTechView != null) {
            sysBatteryTechView.setText(stats.batteryTechnology);
        }
        if (sysBatteryTempView != null) {
            sysBatteryTempView.setText(String.format(Locale.US, "%.1f °C", stats.batteryTempC));
        }
        if (sysBatteryVoltageView != null) {
            sysBatteryVoltageView.setText(String.format(Locale.US, "%.2f V", stats.batteryVoltageV));
        }
    }

    private void updateNetworkUsageUI(List<DeviceTelemetryManager.AppNetworkUsage> netApps) {
        if (sysNetworkListContainer == null) return;
        sysNetworkListContainer.removeAllViews();

        int count = netApps != null ? netApps.size() : 0;
        if (sysNetworkCountBadge != null) {
            sysNetworkCountBadge.setText(count + " Apps Active");
        }

        long totalAllBytes = 0;
        long totalRx = 0;
        long totalTx = 0;

        if (netApps != null) {
            for (DeviceTelemetryManager.AppNetworkUsage app : netApps) {
                totalRx += app.rxBytes;
                totalTx += app.txBytes;
                totalAllBytes += app.totalBytes;
            }
        }

        if (sysNetworkSummaryView != null) {
            sysNetworkSummaryView.setText(
                "Total Traffic: " + DeviceTelemetryManager.formatBytes(totalAllBytes) +
                " (⬇️ " + DeviceTelemetryManager.formatBytes(totalRx) + " | ⬆️ " + DeviceTelemetryManager.formatBytes(totalTx) + ")"
            );
        }

        if (netApps == null || netApps.isEmpty()) {
            TextView emptyText = new TextView(this);
            emptyText.setText("No active network traffic recorded since boot.");
            emptyText.setTextSize(10);
            emptyText.setTextColor(Color.parseColor("#94A3B8"));
            emptyText.setPadding(0, dp(6), 0, dp(6));
            sysNetworkListContainer.addView(emptyText);
            return;
        }

        // Display top active network consumers
        int limit = Math.min(netApps.size(), 6);
        for (int i = 0; i < limit; i++) {
            DeviceTelemetryManager.AppNetworkUsage app = netApps.get(i);

            LinearLayout row = new LinearLayout(this);
            row.setOrientation(LinearLayout.HORIZONTAL);
            row.setGravity(Gravity.CENTER_VERTICAL);
            row.setPadding(0, dp(6), 0, dp(6));

            ImageView icon = new ImageView(this);
            LinearLayout.LayoutParams iconLp = new LinearLayout.LayoutParams(dp(32), dp(32));
            iconLp.setMargins(0, 0, dp(10), 0);
            icon.setLayoutParams(iconLp);
            if (app.icon != null) {
                icon.setImageDrawable(app.icon);
            } else {
                icon.setImageResource(android.R.drawable.sym_def_app_icon);
            }
            row.addView(icon);

            LinearLayout nameCol = new LinearLayout(this);
            nameCol.setOrientation(LinearLayout.VERTICAL);
            LinearLayout.LayoutParams nameLp = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1.0f);
            nameCol.setLayoutParams(nameLp);

            TextView name = new TextView(this);
            name.setText(app.appName);
            name.setTextSize(12);
            name.setTypeface(Typeface.DEFAULT_BOLD);
            name.setTextColor(Color.parseColor("#1E293B"));
            name.setSingleLine(true);
            nameCol.addView(name);

            TextView pkg = new TextView(this);
            pkg.setText(app.packageName);
            pkg.setTextSize(9);
            pkg.setTextColor(Color.parseColor("#94A3B8"));
            pkg.setSingleLine(true);
            nameCol.addView(pkg);
            row.addView(nameCol);

            LinearLayout statCol = new LinearLayout(this);
            statCol.setOrientation(LinearLayout.VERTICAL);
            statCol.setGravity(Gravity.END);

            TextView totalTxt = new TextView(this);
            totalTxt.setText(DeviceTelemetryManager.formatBytes(app.totalBytes));
            totalTxt.setTextSize(12);
            totalTxt.setTypeface(Typeface.DEFAULT_BOLD);
            totalTxt.setTextColor(Color.parseColor("#0284C7"));
            statCol.addView(totalTxt);

            TextView rxTxTxt = new TextView(this);
            rxTxTxt.setText("⬇️ " + DeviceTelemetryManager.formatShortBytes(app.rxBytes) + "  ⬆️ " + DeviceTelemetryManager.formatShortBytes(app.txBytes));
            rxTxTxt.setTextSize(9);
            rxTxTxt.setTextColor(Color.parseColor("#64748B"));
            statCol.addView(rxTxTxt);
            row.addView(statCol);

            sysNetworkListContainer.addView(row);

            if (i < limit - 1) {
                View div = new View(this);
                div.setLayoutParams(new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(1)));
                div.setBackgroundColor(Color.parseColor("#F1F5F9"));
                sysNetworkListContainer.addView(div);
            }
        }
    }

    private void updateBackgroundAppsUI(List<DeviceTelemetryManager.BackgroundAppInfo> bgApps) {
        if (sysBgAppsListContainer == null) return;
        sysBgAppsListContainer.removeAllViews();

        int count = bgApps != null ? bgApps.size() : 0;
        int runningCount = 0;
        long totalBgRam = 0;
        if (bgApps != null) {
            for (DeviceTelemetryManager.BackgroundAppInfo app : bgApps) {
                if (app.isRunning) {
                    totalBgRam += app.ramBytes;
                    runningCount++;
                }
            }
        }

        if (sysBgAppsCountBadge != null) {
            if (runningCount > 0) {
                sysBgAppsCountBadge.setText(count + " Apps (" + DeviceTelemetryManager.formatBytes(totalBgRam) + " RAM)");
                sysBgAppsCountBadge.setTextColor(Color.parseColor("#4F46E5"));
                sysBgAppsCountBadge.setBackground(createPillDrawable(Color.parseColor("#EEF2FF"), dp(10)));
            } else {
                sysBgAppsCountBadge.setText(count + " Apps (All Paused • RAM Freed)");
                sysBgAppsCountBadge.setTextColor(Color.parseColor("#059669"));
                sysBgAppsCountBadge.setBackground(createPillDrawable(Color.parseColor("#ECFDF5"), dp(10)));
            }
        }

        if (bgApps == null || bgApps.isEmpty()) {
            TextView emptyText = new TextView(this);
            emptyText.setText("No background apps detected.");
            emptyText.setTextSize(10);
            emptyText.setTextColor(Color.parseColor("#94A3B8"));
            emptyText.setPadding(0, dp(6), 0, dp(6));
            sysBgAppsListContainer.addView(emptyText);
            return;
        }

        for (DeviceTelemetryManager.BackgroundAppInfo app : bgApps) {
            LinearLayout item = createCardLayout(Color.WHITE, Color.parseColor("#E2E8F0"));
            item.setOrientation(LinearLayout.HORIZONTAL);
            item.setGravity(Gravity.CENTER_VERTICAL);
            item.setPadding(dp(10), dp(8), dp(10), dp(8));
            LinearLayout.LayoutParams itemLp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            itemLp.setMargins(0, 0, 0, dp(6));
            item.setLayoutParams(itemLp);

            ImageView icon = new ImageView(this);
            LinearLayout.LayoutParams iconLp = new LinearLayout.LayoutParams(dp(36), dp(36));
            iconLp.setMargins(0, 0, dp(10), 0);
            icon.setLayoutParams(iconLp);
            if (app.icon != null) {
                icon.setImageDrawable(app.icon);
            } else {
                icon.setImageResource(android.R.drawable.sym_def_app_icon);
            }
            item.addView(icon);

            LinearLayout col = new LinearLayout(this);
            col.setOrientation(LinearLayout.VERTICAL);
            LinearLayout.LayoutParams colLp = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1.0f);
            col.setLayoutParams(colLp);

            TextView name = new TextView(this);
            name.setText(app.appName);
            name.setTextSize(12);
            name.setTypeface(Typeface.DEFAULT_BOLD);
            name.setTextColor(Color.parseColor("#1E293B"));
            name.setSingleLine(true);
            col.addView(name);

            TextView statusText = new TextView(this);
            if (app.isRunning) {
                statusText.setText("⚡ " + DeviceTelemetryManager.formatBytes(app.ramBytes) + " RAM");
                statusText.setTextColor(Color.parseColor("#6366F1"));
            } else {
                statusText.setText("✓ Stopped • Freed " + DeviceTelemetryManager.formatBytes(app.ramBytes));
                statusText.setTextColor(Color.parseColor("#10B981"));
            }
            statusText.setTextSize(10);
            statusText.setTypeface(Typeface.DEFAULT_BOLD);
            col.addView(statusText);

            TextView pkg = new TextView(this);
            pkg.setText(app.packageName);
            pkg.setTextSize(9);
            pkg.setTextColor(Color.parseColor("#94A3B8"));
            pkg.setSingleLine(true);
            col.addView(pkg);

            item.addView(col);

            ModernToggleSwitch appSwitch = new ModernToggleSwitch(this);
            appSwitch.setChecked(app.isRunning, false);
            LinearLayout.LayoutParams swLp = new LinearLayout.LayoutParams(dp(44), dp(26));
            swLp.setMargins(dp(8), 0, 0, 0);
            appSwitch.setLayoutParams(swLp);

            appSwitch.setOnCheckedChangeListener((sw, isChecked) -> {
                if (!isChecked) {
                    DeviceTelemetryManager.killBackgroundProcess(MainActivity.this, app.packageName);
                    app.isRunning = false;
                    statusText.setText("✓ Stopped • Freed " + DeviceTelemetryManager.formatBytes(app.ramBytes));
                    statusText.setTextColor(Color.parseColor("#10B981"));
                    Toast.makeText(MainActivity.this, "Freed " + DeviceTelemetryManager.formatBytes(app.ramBytes) + " for " + app.appName, Toast.LENGTH_SHORT).show();
                    new Thread(() -> {
                        DeviceTelemetryManager.HardwareStats s = DeviceTelemetryManager.getHardwareStats(MainActivity.this);
                        runOnUiThread(() -> updateHardwareVitalsUI(s));
                    }).start();
                } else {
                    app.isRunning = true;
                    statusText.setText("⚡ " + DeviceTelemetryManager.formatBytes(app.ramBytes) + " RAM");
                    statusText.setTextColor(Color.parseColor("#6366F1"));
                    Toast.makeText(MainActivity.this, app.appName + " process paused. Open app to restart.", Toast.LENGTH_SHORT).show();
                }
            });

            item.addView(appSwitch);
            sysBgAppsListContainer.addView(item);
        }
    }

    // ==========================================
    // 5.5. CARD 5: DEEP SYSTEM CLEANER (CCLEANER)
    // ==========================================
    private View createDeepCleanContent() {
        LinearLayout content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setPadding(0, 0, 0, dp(24));

        // 1. Hero Junk Meter Card
        LinearLayout heroCard = createCardLayout(Color.WHITE, Color.parseColor("#CCFBF1"));
        heroCard.setPadding(dp(16), dp(16), dp(16), dp(16));
        heroCard.setOrientation(LinearLayout.VERTICAL);

        LinearLayout heroHeaderRow = new LinearLayout(this);
        heroHeaderRow.setOrientation(LinearLayout.HORIZONTAL);
        heroHeaderRow.setGravity(Gravity.CENTER_VERTICAL);

        TextView heroHeader = new TextView(this);
        heroHeader.setText("🧹 DEEP CACHE & RESIDUAL STORAGE");
        heroHeader.setTextSize(10);
        heroHeader.setTypeface(Typeface.DEFAULT_BOLD);
        heroHeader.setTextColor(Color.parseColor("#0D9488"));
        LinearLayout.LayoutParams hlLp = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1.0f);
        heroHeader.setLayoutParams(hlLp);
        heroHeaderRow.addView(heroHeader);

        TextView heroBadge = new TextView(this);
        heroBadge.setText("ZERO-ROOT");
        heroBadge.setTextSize(9);
        heroBadge.setTypeface(Typeface.DEFAULT_BOLD);
        heroBadge.setTextColor(Color.parseColor("#0D9488"));
        heroBadge.setPadding(dp(6), dp(2), dp(6), dp(2));
        heroBadge.setBackground(createPillDrawable(Color.parseColor("#F0FDFA"), dp(4)));
        heroHeaderRow.addView(heroBadge);
        heroCard.addView(heroHeaderRow);

        deepTotalJunkView = new TextView(this);
        deepTotalJunkView.setText("Scanning...");
        deepTotalJunkView.setTextSize(26);
        deepTotalJunkView.setTypeface(Typeface.DEFAULT_BOLD);
        deepTotalJunkView.setTextColor(Color.parseColor("#0D9488"));
        deepTotalJunkView.setPadding(0, dp(4), 0, dp(2));
        heroCard.addView(deepTotalJunkView);

        TextView heroSub = new TextView(this);
        heroSub.setText("TOTAL RECLAIMABLE APPLICATION CACHE & RESIDUAL JUNK");
        heroSub.setTextSize(9);
        heroSub.setTypeface(Typeface.DEFAULT_BOLD);
        heroSub.setTextColor(Color.parseColor("#64748B"));
        heroSub.setPadding(0, 0, 0, dp(12));
        heroCard.addView(heroSub);

        // 3-Tile Breakdown Row
        LinearLayout breakdownRow = new LinearLayout(this);
        breakdownRow.setOrientation(LinearLayout.HORIZONTAL);

        // Tile 1: App Cache
        LinearLayout tile1 = createCardLayout(Color.parseColor("#F0FDFA"), Color.parseColor("#CCFBF1"));
        tile1.setOrientation(LinearLayout.VERTICAL);
        tile1.setPadding(dp(8), dp(8), dp(8), dp(8));
        LinearLayout.LayoutParams t1Lp = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1.0f);
        t1Lp.setMargins(0, 0, dp(3), 0);
        tile1.setLayoutParams(t1Lp);

        TextView t1Lbl = new TextView(this);
        t1Lbl.setText("📱 App Cache");
        t1Lbl.setTextSize(9);
        t1Lbl.setTextColor(Color.parseColor("#0F766E"));
        tile1.addView(t1Lbl);

        deepAppCacheSubView = new TextView(this);
        deepAppCacheSubView.setText("--");
        deepAppCacheSubView.setTextSize(11);
        deepAppCacheSubView.setTypeface(Typeface.DEFAULT_BOLD);
        deepAppCacheSubView.setTextColor(Color.parseColor("#0D9488"));
        tile1.addView(deepAppCacheSubView);
        breakdownRow.addView(tile1);

        // Tile 2: Thumbnails
        LinearLayout tile2 = createCardLayout(Color.parseColor("#F0FDFA"), Color.parseColor("#CCFBF1"));
        tile2.setOrientation(LinearLayout.VERTICAL);
        tile2.setPadding(dp(8), dp(8), dp(8), dp(8));
        LinearLayout.LayoutParams t2Lp = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1.0f);
        t2Lp.setMargins(dp(3), 0, dp(3), 0);
        tile2.setLayoutParams(t2Lp);

        TextView t2Lbl = new TextView(this);
        t2Lbl.setText("🖼️ Thumbnails");
        t2Lbl.setTextSize(9);
        t2Lbl.setTextColor(Color.parseColor("#0F766E"));
        tile2.addView(t2Lbl);

        deepThumbnailSubView = new TextView(this);
        deepThumbnailSubView.setText("--");
        deepThumbnailSubView.setTextSize(11);
        deepThumbnailSubView.setTypeface(Typeface.DEFAULT_BOLD);
        deepThumbnailSubView.setTextColor(Color.parseColor("#0D9488"));
        tile2.addView(deepThumbnailSubView);
        breakdownRow.addView(tile2);

        // Tile 3: Temp & Logs
        LinearLayout tile3 = createCardLayout(Color.parseColor("#F0FDFA"), Color.parseColor("#CCFBF1"));
        tile3.setOrientation(LinearLayout.VERTICAL);
        tile3.setPadding(dp(8), dp(8), dp(8), dp(8));
        LinearLayout.LayoutParams t3Lp = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1.0f);
        t3Lp.setMargins(dp(3), 0, 0, 0);
        tile3.setLayoutParams(t3Lp);

        TextView t3Lbl = new TextView(this);
        t3Lbl.setText("📝 Temp & Logs");
        t3Lbl.setTextSize(9);
        t3Lbl.setTextColor(Color.parseColor("#0F766E"));
        tile3.addView(t3Lbl);

        deepTempLogsSubView = new TextView(this);
        deepTempLogsSubView.setText("--");
        deepTempLogsSubView.setTextSize(11);
        deepTempLogsSubView.setTypeface(Typeface.DEFAULT_BOLD);
        deepTempLogsSubView.setTextColor(Color.parseColor("#0D9488"));
        tile3.addView(deepTempLogsSubView);
        breakdownRow.addView(tile3);

        heroCard.addView(breakdownRow);

        // 2. Action Buttons Row (iOS Glossy Style)
        LinearLayout btnRow = new LinearLayout(this);
        btnRow.setOrientation(LinearLayout.HORIZONTAL);
        btnRow.setPadding(0, dp(12), 0, 0);

        runDeepCleanBtn = createIosGlossyButton(
            "🚀 Run Deep Clean",
            Color.parseColor("#14B8A6"),
            Color.parseColor("#0D9488"),
            Color.parseColor("#0F766E"),
            Color.parseColor("#2DD4BF")
        );
        LinearLayout.LayoutParams rdcLp = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1.2f);
        rdcLp.setMargins(0, 0, dp(4), 0);
        runDeepCleanBtn.setLayoutParams(rdcLp);
        runDeepCleanBtn.setOnClickListener(v -> triggerAutomatedDeepClean());
        btnRow.addView(runDeepCleanBtn);

        runTempPurgeBtn = createIosGlossyButton(
            "🧹 Purge Temp",
            Color.parseColor("#475569"),
            Color.parseColor("#334155"),
            Color.parseColor("#1E293B"),
            Color.parseColor("#64748B")
        );
        LinearLayout.LayoutParams rtpLp = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 0.8f);
        rtpLp.setMargins(dp(4), 0, 0, 0);
        runTempPurgeBtn.setLayoutParams(rtpLp);
        runTempPurgeBtn.setOnClickListener(v -> triggerTempPurge());
        btnRow.addView(runTempPurgeBtn);

        heroCard.addView(btnRow);
        content.addView(heroCard);

        // Live Cleaning Progress Container (Hidden by default)
        deepProgressLayout = createCardLayout(Color.parseColor("#F0FDFA"), Color.parseColor("#5EEAD4"));
        deepProgressLayout.setOrientation(LinearLayout.VERTICAL);
        deepProgressLayout.setPadding(dp(14), dp(12), dp(14), dp(12));
        LinearLayout.LayoutParams dplLp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        dplLp.setMargins(0, dp(10), 0, 0);
        deepProgressLayout.setLayoutParams(dplLp);
        deepProgressLayout.setVisibility(View.GONE);

        deepProgressTitle = new TextView(this);
        deepProgressTitle.setText("Cleaning in progress...");
        deepProgressTitle.setTextSize(12);
        deepProgressTitle.setTypeface(Typeface.DEFAULT_BOLD);
        deepProgressTitle.setTextColor(Color.parseColor("#0F766E"));
        deepProgressLayout.addView(deepProgressTitle);

        deepProgressBar = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
        deepProgressBar.setMax(100);
        deepProgressBar.setProgress(0);
        deepProgressBar.setProgressTintList(ColorStateList.valueOf(Color.parseColor("#0D9488")));
        deepProgressBar.setProgressBackgroundTintList(ColorStateList.valueOf(Color.parseColor("#CCFBF1")));
        LinearLayout.LayoutParams dpbLp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(8));
        dpbLp.setMargins(0, dp(6), 0, dp(6));
        deepProgressBar.setLayoutParams(dpbLp);
        deepProgressLayout.addView(deepProgressBar);

        LinearLayout progBottom = new LinearLayout(this);
        progBottom.setOrientation(LinearLayout.HORIZONTAL);
        progBottom.setGravity(Gravity.CENTER_VERTICAL);

        deepProgressFreed = new TextView(this);
        deepProgressFreed.setText("Freed: 0 B");
        deepProgressFreed.setTextSize(10);
        deepProgressFreed.setTypeface(Typeface.DEFAULT_BOLD);
        deepProgressFreed.setTextColor(Color.parseColor("#0D9488"));
        LinearLayout.LayoutParams dpfLp = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1.0f);
        deepProgressFreed.setLayoutParams(dpfLp);
        progBottom.addView(deepProgressFreed);

        deepProgressStopBtn = createStyledButton("❌ Stop", Color.parseColor("#FEE2E2"));
        deepProgressStopBtn.setTextColor(Color.parseColor("#EF4444"));
        deepProgressStopBtn.setPadding(dp(8), dp(4), dp(8), dp(4));
        deepProgressStopBtn.setTextSize(10);
        deepProgressStopBtn.setOnClickListener(v -> {
            DeepCleanManager.stopAutomatedClean(this);
            deepProgressLayout.setVisibility(View.GONE);
            Toast.makeText(this, "Clean stopped", Toast.LENGTH_SHORT).show();
        });
        progBottom.addView(deepProgressStopBtn);

        deepProgressLayout.addView(progBottom);
        content.addView(deepProgressLayout);

        // ==========================================
        // SECTION 2: 3 DEEP PERMISSIONS (CCLEANER SPEC)
        // ==========================================
        LinearLayout permCard = createCardLayout(Color.WHITE, Color.parseColor("#E2E8F0"));
        permCard.setOrientation(LinearLayout.VERTICAL);
        permCard.setPadding(dp(16), dp(14), dp(16), dp(14));
        LinearLayout.LayoutParams pclp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        pclp.setMargins(0, dp(10), 0, 0);
        permCard.setLayoutParams(pclp);

        TextView permHeader = new TextView(this);
        permHeader.setText("🛡️ CCLEANER PRO ACCESS (3 DEEP PERMISSIONS)");
        permHeader.setTextSize(10);
        permHeader.setTypeface(Typeface.DEFAULT_BOLD);
        permHeader.setTextColor(Color.parseColor("#0D9488"));
        permCard.addView(permHeader);

        TextView permSub = new TextView(this);
        permSub.setText("Enables deep filesystem scans, StorageStats computation, and zero-root cache automation");
        permSub.setTextSize(10);
        permSub.setTextColor(Color.parseColor("#64748B"));
        permSub.setPadding(0, dp(1), 0, dp(10));
        permCard.addView(permSub);

        // Perm 1: Usage Access
        permCard.addView(createPermissionItemRow(
            "📊 1. Usage Access (StorageStats)",
            "Required to read deep per-app cache and internal storage sizes",
            perm1StatusView = new TextView(this),
            perm1Btn = createStyledButton("Grant", Color.parseColor("#0D9488")),
            v -> startActivity(DeepCleanManager.getUsageAccessIntent(this))
        ));

        View div1 = new View(this);
        div1.setLayoutParams(new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(1)));
        div1.setBackgroundColor(Color.parseColor("#F1F5F9"));
        permCard.addView(div1);

        // Perm 2: All Files Storage Access
        permCard.addView(createPermissionItemRow(
            "📂 2. All Files Storage Access",
            "Required to scan and purge thumbnail dumps and orphaned temp files",
            perm2StatusView = new TextView(this),
            perm2Btn = createStyledButton("Grant", Color.parseColor("#0D9488")),
            v -> startActivity(DeepCleanManager.getAllFilesAccessIntent(this))
        ));

        View div2 = new View(this);
        div2.setLayoutParams(new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(1)));
        div2.setBackgroundColor(Color.parseColor("#F1F5F9"));
        permCard.addView(div2);

        // Perm 3: Automated Accessibility Service
        permCard.addView(createPermissionItemRow(
            "🤖 3. Automated Accessibility Service",
            "Required to cycle through applications and clear caches one by one without root",
            perm3StatusView = new TextView(this),
            perm3Btn = createStyledButton("Enable", Color.parseColor("#0D9488")),
            v -> startActivity(DeepCleanManager.getAccessibilityIntent(this))
        ));

        content.addView(permCard);

        // ==========================================
        // SECTION 3: APPLICATION CACHE LEADERBOARD
        // ==========================================
        LinearLayout appCard = createCardLayout(Color.WHITE, Color.parseColor("#E2E8F0"));
        appCard.setOrientation(LinearLayout.VERTICAL);
        appCard.setPadding(dp(16), dp(14), dp(16), dp(14));
        LinearLayout.LayoutParams aclp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        aclp.setMargins(0, dp(10), 0, 0);
        appCard.setLayoutParams(aclp);

        LinearLayout appHeadRow = new LinearLayout(this);
        appHeadRow.setOrientation(LinearLayout.HORIZONTAL);
        appHeadRow.setGravity(Gravity.CENTER_VERTICAL);

        TextView appHead = new TextView(this);
        appHead.setText("APPLICATIONS BY CACHE FOOTPRINT");
        appHead.setTextSize(10);
        appHead.setTypeface(Typeface.DEFAULT_BOLD);
        appHead.setTextColor(Color.parseColor("#0D9488"));
        LinearLayout.LayoutParams ahlp = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1.0f);
        appHead.setLayoutParams(ahlp);
        appHeadRow.addView(appHead);

        deepAppsCountBadge = new TextView(this);
        deepAppsCountBadge.setText("0 APPS");
        deepAppsCountBadge.setTextSize(9);
        deepAppsCountBadge.setTypeface(Typeface.DEFAULT_BOLD);
        deepAppsCountBadge.setTextColor(Color.parseColor("#0D9488"));
        deepAppsCountBadge.setPadding(dp(6), dp(2), dp(6), dp(2));
        deepAppsCountBadge.setBackground(createPillDrawable(Color.parseColor("#F0FDFA"), dp(4)));
        appHeadRow.addView(deepAppsCountBadge);
        appCard.addView(appHeadRow);

        TextView appSub = new TextView(this);
        appSub.setText("Sorted descending by internal cache volume. Tap 'Clean' to clear cache individually.");
        appSub.setTextSize(10);
        appSub.setTextColor(Color.parseColor("#64748B"));
        appSub.setPadding(0, dp(1), 0, dp(8));
        appCard.addView(appSub);

        deepAppListContainer = new LinearLayout(this);
        deepAppListContainer.setOrientation(LinearLayout.VERTICAL);
        appCard.addView(deepAppListContainer);

        content.addView(appCard);

        return content;
    }

    private View createPermissionItemRow(String title, String subtitle, TextView statusView, Button actionBtn, View.OnClickListener clickListener) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(0, dp(8), 0, dp(8));

        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        LinearLayout.LayoutParams colLp = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1.0f);
        col.setLayoutParams(colLp);

        TextView t = new TextView(this);
        t.setText(title);
        t.setTextSize(11);
        t.setTypeface(Typeface.DEFAULT_BOLD);
        t.setTextColor(Color.parseColor("#1E293B"));
        col.addView(t);

        LinearLayout badgeRow = new LinearLayout(this);
        badgeRow.setOrientation(LinearLayout.HORIZONTAL);
        badgeRow.setGravity(Gravity.CENTER_VERTICAL);
        badgeRow.setPadding(0, dp(3), 0, dp(3));

        statusView.setTextSize(8.5f);
        statusView.setTypeface(Typeface.DEFAULT_BOLD);
        statusView.setSingleLine(true);
        statusView.setPadding(dp(6), dp(2), dp(6), dp(2));
        badgeRow.addView(statusView);
        col.addView(badgeRow);

        TextView sub = new TextView(this);
        sub.setText(subtitle);
        sub.setTextSize(9);
        sub.setTextColor(Color.parseColor("#64748B"));
        sub.setPadding(0, 0, dp(4), 0);
        col.addView(sub);
        row.addView(col);

        actionBtn.setTextSize(10);
        actionBtn.setTextColor(Color.WHITE);
        actionBtn.setPadding(dp(12), dp(5), dp(12), dp(5));
        actionBtn.setOnClickListener(clickListener);
        LinearLayout.LayoutParams bLp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, dp(32));
        bLp.setMargins(dp(8), 0, 0, 0);
        actionBtn.setLayoutParams(bLp);
        row.addView(actionBtn);

        return row;
    }

    private void triggerAutomatedDeepClean() {
        if (!DeepCleanManager.isAccessibilityEnabled(this)) {
            new AlertDialog.Builder(this)
                .setTitle("🤖 Enable Accessibility Runner")
                .setMessage("To automatically cycle through applications and tap 'Clear Cache' without root (just like CCleaner), Rose needs its Accessibility Service enabled.\n\nWould you like to open Accessibility Settings now, or run an Instant Temp Purge instead?")
                .setPositiveButton("Open Settings", (d, w) -> startActivity(DeepCleanManager.getAccessibilityIntent(this)))
                .setNegativeButton("Instant Temp Purge", (d, w) -> triggerTempPurge())
                .setNeutralButton("Cancel", null)
                .show();
            return;
        }

        if (currentJunkOverview == null || currentJunkOverview.appList == null || currentJunkOverview.appList.isEmpty()) {
            Toast.makeText(this, "Scanning applications... Please wait a moment.", Toast.LENGTH_SHORT).show();
            refreshDeepCleanUI();
            return;
        }

        List<String> targets = new ArrayList<>();
        for (DeepCleanManager.AppJunkInfo app : currentJunkOverview.appList) {
            if (app.cacheBytes > 0) {
                targets.add(app.packageName);
            }
        }
        if (targets.isEmpty()) {
            for (DeepCleanManager.AppJunkInfo app : currentJunkOverview.appList) {
                targets.add(app.packageName);
                if (targets.size() >= 15) break;
            }
        }

        if (targets.isEmpty()) {
            Toast.makeText(this, "No apps requiring cache cleanup!", Toast.LENGTH_SHORT).show();
            return;
        }

        if (deepProgressLayout != null) {
            deepProgressLayout.setVisibility(View.VISIBLE);
            deepProgressTitle.setText("Starting automated deep clean...");
            deepProgressBar.setMax(targets.size());
            deepProgressBar.setProgress(0);
        }

        DeepCleanManager.startAutomatedClean(this, targets, new DeepCleanManager.CleaningListener() {
            @Override
            public void onProgress(int current, int total, String currentPackage, String appName, long freedBytes) {
                if (deepProgressLayout != null) {
                    deepProgressLayout.setVisibility(View.VISIBLE);
                    deepProgressTitle.setText("Cleaning " + appName + " (" + current + " of " + total + ")...");
                    deepProgressBar.setProgress(current);
                    deepProgressFreed.setText("Freed: " + DeepCleanManager.formatBytes(freedBytes));
                }
            }

            @Override
            public void onComplete(int totalCleaned, long totalFreedBytes) {
                if (deepProgressLayout != null) {
                    deepProgressLayout.setVisibility(View.GONE);
                }
                Toast.makeText(MainActivity.this, "🎉 Deep Clean Complete! Freed " + DeepCleanManager.formatBytes(totalFreedBytes) + " across " + totalCleaned + " apps!", Toast.LENGTH_LONG).show();
                refreshDeepCleanUI();
            }

            @Override
            public void onCancelled() {
                if (deepProgressLayout != null) {
                    deepProgressLayout.setVisibility(View.GONE);
                }
            }

            @Override
            public void onError(String errorMessage) {
                if (deepProgressLayout != null) {
                    deepProgressLayout.setVisibility(View.GONE);
                }
                Toast.makeText(MainActivity.this, errorMessage, Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void triggerTempPurge() {
        Toast.makeText(this, "Purging residual thumbnails, temp, and cache files...", Toast.LENGTH_SHORT).show();
        new Thread(() -> {
            DeepCleanManager.PurgeReport report = DeepCleanManager.purgeResidualAndTempFiles(MainActivity.this);
            runOnUiThread(() -> {
                Toast.makeText(MainActivity.this, "✅ " + report.summaryMessage, Toast.LENGTH_LONG).show();
                refreshDeepCleanUI();
            });
        }).start();
    }

    private void refreshDeepCleanUI() {
        // 1. Update 3 Permissions Status
        boolean p1 = DeepCleanManager.hasUsageAccess(this);
        boolean p2 = DeepCleanManager.hasAllFilesAccess(this);
        boolean p3 = DeepCleanManager.isAccessibilityEnabled(this);

        if (perm1StatusView != null) {
            perm1StatusView.setText(p1 ? "GRANTED ✅" : "REQUIRED ⚠️");
            perm1StatusView.setTextColor(p1 ? Color.parseColor("#10B981") : Color.parseColor("#D97706"));
            perm1StatusView.setBackground(createPillDrawable(p1 ? Color.parseColor("#ECFDF5") : Color.parseColor("#FFFBEB"), dp(4)));
        }
        if (perm1Btn != null) {
            perm1Btn.setText(p1 ? "Settings" : "Grant");
            perm1Btn.setBackground(createPillDrawable(p1 ? Color.parseColor("#64748B") : Color.parseColor("#0D9488"), dp(6)));
        }

        if (perm2StatusView != null) {
            perm2StatusView.setText(p2 ? "GRANTED ✅" : "REQUIRED ⚠️");
            perm2StatusView.setTextColor(p2 ? Color.parseColor("#10B981") : Color.parseColor("#D97706"));
            perm2StatusView.setBackground(createPillDrawable(p2 ? Color.parseColor("#ECFDF5") : Color.parseColor("#FFFBEB"), dp(4)));
        }
        if (perm2Btn != null) {
            perm2Btn.setText(p2 ? "Settings" : "Grant");
            perm2Btn.setBackground(createPillDrawable(p2 ? Color.parseColor("#64748B") : Color.parseColor("#0D9488"), dp(6)));
        }

        if (perm3StatusView != null) {
            perm3StatusView.setText(p3 ? "ACTIVE ✅" : "INACTIVE ⚠️");
            perm3StatusView.setTextColor(p3 ? Color.parseColor("#10B981") : Color.parseColor("#D97706"));
            perm3StatusView.setBackground(createPillDrawable(p3 ? Color.parseColor("#ECFDF5") : Color.parseColor("#FFFBEB"), dp(4)));
        }
        if (perm3Btn != null) {
            perm3Btn.setText(p3 ? "Settings" : "Enable");
            perm3Btn.setBackground(createPillDrawable(p3 ? Color.parseColor("#64748B") : Color.parseColor("#0D9488"), dp(6)));
        }

        // 2. Scan Storage & Apps Junk in Background Thread
        new Thread(() -> {
            DeepCleanManager.JunkOverview overview = DeepCleanManager.scanAllJunk(MainActivity.this);
            currentJunkOverview = overview;

            runOnUiThread(() -> {
                if (deepTotalJunkView != null) {
                    deepTotalJunkView.setText(overview.getFormattedTotal());
                }
                if (deepAppCacheSubView != null) {
                    deepAppCacheSubView.setText(overview.getFormattedAppCache());
                }
                if (deepThumbnailSubView != null) {
                    deepThumbnailSubView.setText(overview.getFormattedThumbnails());
                }
                if (deepTempLogsSubView != null) {
                    deepTempLogsSubView.setText(overview.getFormattedTempLogs());
                }
                if (deepAppsCountBadge != null) {
                    deepAppsCountBadge.setText(overview.appList.size() + " APPS");
                }
                renderDeepAppList(overview.appList);
            });
        }).start();
    }

    private void renderDeepAppList(List<DeepCleanManager.AppJunkInfo> apps) {
        if (deepAppListContainer == null) return;
        deepAppListContainer.removeAllViews();

        if (apps == null || apps.isEmpty()) {
            TextView empty = new TextView(this);
            empty.setText("No applications found.");
            empty.setTextSize(11);
            empty.setTextColor(Color.parseColor("#94A3B8"));
            empty.setPadding(0, dp(10), 0, dp(10));
            deepAppListContainer.addView(empty);
            return;
        }

        int limit = Math.min(apps.size(), 30);
        for (int i = 0; i < limit; i++) {
            DeepCleanManager.AppJunkInfo app = apps.get(i);

            LinearLayout row = new LinearLayout(this);
            row.setOrientation(LinearLayout.HORIZONTAL);
            row.setGravity(Gravity.CENTER_VERTICAL);
            row.setPadding(0, dp(7), 0, dp(7));

            ImageView iconView = new ImageView(this);
            if (app.icon != null) {
                iconView.setImageDrawable(app.icon);
            } else {
                iconView.setImageResource(android.R.drawable.sym_def_app_icon);
            }
            LinearLayout.LayoutParams icLp = new LinearLayout.LayoutParams(dp(32), dp(32));
            icLp.setMargins(0, 0, dp(10), 0);
            iconView.setLayoutParams(icLp);
            row.addView(iconView);

            LinearLayout col = new LinearLayout(this);
            col.setOrientation(LinearLayout.VERTICAL);
            LinearLayout.LayoutParams colLp = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1.0f);
            col.setLayoutParams(colLp);

            TextView name = new TextView(this);
            name.setText(app.appName);
            name.setTextSize(12);
            name.setTypeface(Typeface.DEFAULT_BOLD);
            name.setTextColor(Color.parseColor("#1E293B"));
            name.setSingleLine(true);
            col.addView(name);

            LinearLayout detailsRow = new LinearLayout(this);
            detailsRow.setOrientation(LinearLayout.HORIZONTAL);
            detailsRow.setGravity(Gravity.CENTER_VERTICAL);

            TextView cacheTxt = new TextView(this);
            cacheTxt.setText(app.isCleaned ? "✓ Cache Cleared" : (app.cacheBytes > 0 ? app.getFormattedCache() + " Cache" : "0 B Cache"));
            cacheTxt.setTextSize(10);
            cacheTxt.setTypeface(Typeface.DEFAULT_BOLD);
            cacheTxt.setTextColor(app.isCleaned ? Color.parseColor("#10B981") : (app.cacheBytes > 1024 * 1024 * 50 ? Color.parseColor("#E11D48") : Color.parseColor("#D97706")));
            detailsRow.addView(cacheTxt);

            TextView dot = new TextView(this);
            dot.setText(" • ");
            dot.setTextSize(9);
            dot.setTextColor(Color.parseColor("#94A3B8"));
            detailsRow.addView(dot);

            TextView totTxt = new TextView(this);
            totTxt.setText(app.getFormattedTotal() + " total");
            totTxt.setTextSize(9);
            totTxt.setTextColor(Color.parseColor("#64748B"));
            detailsRow.addView(totTxt);

            col.addView(detailsRow);
            row.addView(col);

            Button cleanBtn = createStyledButton("Clean", Color.parseColor("#F0FDFA"));
            cleanBtn.setTextColor(Color.parseColor("#0D9488"));
            cleanBtn.setTextSize(10);
            cleanBtn.setTypeface(Typeface.DEFAULT_BOLD);
            cleanBtn.setPadding(dp(8), dp(4), dp(8), dp(4));
            cleanBtn.setOnClickListener(v -> {
                if (DeepCleanManager.isAccessibilityEnabled(MainActivity.this)) {
                    List<String> singleTarget = new ArrayList<>();
                    singleTarget.add(app.packageName);
                    DeepCleanManager.startAutomatedClean(MainActivity.this, singleTarget, new DeepCleanManager.CleaningListener() {
                        @Override
                        public void onProgress(int current, int total, String currentPackage, String appName, long freedBytes) {}
                        @Override
                        public void onComplete(int totalCleaned, long totalFreedBytes) {
                            runOnUiThread(() -> refreshDeepCleanUI());
                        }
                        @Override
                        public void onCancelled() {}
                        @Override
                        public void onError(String errorMessage) {}
                    });
                } else {
                    DeepCleanManager.launchAppDetails(MainActivity.this, app.packageName);
                }
            });
            LinearLayout.LayoutParams cbLp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, dp(28));
            cbLp.setMargins(dp(6), 0, 0, 0);
            cleanBtn.setLayoutParams(cbLp);
            row.addView(cleanBtn);

            deepAppListContainer.addView(row);

            if (i < limit - 1) {
                View div = new View(this);
                div.setLayoutParams(new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(1)));
                div.setBackgroundColor(Color.parseColor("#F8FAFC"));
                deepAppListContainer.addView(div);
            }
        }
    }

    // ==========================================
    // 5. CARD 2: BIOMETRICS CONTENT
    // ==========================================
    private View createBiometricsContent() {
        LinearLayout content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setPadding(0, 0, 0, dp(24));

        // Hydration Card (Aesthetic Sky Blue Card)
        LinearLayout waterCard = createCardLayout(Color.parseColor("#F0F9FF"), Color.parseColor("#BAE6FD"));
        waterCard.setPadding(dp(16), dp(14), dp(16), dp(14));
        waterCard.setOrientation(LinearLayout.VERTICAL);

        TextView waterHeader = new TextView(this);
        waterHeader.setText("💧 DAILY HYDRATION GOAL");
        waterHeader.setTextSize(10);
        waterHeader.setTypeface(Typeface.DEFAULT_BOLD);
        waterHeader.setTextColor(Color.parseColor("#0284C7"));
        waterCard.addView(waterHeader);

        hydrationTextView = new TextView(this);
        hydrationTextView.setText("2250 / 3000 ml (75%)");
        hydrationTextView.setTextSize(20);
        hydrationTextView.setTypeface(Typeface.DEFAULT_BOLD);
        hydrationTextView.setTextColor(Color.parseColor("#0F172A"));
        hydrationTextView.setPadding(0, dp(3), 0, dp(6));
        waterCard.addView(hydrationTextView);

        hydrationProgressBar = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
        hydrationProgressBar.setMax(BiometricsManager.DAILY_WATER_GOAL_ML);
        hydrationProgressBar.setProgress(2250);
        hydrationProgressBar.setProgressTintList(ColorStateList.valueOf(Color.parseColor("#0284C7")));
        hydrationProgressBar.setProgressBackgroundTintList(ColorStateList.valueOf(Color.parseColor("#E0F2FE")));
        hydrationProgressBar.setLayoutParams(new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(6)));
        waterCard.addView(hydrationProgressBar);

        LinearLayout waterBtnRow = new LinearLayout(this);
        waterBtnRow.setOrientation(LinearLayout.HORIZONTAL);
        waterBtnRow.setPadding(0, dp(10), 0, 0);

        Button minusBtn = createStyledButton("– 250 ml", Color.parseColor("#F1F5F9"));
        minusBtn.setTextColor(Color.parseColor("#475569"));
        LinearLayout.LayoutParams pMin = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1.0f);
        pMin.setMargins(0, 0, dp(4), 0);
        minusBtn.setLayoutParams(pMin);
        minusBtn.setOnClickListener(v -> {
            BiometricsManager.addWater(this, -250);
            refreshHydrationUI();
        });
        waterBtnRow.addView(minusBtn);

        Button plusBtn = createStyledButton("+ 250 ml", Color.parseColor("#0284C7"));
        LinearLayout.LayoutParams pPlus = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1.0f);
        pPlus.setMargins(dp(4), 0, 0, 0);
        plusBtn.setLayoutParams(pPlus);
        plusBtn.setOnClickListener(v -> {
            BiometricsManager.addWater(this, 250);
            refreshHydrationUI();
        });
        waterBtnRow.addView(plusBtn);

        waterCard.addView(waterBtnRow);
        content.addView(waterCard);

        // Nutritional Protocol Checklist
        TextView macroHeader = new TextView(this);
        macroHeader.setText("DAILY NUTRITIONAL PROTOCOL (5 TARGETS)");
        macroHeader.setTextSize(10);
        macroHeader.setTypeface(Typeface.DEFAULT_BOLD);
        macroHeader.setTextColor(Color.parseColor("#64748B"));
        macroHeader.setPadding(dp(2), dp(12), 0, dp(6));
        content.addView(macroHeader);

        String[][] macros = new String[][]{
            {"morning_fuel", "Fuel 1: Roti+PB + 1 Banana + Soaked Nuts/Seeds + Chia", "Tyrosine, B6 & magnesium; soaked nuts boost absorption 90%+"},
            {"power_lunch", "Fuel 2: Soya Chunks (50g Double-Boiled) + Veggies + Lemon", "30g clean protein + Vit C catalyst for iron; zero palak hassle"},
            {"glut4_walk", "🚶 Mandatory 10-Minute Post-Lunch Walk", "AMPK & GLUT4 glucose disposal (zero afternoon coma)"},
            {"evening_eggs", "Fuel 3: 6 PM 3 Boiled Eggs (Tue: Paneer) + Chana + Creatine", "420mg Choline for Acetylcholine & brain ATP; superior lutein"},
            {"clean_dinner", "Fuel 4: Moong Khichdi + Curd (Finish by 9 PM for 3h Sleep Gap)", "Probiotic GABA & calcium; glymphatic brain flush in deep sleep"}
        };

        for (String[] m : macros) {
            final String key = m[0];
            LinearLayout item = createCardLayout(Color.WHITE, Color.parseColor("#E2E8F0"));
            item.setOrientation(LinearLayout.HORIZONTAL);
            item.setGravity(Gravity.CENTER_VERTICAL);
            item.setPadding(dp(10), dp(8), dp(10), dp(8));
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            lp.setMargins(0, 0, 0, dp(6));
            item.setLayoutParams(lp);

            CheckBox cb = new CheckBox(this);
            cb.setChecked(BiometricsManager.isMacroChecked(this, key));
            cb.setButtonTintList(ColorStateList.valueOf(Color.parseColor("#E11D48")));
            cb.setOnCheckedChangeListener((buttonView, isChecked) -> {
                BiometricsManager.setMacroChecked(this, key, isChecked);
            });
            item.addView(cb);

            LinearLayout textCol = new LinearLayout(this);
            textCol.setOrientation(LinearLayout.VERTICAL);
            textCol.setPadding(dp(4), 0, 0, 0);

            TextView t1 = new TextView(this);
            t1.setText(m[1]);
            t1.setTextSize(12);
            t1.setTypeface(Typeface.DEFAULT_BOLD);
            t1.setTextColor(Color.parseColor("#0F172A"));
            textCol.addView(t1);

            TextView t2 = new TextView(this);
            t2.setText(m[2]);
            t2.setTextSize(10);
            t2.setTextColor(Color.parseColor("#64748B"));
            textCol.addView(t2);

            item.addView(textCol);
            content.addView(item);
        }

        // Circadian & Energy Protocols
        TextView circHeader = new TextView(this);
        circHeader.setText("CIRCADIAN & ENERGY PROTOCOLS");
        circHeader.setTextSize(10);
        circHeader.setTypeface(Typeface.DEFAULT_BOLD);
        circHeader.setTextColor(Color.parseColor("#64748B"));
        circHeader.setPadding(dp(2), dp(12), 0, dp(6));
        content.addView(circHeader);

        String[][] circuits = new String[][]{
            {"🌅 Morning Sunlight Sync (08:30 AM)", "Direct optic reset of master circadian clock & dopamine"},
            {"🚶 Post-Lunch 10-Minute Walk (02:00 PM)", "Clears post-meal blood sugar to eliminate afternoon coma"},
            {"🥚 6 PM Brain Energy Reset", "3 Whole eggs (Tue: Paneer) + Creatine for continuous brain ATP"},
            {"🌙 3-Hour Pre-Bed Fasting Gap", "Empty stomach sleep for full glymphatic brain detox"}
        };

        for (String[] c : circuits) {
            LinearLayout item = createCardLayout(Color.WHITE, Color.parseColor("#E2E8F0"));
            item.setOrientation(LinearLayout.VERTICAL);
            item.setPadding(dp(12), dp(8), dp(12), dp(8));
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            lp.setMargins(0, 0, 0, dp(6));
            item.setLayoutParams(lp);

            TextView t1 = new TextView(this);
            t1.setText(c[0]);
            t1.setTextSize(12);
            t1.setTypeface(Typeface.DEFAULT_BOLD);
            t1.setTextColor(Color.parseColor("#0284C7"));
            item.addView(t1);

            TextView t2 = new TextView(this);
            t2.setText(c[1]);
            t2.setTextSize(10);
            t2.setTextColor(Color.parseColor("#64748B"));
            t2.setPadding(0, dp(2), 0, 0);
            item.addView(t2);

            content.addView(item);
        }

        return content;
    }

    private void refreshHydrationUI() {
        if (hydrationTextView == null || hydrationProgressBar == null) return;
        int ml = BiometricsManager.getWaterIntakeMl(this);
        int goal = BiometricsManager.DAILY_WATER_GOAL_ML;
        int percent = Math.min(100, (ml * 100) / goal);
        hydrationTextView.setText(ml + " / " + goal + " ml (" + percent + "%)");
        hydrationProgressBar.setProgress(ml);
    }

    // ==========================================
    // 6. TICKER & ROUTINE UPDATES
    // ==========================================
    private void startLiveTicker() {
        tickerHandler = new Handler(Looper.getMainLooper());
        tickerRunnable = new Runnable() {
            int tickerCount = 0;
            @Override
            public void run() {
                updateActivePhaseUI();
                tickerCount++;
                if (tickerCount % 5 == 0 && pager != null && pager.getCurrentPage() == 4) {
                    new Thread(() -> {
                        DeviceTelemetryManager.HardwareStats s = DeviceTelemetryManager.getHardwareStats(MainActivity.this);
                        runOnUiThread(() -> updateHardwareVitalsUI(s));
                    }).start();
                }
                tickerHandler.postDelayed(this, 1000);
            }
        };
        tickerHandler.post(tickerRunnable);
    }

    private void updateActivePhaseUI() {
        ScheduleManager.Phase current = ScheduleManager.getCurrentPhase();
        if (current == null) {
            if (currentTitleView != null) currentTitleView.setText("All Phases Inactive");
            return;
        }

        if (currentRomanView != null) {
            currentRomanView.setText(current.getFormattedTime12());
        }
        if (currentTitleView != null) {
            currentTitleView.setText(current.getDisplayTitle());
        }
        if (currentDirectiveView != null) {
            currentDirectiveView.setText("What to do: " + current.getDisplayProtocol());
        }
        if (currentWhyView != null) {
            currentWhyView.setText("Why: " + current.biologicalWhy);
        }
        if (currentCountdownView != null) {
            if (AppEngineManager.isAppEnabled(this)) {
                currentCountdownView.setText("Next boundary in " + calculateRemainingTime(current));
                currentCountdownView.setTextColor(Color.parseColor("#0284C7"));
            } else {
                currentCountdownView.setText("⏸️ Rose Engine PAUSED (All routine alarms stopped)");
                currentCountdownView.setTextColor(Color.parseColor("#DC2626"));
            }
        }
    }

    private String calculateRemainingTime(ScheduleManager.Phase p) {
        if (p == null) return "--:--";
        Calendar now = Calendar.getInstance();
        Calendar end = Calendar.getInstance();
        end.set(Calendar.HOUR_OF_DAY, p.endHour);
        end.set(Calendar.MINUTE, p.endMinute);
        end.set(Calendar.SECOND, 0);

        if (end.before(now)) {
            end.add(Calendar.DAY_OF_YEAR, 1);
        }

        long diffMs = end.getTimeInMillis() - now.getTimeInMillis();
        long diffMins = (diffMs / (1000 * 60)) % 60;
        long diffHours = (diffMs / (1000 * 60 * 60));
        return String.format("%02dh %02dm", diffHours, diffMins);
    }

    private void triggerTestAlarm() {
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission("android.permission.POST_NOTIFICATIONS") != PackageManager.PERMISSION_GRANTED) {
            try {
                Intent intent = new Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS);
                intent.putExtra(Settings.EXTRA_APP_PACKAGE, getPackageName());
                startActivity(intent);
                Toast.makeText(this, "Please switch 'Allow notifications' ON", Toast.LENGTH_LONG).show();
            } catch (Exception e) {
                requestPermissions(new String[]{"android.permission.POST_NOTIFICATIONS"}, 101);
            }
            return;
        }

        AlarmAudioService.startAlarm(
            this,
            "Test Cadence Alert",
            "LIVE TEST",
            "Playing: Lana Del Rey — Summertime Sadness",
            "Now"
        );

        Toast.makeText(this, "🎵 Playing Lana Del Rey — Summertime Sadness! Use 'Stop' or notification button to stop.", Toast.LENGTH_LONG).show();
    }

    private void showDecoderDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this, android.R.style.Theme_DeviceDefault_Light_Dialog_Alert);
        builder.setTitle("🌹 Brain Fuel & Bioavailability Guide");

        String msg = "• 90%+ Bioavailability Law: Curd is eaten ONLY at night so calcium never blocks daytime Iron/Zinc at DMT-1 receptors.\n\n"
                   + "• Zero Palak Hassle: 3 Whole Eggs provide 300% more bioavailable retinal Lutein/Zeaxanthin than spinach, with zero oxalates!\n\n"
                   + "• Soya Double-Boil & Lemon: Boiling twice removes oligosaccharides; fresh lemon (Vit C) boosts iron uptake by 300%.\n\n"
                   + "• Soaked & Peeled Nuts / Ground Flax: Removes phytates and breaks outer seed hull to unlock 100% of Omega-3s.\n\n"
                   + "• Creatine at 6:00 PM: Carbohydrate & sodium co-transport pushes 25% more creatine into muscle & cortical neurons.\n\n"
                   + "• 3-Hour Pre-Bed Sleep Gap: Finish dinner by 9:00 PM so stomach is empty for 12:00 AM glymphatic brain detox.";

        builder.setMessage(msg);
        builder.setPositiveButton("Understood", (dialog, which) -> dialog.dismiss());
        builder.show();
    }

    // ==========================================
    // 7. CARD 3: COMPLETE BLUEPRINT VIEWER (.MD)
    // ==========================================
    private View createBlueprintContent() {
        LinearLayout content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setPadding(0, 0, 0, dp(24));

        // Hero Card (Aesthetic Rose Petal Tint)
        LinearLayout heroCard = createCardLayout(Color.parseColor("#FFF1F2"), Color.parseColor("#FDA4AF"));
        heroCard.setPadding(dp(16), dp(14), dp(16), dp(14));
        heroCard.setOrientation(LinearLayout.VERTICAL);

        TextView heroTitle = new TextView(this);
        heroTitle.setText("🌹 HIGH-OCTANE BRAIN FUEL BLUEPRINT");
        heroTitle.setTextSize(12);
        heroTitle.setTypeface(Typeface.DEFAULT_BOLD);
        heroTitle.setTextColor(Color.parseColor("#E11D48"));
        heroCard.addView(heroTitle);

        TextView heroSub = new TextView(this);
        heroSub.setText("90%+ Bioavailability Architecture for AI/ML & Deep Robotics Engineering. Zero nutrient competition, zero anti-nutrient blockage.");
        heroSub.setTextSize(11);
        heroSub.setTextColor(Color.parseColor("#334155"));
        heroSub.setPadding(0, dp(4), 0, dp(10));
        heroCard.addView(heroSub);

        Button backBtnTop = createStyledButton("🌹 Jump to Daily Schedule", Color.parseColor("#E11D48"));
        backBtnTop.setOnClickListener(v -> {
            if (pager != null) pager.scrollToPage(1, true);
        });
        heroCard.addView(backBtnTop);
        content.addView(heroCard);

        // Blueprint Data Array: {Title, Badge, Bullet 1, Bullet 2}
        String[][] blueprintSections = new String[][]{
            {
                "1. 🍌 Bananas: 1 to 2 Daily Max (Not 4)",
                "GLYCEMIC CONTROL",
                "• Why NOT 4 bananas: 4 bananas dump ~110g carbs & 56g sugars, triggering an acute insulin spike followed by reactive hypoglycemia (brain fog and dopamine receptor down-regulation).",
                "• Optimal Rule: Exactly 1 banana at breakfast (paired with peanut butter and nuts to flatten the glucose curve) + optionally 1 before 6 PM training."
            },
            {
                "2. 🌰 Walnuts & Almonds: Soaking & Peeling Rule",
                "85%+ MINERALS",
                "• Almond Peeling: Raw almond skins are packed with phytic acid and enzyme-inhibiting tannins that block zinc and iron absorption. Soak 8-10h overnight and slip off brown skin in the morning.",
                "• Walnuts: 2-3 whole walnuts (4-6 halves) soaked for 4-6h soften bitter polyphenols and unlock ALA Omega-3s for neuronal myelin sheath repair."
            },
            {
                "3. 🥛 Curd (Dahi): Strictly at Night with Dinner",
                "DMT-1 RECEPTOR LAW",
                "• Never with Lunch: Calcium (Ca2+) and Iron (Fe2+) fight for the exact same transporter (DMT-1) in the small intestine. Curd at lunch blocks 50-60% of plant iron.",
                "• Eat at 8:30 PM: Consuming curd with Moong Dal Khichdi at night supplies bioavailable calcium & casein for deep-sleep GABA and melatonin, while probiotics rebuild gut flora."
            },
            {
                "4. 🫘 Soya Chunks: 50g-60g Double-Boiled & Squeezed",
                "30g CLEAN PROTEIN",
                "• Dry vs Boiled: 50g-60g dry expands to 160g-180g boiled (~30g pure protein, optimal single-meal leucine threshold). 80g dry expands to 250g+ and causes digestive heaviness.",
                "• Double-Boil: Boil 5 min, dump boiling water (flushes gas-causing raffinose/stachyose), squeeze firmly twice, sauté with 1/2 fresh lemon (Vitamin C boosts iron uptake 300%)."
            },
            {
                "5. 🌻 Morning Seeds Protocol: Pumpkin, Alsi & Chia",
                "PREPARATION LAW",
                "• 🎃 Pumpkin Seeds (1 Tbsp): Eat raw or lightly dry-roasted with breakfast. Chew thoroughly. Supplies ~3mg bioavailable Zinc and 75mg Magnesium for dopamine synthesis and cellular ATP.\n\n• 🌾 Alsi / Flaxseeds (1 Tbsp): MUST BE ROASTED & GROUND into powder! Whole seeds pass through undigested. Dry-roast in pan for 2 mins, grind, store in airtight jar, and sprinkle 1 Tbsp over your PB roti or morning bowl.\n\n• 💧 Chia Seeds (1 Tbsp): MUST BE SOAKED in 150-200ml water for 15-20 mins (or overnight). The soluble fiber creates a hydrophilic gel that flattens banana glucose spikes and delivers sustained hydration."
            },
            {
                "6. 💡 Zero-Palak Rule: Why You Can 100% Skip It",
                "NO MARKET HASSLE",
                "• Why Skip: Spinach has ~800mg oxalates per 100g (binds calcium/iron) and rots in 48 hours in the fridge.",
                "• The Egg Replacement: 3 Whole Eggs contain the most bioavailable Lutein & Zeaxanthin on Earth (embedded in lipid micelles, 300%+ higher retinal absorption than spinach, zero oxalates).\n• Long-life veggies: Cabbage, carrots, and capsicum last 2-3 weeks in fridge!"
            },
            {
                "7. ⚡ The 7 Bioavailability Catalyst Laws",
                "MASTER CATALYSTS",
                "1. Calcium-Iron Separation: Curd at night only.\n2. Ascorbic Acid: Fresh lemon on soya and chana converts Fe3+ to soluble Fe2+.\n3. Phytate Strip: Soak almonds, peel skin, grind flaxseeds.\n4. Fat Carrier: Vitamin D3 & egg lutein require dietary fats (mustard oil/ghee).\n5. Piperine Multiplier: Black pepper with turmeric boosts curcumin 2000%.\n6. Osmotic Hydration: Sendha namak in morning water triggers SGLT1 cellular pump.\n7. Creatine Shuttling: Taken with 6 PM chana carbs for insulin-driven CRT uptake."
            },
            {
                "8. 💊 Supplements: Creatine & Vitamin D3",
                "PROVEN STACK",
                "• Creatine Monohydrate: 3g-5g pure micronized daily at 6 PM with snack. Regenerates cerebral ATP, boosting mathematical stamina and working memory.\n• Vitamin D3 60,000 IU: 1 softgel weekly for 8 weeks, then monthly. Take immediately after lunch or eggs (requires fat for absorption)."
            },
            {
                "9. 🛒 Smart Weekly Grocery Shopping List",
                "WEEKLY PLAN",
                "• Eggs: 1-2 crates (30-60) — lasts 4 weeks in fridge.\n• Soya Chunks & Roasted Chana: 1 kg each — 3-6 months pantry shelf life.\n• Peanut Butter, Nuts & Seeds: 500g-1kg — airtight jars.\n• Bananas: Buy 6-7 twice a week.\n• Lemons: Buy 10-12 once a week (crisper drawer).\n• Cabbage & Carrots: Lasts 2-3 weeks in fridge crisper.\n• Moong Dal, Rice, Ghee, Mustard Oil, Sendha Namak: Pantry staples."
            }
        };

        for (String[] sec : blueprintSections) {
            LinearLayout card = createCardLayout(Color.WHITE, Color.parseColor("#E2E8F0"));
            card.setOrientation(LinearLayout.VERTICAL);
            card.setPadding(dp(14), dp(12), dp(14), dp(12));
            LinearLayout.LayoutParams clp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            clp.setMargins(0, 0, 0, dp(10));
            card.setLayoutParams(clp);

            LinearLayout topHeader = new LinearLayout(this);
            topHeader.setOrientation(LinearLayout.HORIZONTAL);
            topHeader.setGravity(Gravity.CENTER_VERTICAL);

            TextView secTitle = new TextView(this);
            secTitle.setText(sec[0]);
            secTitle.setTextSize(13);
            secTitle.setTypeface(Typeface.DEFAULT_BOLD);
            secTitle.setTextColor(Color.parseColor("#0F172A"));
            LinearLayout.LayoutParams stLp = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1.0f);
            secTitle.setLayoutParams(stLp);
            topHeader.addView(secTitle);

            TextView badge = new TextView(this);
            badge.setText(sec[1]);
            badge.setTextSize(9);
            badge.setTypeface(Typeface.DEFAULT_BOLD);
            badge.setTextColor(Color.parseColor("#0284C7"));
            badge.setPadding(dp(6), dp(2), dp(6), dp(2));
            GradientDrawable bbg = new GradientDrawable();
            bbg.setColor(Color.parseColor("#F0F9FF"));
            bbg.setCornerRadius(dp(6));
            bbg.setStroke(dp(1), Color.parseColor("#BAE6FD"));
            badge.setBackground(bbg);
            topHeader.addView(badge);
            card.addView(topHeader);

            if (sec.length > 2 && sec[2] != null && !sec[2].isEmpty()) {
                TextView d1 = new TextView(this);
                d1.setText(sec[2]);
                d1.setTextSize(11);
                d1.setTextColor(Color.parseColor("#334155"));
                d1.setPadding(0, dp(6), 0, dp(3));
                card.addView(d1);
            }

            if (sec.length > 3 && sec[3] != null && !sec[3].isEmpty()) {
                TextView d2 = new TextView(this);
                d2.setText(sec[3]);
                d2.setTextSize(11);
                d2.setTextColor(Color.parseColor("#64748B"));
                card.addView(d2);
            }

            content.addView(card);
        }

        Button backBtnBottom = createStyledButton("🌹 Back to Daily Schedule", Color.parseColor("#E11D48"));
        backBtnBottom.setOnClickListener(v -> {
            if (pager != null) pager.scrollToPage(1, true);
        });
        content.addView(backBtnBottom);

        return content;
    }

    // ==========================================
    // 6. POMODORO ENGINE CONTENT (CARD 1)
    // ==========================================
    private View createPomodoroContent() {
        LinearLayout content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setPadding(0, 0, 0, dp(24));

        // Hero Timer Card (Aesthetic Porcelain White with soft border)
        LinearLayout timerCard = createCardLayout(Color.WHITE, Color.parseColor("#E2E8F0"));
        timerCard.setPadding(dp(18), dp(18), dp(18), dp(18));

        // Top Header within Card
        LinearLayout cardHeader = new LinearLayout(this);
        cardHeader.setOrientation(LinearLayout.HORIZONTAL);
        cardHeader.setGravity(Gravity.CENTER_VERTICAL);

        TextView pomoTitle = new TextView(this);
        pomoTitle.setText("FOCUS INTERVAL");
        pomoTitle.setTextSize(11);
        pomoTitle.setTypeface(Typeface.DEFAULT_BOLD);
        pomoTitle.setTextColor(Color.parseColor("#64748B"));
        LinearLayout.LayoutParams ptLp = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1.0f);
        pomoTitle.setLayoutParams(ptLp);
        cardHeader.addView(pomoTitle);

        pomoPhaseBadgeView = new TextView(this);
        pomoPhaseBadgeView.setText("FOCUS SESSION");
        pomoPhaseBadgeView.setTextSize(10);
        pomoPhaseBadgeView.setTypeface(Typeface.DEFAULT_BOLD);
        pomoPhaseBadgeView.setTextColor(Color.parseColor("#E11D48"));
        pomoPhaseBadgeView.setPadding(dp(8), dp(3), dp(8), dp(3));
        pomoPhaseBadgeView.setBackground(createPillDrawable(Color.parseColor("#FFF1F2"), dp(6)));
        cardHeader.addView(pomoPhaseBadgeView);
        timerCard.addView(cardHeader);

        // Huge Countdown Display
        pomoTimerView = new TextView(this);
        pomoTimerView.setText("25:00");
        pomoTimerView.setTextSize(48);
        pomoTimerView.setTypeface(Typeface.DEFAULT_BOLD);
        pomoTimerView.setTextColor(Color.parseColor("#0F172A"));
        pomoTimerView.setGravity(Gravity.CENTER);
        pomoTimerView.setPadding(0, dp(12), 0, dp(2));
        timerCard.addView(pomoTimerView);

        // Session status subtext
        pomoSessionView = new TextView(this);
        pomoSessionView.setText("Session 1 / 4  ·  🎯 ⚪ ⚪ ⚪");
        pomoSessionView.setTextSize(12);
        pomoSessionView.setTextColor(Color.parseColor("#64748B"));
        pomoSessionView.setGravity(Gravity.CENTER);
        pomoSessionView.setPadding(0, 0, 0, dp(12));
        timerCard.addView(pomoSessionView);

        // Horizontal Progress Bar
        pomoProgressBar = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
        pomoProgressBar.setMax(100);
        pomoProgressBar.setProgress(0);
        pomoProgressBar.setProgressTintList(ColorStateList.valueOf(Color.parseColor("#E11D48")));
        LinearLayout.LayoutParams pbLp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(6));
        pbLp.setMargins(0, 0, 0, dp(16));
        pomoProgressBar.setLayoutParams(pbLp);
        timerCard.addView(pomoProgressBar);

        // Main Controls Row: Toggle (Start/Pause), Reset, Skip
        LinearLayout controlRow = new LinearLayout(this);
        controlRow.setOrientation(LinearLayout.HORIZONTAL);

        pomoToggleBtn = createStyledButton("▶ Start Focus", Color.parseColor("#E11D48"));
        LinearLayout.LayoutParams tLp = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1.4f);
        pomoToggleBtn.setLayoutParams(tLp);
        pomoToggleBtn.setOnClickListener(v -> PomodoroManager.toggle(this));
        controlRow.addView(pomoToggleBtn);

        Button resetBtn = createOutlinedButton("↺ Reset", Color.parseColor("#334155"), Color.parseColor("#CBD5E1"));
        LinearLayout.LayoutParams rLp = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 0.9f);
        rLp.setMargins(dp(6), 0, 0, 0);
        resetBtn.setLayoutParams(rLp);
        resetBtn.setOnClickListener(v -> PomodoroManager.reset(this));
        controlRow.addView(resetBtn);

        Button skipBtn = createOutlinedButton("⏭ Skip", Color.parseColor("#334155"), Color.parseColor("#CBD5E1"));
        LinearLayout.LayoutParams sLp = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 0.9f);
        sLp.setMargins(dp(6), 0, 0, 0);
        skipBtn.setLayoutParams(sLp);
        skipBtn.setOnClickListener(v -> PomodoroManager.skip(this));
        controlRow.addView(skipBtn);

        timerCard.addView(controlRow);
        content.addView(timerCard);

        // Quick Presets Header
        TextView presetHeader = new TextView(this);
        presetHeader.setText("FOCUS PRESETS & INTERVALS");
        presetHeader.setTextSize(10);
        presetHeader.setTypeface(Typeface.DEFAULT_BOLD);
        presetHeader.setTextColor(Color.parseColor("#64748B"));
        presetHeader.setPadding(dp(4), dp(16), 0, dp(8));
        content.addView(presetHeader);

        // Preset Grid Row 1 (Work presets)
        LinearLayout row1 = new LinearLayout(this);
        row1.setOrientation(LinearLayout.HORIZONTAL);

        Button b25 = createStyledButton("25m Classic Focus", Color.parseColor("#0284C7"));
        LinearLayout.LayoutParams lpB25 = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1.0f);
        lpB25.setMargins(0, 0, dp(4), dp(6));
        b25.setLayoutParams(lpB25);
        b25.setOnClickListener(v -> PomodoroManager.setPreset(this, "WORK", PomodoroManager.DURATION_WORK_DEFAULT));
        row1.addView(b25);

        Button b50 = createStyledButton("50m Deep Flow", Color.parseColor("#0284C7"));
        LinearLayout.LayoutParams lpB50 = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1.0f);
        lpB50.setMargins(dp(4), 0, 0, dp(6));
        b50.setLayoutParams(lpB50);
        b50.setOnClickListener(v -> PomodoroManager.setPreset(this, "WORK", PomodoroManager.DURATION_DEEP_WORK));
        row1.addView(b50);
        content.addView(row1);

        // Preset Grid Row 2 (Break presets)
        LinearLayout row2 = new LinearLayout(this);
        row2.setOrientation(LinearLayout.HORIZONTAL);

        Button b5 = createStyledButton("5m Short Break", Color.parseColor("#059669"));
        LinearLayout.LayoutParams lpB5 = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1.0f);
        lpB5.setMargins(0, 0, dp(4), 0);
        b5.setLayoutParams(lpB5);
        b5.setOnClickListener(v -> PomodoroManager.setPreset(this, "SHORT_BREAK", PomodoroManager.DURATION_SHORT_BREAK));
        row2.addView(b5);

        Button b15 = createStyledButton("15m Long Break", Color.parseColor("#059669"));
        LinearLayout.LayoutParams lpB15 = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1.0f);
        lpB15.setMargins(dp(4), 0, 0, 0);
        b15.setLayoutParams(lpB15);
        b15.setOnClickListener(v -> PomodoroManager.setPreset(this, "LONG_BREAK", PomodoroManager.DURATION_LONG_BREAK));
        row2.addView(b15);
        content.addView(row2);

        // Sound & Notification Alert Controls Card
        LinearLayout alertCard = createCardLayout(Color.WHITE, Color.parseColor("#E2E8F0"));
        alertCard.setPadding(dp(16), dp(14), dp(16), dp(14));
        alertCard.setOrientation(LinearLayout.VERTICAL);
        LinearLayout.LayoutParams aclp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        aclp.setMargins(0, dp(14), 0, 0);
        alertCard.setLayoutParams(aclp);

        TextView alertHeader = new TextView(this);
        alertHeader.setText("🔊 SOUND & NOTIFICATION CONTROLS");
        alertHeader.setTextSize(10);
        alertHeader.setTypeface(Typeface.DEFAULT_BOLD);
        alertHeader.setTextColor(Color.parseColor("#64748B"));
        alertCard.addView(alertHeader);

        TextView alertSub = new TextView(this);
        alertSub.setText("Toggle audible chimes and heads-up alerts on session completion");
        alertSub.setTextSize(10);
        alertSub.setTextColor(Color.parseColor("#94A3B8"));
        alertSub.setPadding(0, dp(1), 0, dp(10));
        alertCard.addView(alertSub);

        LinearLayout alertRow = new LinearLayout(this);
        alertRow.setOrientation(LinearLayout.HORIZONTAL);

        pomoSoundToggleBtn = createStyledButton(
            SoundManager.isSoundEnabled(this) ? "🔔 Sound Alert: ON" : "🔕 Sound Alert: OFF",
            SoundManager.isSoundEnabled(this) ? Color.parseColor("#E11D48") : Color.parseColor("#64748B")
        );
        LinearLayout.LayoutParams sToggleLp = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1.0f);
        sToggleLp.setMargins(0, 0, dp(4), 0);
        pomoSoundToggleBtn.setLayoutParams(sToggleLp);
        pomoSoundToggleBtn.setOnClickListener(v -> {
            boolean current = SoundManager.isSoundEnabled(this);
            boolean updated = !current;
            SoundManager.setSoundEnabled(this, updated);
            if (updated) {
                SoundManager.previewChime(this);
                Toast.makeText(this, "Sound alerts ENABLED (preview chime played)", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(this, "Sound alerts MUTED", Toast.LENGTH_SHORT).show();
            }
            updateSoundControlsUI();
        });
        alertRow.addView(pomoSoundToggleBtn);

        pomoNotifToggleBtn = createStyledButton(
            SoundManager.isNotificationEnabled(this) ? "📲 Notification: ON" : "📴 Notification: OFF",
            SoundManager.isNotificationEnabled(this) ? Color.parseColor("#0284C7") : Color.parseColor("#64748B")
        );
        LinearLayout.LayoutParams nToggleLp = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1.0f);
        nToggleLp.setMargins(dp(4), 0, 0, 0);
        pomoNotifToggleBtn.setLayoutParams(nToggleLp);
        pomoNotifToggleBtn.setOnClickListener(v -> {
            boolean current = SoundManager.isNotificationEnabled(this);
            boolean updated = !current;
            SoundManager.setNotificationEnabled(this, updated);
            if (updated && Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                if (checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
                    requestPermissions(new String[]{android.Manifest.permission.POST_NOTIFICATIONS}, 101);
                }
            }
            Toast.makeText(this, updated ? "Completion notifications ENABLED" : "Completion notifications DISABLED", Toast.LENGTH_SHORT).show();
            updateSoundControlsUI();
        });
        alertRow.addView(pomoNotifToggleBtn);
        alertCard.addView(alertRow);

        content.addView(alertCard);

        // Parallel Engine Status Card
        LinearLayout parallelCard = createCardLayout(Color.parseColor("#F0F9FF"), Color.parseColor("#BAE6FD"));
        parallelCard.setPadding(dp(14), dp(12), dp(14), dp(12));
        LinearLayout.LayoutParams pclp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        pclp.setMargins(0, dp(14), 0, 0);
        parallelCard.setLayoutParams(pclp);

        TextView parTitle = new TextView(this);
        parTitle.setText("⚡ PARALLEL ENGINE SYNCHRONIZATION");
        parTitle.setTextSize(10);
        parTitle.setTypeface(Typeface.DEFAULT_BOLD);
        parTitle.setTextColor(Color.parseColor("#0284C7"));
        parallelCard.addView(parTitle);

        pomoParallelDietView = new TextView(this);
        pomoParallelDietView.setText("• Rose Diet Cadence: Active & Independent\n• Pomodoro Engine: Ready\n• Home Screen Widget: Enabled");
        pomoParallelDietView.setTextSize(11);
        pomoParallelDietView.setTextColor(Color.parseColor("#334155"));
        pomoParallelDietView.setPadding(0, dp(4), 0, 0);
        parallelCard.addView(pomoParallelDietView);

        Button pinWidgetBtn = createStyledButton("📱 Add Widget to Home Screen", Color.parseColor("#0284C7"));
        LinearLayout.LayoutParams wlp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        wlp.setMargins(0, dp(10), 0, 0);
        pinWidgetBtn.setLayoutParams(wlp);
        pinWidgetBtn.setOnClickListener(v -> {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                AppWidgetManager appWidgetManager = getSystemService(AppWidgetManager.class);
                ComponentName myProvider = new ComponentName(this, PomodoroWidgetProvider.class);
                if (appWidgetManager != null && appWidgetManager.isRequestPinAppWidgetSupported()) {
                    appWidgetManager.requestPinAppWidget(myProvider, null, null);
                    Toast.makeText(this, "Prompting to pin Rose Pomodoro Widget!", Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(this, "Please long-press home screen -> Widgets -> Rose Pomodoro", Toast.LENGTH_LONG).show();
                }
            } else {
                Toast.makeText(this, "Please long-press home screen -> Widgets -> Rose Pomodoro", Toast.LENGTH_LONG).show();
            }
        });
        parallelCard.addView(pinWidgetBtn);

        content.addView(parallelCard);

        // Today's Stats Card
        LinearLayout statsCard = createCardLayout(Color.WHITE, Color.parseColor("#E2E8F0"));
        statsCard.setPadding(dp(14), dp(12), dp(14), dp(12));
        LinearLayout.LayoutParams sclp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        sclp.setMargins(0, dp(10), 0, 0);
        statsCard.setLayoutParams(sclp);

        TextView statsTitle = new TextView(this);
        statsTitle.setText("📈 TODAY'S PRODUCTIVITY METRICS");
        statsTitle.setTextSize(10);
        statsTitle.setTypeface(Typeface.DEFAULT_BOLD);
        statsTitle.setTextColor(Color.parseColor("#64748B"));
        statsCard.addView(statsTitle);

        pomoStatsView = new TextView(this);
        pomoStatsView.setText("• Completed Sessions: 0 / 8\n• Total Focus Time: 0 mins\n• Target: 4.0 Hours Daily Deep Work");
        pomoStatsView.setTextSize(11);
        pomoStatsView.setTextColor(Color.parseColor("#334155"));
        pomoStatsView.setPadding(0, dp(4), 0, 0);
        statsCard.addView(pomoStatsView);
        content.addView(statsCard);

        return content;
    }

    private void refreshPomodoroUI() {
        String phase = PomodoroManager.getPhase(this);
        String status = PomodoroManager.getStatus(this);
        int remaining = PomodoroManager.getRemainingSeconds(this);
        int total = PomodoroManager.getTotalSeconds(this);
        int completed = PomodoroManager.getCompletedToday(this);
        updatePomodoroUI(phase, status, remaining, total, completed);
        updateSoundControlsUI();
    }

    private void updateSoundControlsUI() {
        if (pomoSoundToggleBtn != null) {
            boolean soundOn = SoundManager.isSoundEnabled(this);
            pomoSoundToggleBtn.setText(soundOn ? "🔔 Sound Alert: ON" : "🔕 Sound Alert: OFF");
            pomoSoundToggleBtn.setBackground(createPillDrawable(soundOn ? Color.parseColor("#E11D48") : Color.parseColor("#64748B"), dp(8)));
        }
        if (pomoNotifToggleBtn != null) {
            boolean notifOn = SoundManager.isNotificationEnabled(this);
            pomoNotifToggleBtn.setText(notifOn ? "📲 Notification: ON" : "📴 Notification: OFF");
            pomoNotifToggleBtn.setBackground(createPillDrawable(notifOn ? Color.parseColor("#0284C7") : Color.parseColor("#64748B"), dp(8)));
        }
    }

    private void toggleAppEngine() {
        boolean newState = !AppEngineManager.isAppEnabled(this);
        setAppEngineState(newState);
    }

    private void setAppEngineState(boolean newState) {
        if (AppEngineManager.isAppEnabled(this) == newState) return;
        AppEngineManager.setAppEnabled(this, newState);

        if (newState) {
            startTelemetryTracking();
            Toast.makeText(this, "🟢 Rose Engine Activated (Alarms scheduled)", Toast.LENGTH_SHORT).show();
        } else {
            stopTelemetryTracking();
            Toast.makeText(this, "⏸️ Rose Engine Paused (All routine alarms stopped)", Toast.LENGTH_SHORT).show();
        }

        updateEngineStateUI();
        updateActivePhaseUI();
        refreshPomodoroUI();
    }

    private void updateEngineStateUI() {
        boolean isEnabled = AppEngineManager.isAppEnabled(this);

        // Sync Top Bar Modern iOS Toggle Switch (The single master toggle beside ROSE)
        if (topBarSwitch != null && topBarSwitch.isChecked() != isEnabled) {
            topBarSwitch.setChecked(isEnabled, true);
        }
    }

    private void showTimePicker(boolean isWake) {
        int currentH = isWake ? ScheduleManager.getWakeHour(this) : ScheduleManager.getSleepHour(this);
        int currentM = isWake ? ScheduleManager.getWakeMinute(this) : ScheduleManager.getSleepMinute(this);

        TimePickerDialog dialog = new TimePickerDialog(
            this,
            (view, hourOfDay, minute) -> {
                int wakeH = isWake ? hourOfDay : ScheduleManager.getWakeHour(this);
                int wakeM = isWake ? minute : ScheduleManager.getWakeMinute(this);
                int sleepH = !isWake ? hourOfDay : ScheduleManager.getSleepHour(this);
                int sleepM = !isWake ? minute : ScheduleManager.getSleepMinute(this);

                ScheduleManager.setScheduleTimings(this, wakeH, wakeM, sleepH, sleepM);
                updateScheduleTimingsUI();
                renderCadenceList();
                updateActivePhaseUI();

                String label = isWake ? "Wake-up" : "Sleep";
                String formatted = ScheduleManager.Phase.formatTime12(hourOfDay, minute);
                Toast.makeText(this, "✨ " + label + " set to " + formatted + " (Schedule recalculated)", Toast.LENGTH_SHORT).show();
            },
            currentH,
            currentM,
            false
        );
        dialog.setTitle(isWake ? "Set Wake-up Time" : "Set Sleep Time");
        dialog.show();
    }

    private void updateScheduleTimingsUI() {
        if (wakeTimeView == null || sleepTimeView == null) return;
        int wakeH = ScheduleManager.getWakeHour(this);
        int wakeM = ScheduleManager.getWakeMinute(this);
        int sleepH = ScheduleManager.getSleepHour(this);
        int sleepM = ScheduleManager.getSleepMinute(this);

        wakeTimeView.setText(ScheduleManager.Phase.formatTime12(wakeH, wakeM));
        sleepTimeView.setText(ScheduleManager.Phase.formatTime12(sleepH, sleepM));

        int wakeTotal = ((wakeH * 60 + wakeM) % 1440 + 1440) % 1440;
        int sleepTotal = ((sleepH * 60 + sleepM) % 1440 + 1440) % 1440;
        int wakeDuration = (sleepTotal - wakeTotal + 1440) % 1440;
        if (wakeDuration == 0) wakeDuration = 1440;
        int sleepDuration = 1440 - wakeDuration;

        float wakeHours = Math.round((wakeDuration / 60.0f) * 10.0f) / 10.0f;
        float sleepHours = Math.round((sleepDuration / 60.0f) * 10.0f) / 10.0f;
        String wStr = (wakeHours == (int) wakeHours) ? String.valueOf((int) wakeHours) : String.format("%.1f", wakeHours);
        String sStr = (sleepHours == (int) sleepHours) ? String.valueOf((int) sleepHours) : String.format("%.1f", sleepHours);

        if (scheduleSummaryView != null) {
            scheduleSummaryView.setText(wStr + "h awake • " + sStr + "h restorative sleep • " + ScheduleManager.PHASES.size() + " phases aligned");
        }
    }

    private void updatePomodoroUI(String phase, String status, int remaining, int total, int completed) {
        if (pomoTimerView == null) return;

        pomoTimerView.setText(PomodoroManager.formatTime(remaining));

        boolean isRunning = "RUNNING".equals(status);
        if (pomoToggleBtn != null) {
            pomoToggleBtn.setText(isRunning ? "⏸ Pause" : "▶ Start Focus");
            pomoToggleBtn.setBackground(createPillDrawable(isRunning ? Color.parseColor("#0284C7") : Color.parseColor("#E11D48"), dp(8)));
        }

        if (pomoPhaseBadgeView != null) {
            String badgeText = "WORK".equals(phase) ? "FOCUS SESSION" : ("LONG_BREAK".equals(phase) ? "LONG BREAK" : "SHORT BREAK");
            pomoPhaseBadgeView.setText(badgeText);
            int color = "WORK".equals(phase) ? Color.parseColor("#E11D48") : Color.parseColor("#059669");
            pomoPhaseBadgeView.setTextColor(color);
            int bgColor = "WORK".equals(phase) ? Color.parseColor("#FFF1F2") : Color.parseColor("#ECFDF5");
            pomoPhaseBadgeView.setBackground(createPillDrawable(bgColor, dp(6)));
        }

        if (pomoSessionView != null) {
            int sessionInCycle = (completed % 4) + 1;
            StringBuilder sb = new StringBuilder();
            for (int i = 1; i <= 4; i++) {
                if (i < sessionInCycle) {
                    sb.append("🍅 ");
                } else if (i == sessionInCycle) {
                    sb.append("🎯 ");
                } else {
                    sb.append("⚪ ");
                }
            }
            pomoSessionView.setText("Session " + sessionInCycle + " / 4  ·  " + sb.toString().trim());
        }

        if (pomoProgressBar != null) {
            int prog = total > 0 ? (int) (((long) (total - remaining) * 100) / total) : 0;
            pomoProgressBar.setProgress(prog);
            int pColor = "WORK".equals(phase) ? Color.parseColor("#E11D48") : Color.parseColor("#059669");
            pomoProgressBar.setProgressTintList(ColorStateList.valueOf(pColor));
        }

        if (pomoStatsView != null) {
            int totalMins = PomodoroManager.getTotalFocusMinutesToday(this);
            pomoStatsView.setText("• Completed Sessions Today: " + completed + "\n• Total Focus Time: " + totalMins + " mins\n• Status: " + (isRunning ? "Active in flow state 🚀" : "Standby / Ready"));
        }

        if (pomoParallelDietView != null) {
            ScheduleManager.Phase curPhase = ScheduleManager.getCurrentPhase();
            String dietName = curPhase != null ? curPhase.getDisplayTitle() : "Active Routine";
            boolean engineOn = AppEngineManager.isAppEnabled(this);
            pomoParallelDietView.setText("• Rose Engine: " + (engineOn ? "ACTIVE & SCHEDULED" : "PAUSED (OFF)") +
                "\n• Rose Diet Cadence: " + dietName + (engineOn ? " (Active)" : " (Paused)") +
                "\n• Pomodoro Engine: " + (isRunning ? "RUNNING (" + PomodoroManager.formatTime(remaining) + ")" : "READY") +
                "\n• Home Screen Widget: Synchronized");
        }
    }

    private Button createOutlinedButton(String text, int textColor, int borderColor) {
        Button btn = new Button(this);
        btn.setText(text);
        btn.setTextColor(textColor);
        btn.setTextSize(11);
        btn.setTypeface(Typeface.DEFAULT_BOLD);

        GradientDrawable gd = new GradientDrawable();
        gd.setColor(Color.WHITE);
        gd.setCornerRadius(dp(8));
        gd.setStroke(dp(1), borderColor);
        btn.setBackground(gd);

        return btn;
    }

    // ==========================================
    // 7. UI STYLING HELPERS
    // ==========================================
    private LinearLayout createCardLayout(int bgColor, int strokeColor) {
        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);

        GradientDrawable gd = new GradientDrawable();
        gd.setColor(bgColor);
        gd.setCornerRadius(dp(14));
        gd.setStroke(dp(1), strokeColor);
        layout.setBackground(gd);

        return layout;
    }

    private GradientDrawable createPillDrawable(int color, int radius) {
        GradientDrawable gd = new GradientDrawable();
        gd.setColor(color);
        gd.setCornerRadius(radius);
        return gd;
    }

    private Button createIosGlossyButton(String text, int topColor, int midColor, int bottomColor, int strokeColor) {
        Button btn = new Button(this);
        btn.setText(text);
        btn.setTextColor(Color.WHITE);
        btn.setTextSize(12);
        btn.setTypeface(Typeface.DEFAULT_BOLD);
        btn.setPadding(dp(12), dp(11), dp(12), dp(11));

        int radius = dp(14); // iOS squircle curve

        // Normal state: 3-stop vertical gradient for luscious specular gloss
        GradientDrawable normal = new GradientDrawable(
            GradientDrawable.Orientation.TOP_BOTTOM,
            new int[]{ topColor, midColor, bottomColor }
        );
        normal.setCornerRadius(radius);
        normal.setStroke(dp(1), strokeColor);

        // Pressed state: slightly deeper/compressed shade for tactile feedback
        GradientDrawable pressed = new GradientDrawable(
            GradientDrawable.Orientation.TOP_BOTTOM,
            new int[]{ midColor, bottomColor, darkenColor(bottomColor, 0.8f) }
        );
        pressed.setCornerRadius(radius);
        pressed.setStroke(dp(1), strokeColor);

        StateListDrawable states = new StateListDrawable();
        states.addState(new int[]{ android.R.attr.state_pressed }, pressed);
        states.addState(new int[]{}, normal);

        btn.setBackground(states);
        btn.setStateListAnimator(null); // Eliminate boxy default Android shadow
        if (Build.VERSION.SDK_INT >= 21) {
            btn.setElevation(dp(3));
        }

        return btn;
    }

    private int darkenColor(int color, float factor) {
        int a = Color.alpha(color);
        int r = Math.round(Color.red(color) * factor);
        int g = Math.round(Color.green(color) * factor);
        int b = Math.round(Color.blue(color) * factor);
        return Color.argb(a, Math.min(r, 255), Math.min(g, 255), Math.min(b, 255));
    }

    private Button createStyledButton(String text, int color) {
        Button btn = new Button(this);
        btn.setText(text);
        btn.setTextColor(Color.WHITE);
        btn.setTextSize(11);
        btn.setTypeface(Typeface.DEFAULT_BOLD);

        GradientDrawable gd = new GradientDrawable();
        gd.setColor(color);
        gd.setCornerRadius(dp(8));
        btn.setBackground(gd);

        return btn;
    }

    private int dp(int value) {
        float density = getResources().getDisplayMetrics().density;
        return Math.round(value * density);
    }
}
