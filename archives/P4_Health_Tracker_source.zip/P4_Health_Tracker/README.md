# P4: Health Tracker & Biological Architecture Cadence

Unified system cadence and biometric tracking suite comprising:
1. **System Cadence & Decoder Matrix**: Pure Roman temporal scheduling (`SCHEDULE.md`), biological decoder (`DECODER.md`), and single-page Typst compiled PDF (`SCHEDULE.pdf`).
2. **Native Android Application (`android/`)**: Standalone APK with exact `AlarmManager` wakeup triggers, foreground audio service (`AlarmAudioService`) playing Stephen Chow's *Li Xianglan*, interactive Roman matrix, and Master Decoder key dialog.
3. **Desktop Daemon (`desktop/`)**: Rust daemon (`chronosd`) providing unmissable desktop overlays and desktop audio playback on Ubuntu Linux.

---

## Directory Structure

```text
P4_Health_Tracker/
├── SCHEDULE.md          # 16-phase encrypted Roman temporal timetable
├── DECODER.md           # Biological mechanisms, nutritional ciphers & workout circuits
├── SCHEDULE.pdf         # Typst-compiled single-page reference sheet
├── schedule.toml        # Unified daemon & mobile cadence configuration
├── android/             # Native Android application
│   ├── src/             # Java source (MainActivity, AlarmAudioService, ReminderReceiver, BootReceiver)
│   ├── res/             # Android layouts, drawables, strings, and res/raw/li_xiang_lan.mp3
│   ├── AndroidManifest.xml # Exact alarm & media foreground service permissions
│   ├── build_apk.sh     # Standalone SDK compiler toolchain (aapt2, javac, d8, apksigner)
│   └── dist/            # Compiled HealthTracker.apk
└── desktop/             # Rust desktop reminder overlay daemon (chronosd)
    ├── Cargo.toml
    ├── src/
    └── systemd/
```

---

## Audio & Alarm Architecture (Android)

* **Audio Asset:** *Li Xianglan* (李香蘭) performed by Stephen Chow in *From Beijing with Love* (1994), embedded in `android/res/raw/li_xiang_lan.mp3`.
* **Foreground Service (`AlarmAudioService`):**
  * Dedicated `FOREGROUND_SERVICE_MEDIA_PLAYBACK` service ensures Android low-memory killer (LMK) never interrupts playback midway.
  * Requests `AudioManager.AUDIOFOCUS_GAIN` with `USAGE_ALARM` and `setWillPauseWhenDucked(false)`, guaranteeing that pulling down the notification drawer never pauses or ducks the audio.
  * Integrated **`[⏹ Stop Song]`** action both on the heads-up notification and in-app button for instant audio termination.
