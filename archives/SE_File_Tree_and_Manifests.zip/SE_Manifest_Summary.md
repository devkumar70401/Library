# 📁 SE Master File & Tree Manifest
**Generated:** 2026-08-30 13:58:50  
**Total Files (All):** 106,550  
**Curated Files:** 2,700  
**Total Size:** 5455.85 MB  

## 📊 Domain Breakdown
| Domain / Directory | File Count | Total Size (MB) |
| :--- | :--- | :--- |
|  | 6 | 0.04 MB |
|  | 11 | 0.01 MB |
|  | 2 | 0.00 MB |
|  | 23 | 0.21 MB |
|  | 251 | 384.05 MB |
|  | 1,818 | 151.56 MB |
|  | 24 | 0.29 MB |
|  | 268 | 14.14 MB |
|  | 82 | 1.31 MB |
|  | 42 | 0.18 MB |
|  | 79 | 92.81 MB |
|  | 3 | 51.47 MB |
|  | 1 | 0.54 MB |
|  | 50 | 0.33 MB |
|  | 27 | 0.75 MB |
|  | 2 | 0.01 MB |
|  | 11 | 9.13 MB |